#!/usr/bin/env bash
# Längen-Ensemble R01/R03/R04 mit Seed-Kontrolle einplanen. Auf dem Login-Knoten, in at_env, im Ordner human301:
#
#   bash diagnose_r_ensemble/einplanen.sh [--account=NAME]
#   bash diagnose_r_ensemble/einplanen.sh --nur-auswertung [--account=NAME]   # nur den CPU-Job neu einplanen
#
# 1. Kopiert configs/R08_01_eval_range8_seed14_15_middle.json nach big_ablation/configs, nur wenn sie dort fehlt.
#    Kein Programmcode ändert sich; laufende Arrays und bestehende Configs bleiben unberührt.
# 2. Reicht R08 (reine Inferenz: 01 mit Seed 14 und 15, Crops wie R01) über submit_array.sh ein und löst danach
#    dessen Wartebedingung. R08 nutzt freie Plätze; die Kette N2 -> N3 bleibt, wie sie ist.
# 3. Plant das Aufräumen neu, damit es auch auf R08 wartet.
# 4. Plant den CPU-Job der Auswertung mit afterany auf R08 und auf noch wartende R01/R03/R04/R05-Jobs. Fehlen
#    danach Läufe, bricht die Auswertung über ihre eigene Prüfung mit "Error" ab, statt endlos zu warten.
# Ergebnisse: diagnose_r_ensemble/ergebnisse/ (eine CSV je Vergleich, zusammenfassung.txt); Log in logs/.
# Auf dem Login-Knoten läuft nichts Schweres.
set -euo pipefail
HIER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BA="$(cd "$HIER/../big_ablation" && pwd)"
R08=R08_01_eval_range8_seed14_15_middle
NUR_AUSWERTUNG=0
ACCOUNT=()
for arg in "$@"; do
    case "$arg" in
        --nur-auswertung) NUR_AUSWERTUNG=1 ;;
        --account=?*) ACCOUNT=("$arg") ;;
        *) echo "Unbekannte Option: $arg (Aufruf: bash einplanen.sh [--nur-auswertung] [--account=NAME])" >&2; exit 2 ;;
    esac
done
PY="${CONDA_PREFIX:+$CONDA_PREFIX/bin/python}"
PY="${PY:-$(command -v python3)}"

echo "== Prüfen"
for exe in sbatch squeue scontrol scancel; do
    command -v "$exe" >/dev/null || { echo "Abgebrochen: $exe fehlt (Login-Knoten?)" >&2; exit 1; }
done
"$PY" -c "import numpy, scipy, sklearn" 2>/dev/null \
    || { echo "Abgebrochen: $PY ohne numpy/scipy/sklearn – zuerst at_env aktivieren." >&2; exit 1; }
NAMEN="$(squeue --me -h -o "%j")" || { echo "Abgebrochen: squeue nicht abfragbar." >&2; exit 1; }
if grep -qx "h301_r_ensemble" <<< "$NAMEN"; then
    echo "Abgebrochen: Der Auswertungsjob h301_r_ensemble steht schon in der Queue." >&2; exit 1
fi
if [ -d "$HIER/ergebnisse" ] && [ -n "$(ls -A "$HIER/ergebnisse")" ]; then
    echo "Abgebrochen: $HIER/ergebnisse enthält schon Ergebnisse; zuerst umbenennen." >&2; exit 1
fi
if [ "$NUR_AUSWERTUNG" = 0 ]; then
    if grep -q "^h301_array_$R08" <<< "$NAMEN"; then
        echo "Abgebrochen: R08 steht schon in der Queue. Nur die Auswertung neu einplanen: --nur-auswertung" >&2; exit 1
    fi
    [ ! -e "$BA/results/$R08" ] \
        || { echo "Abgebrochen: results/$R08 existiert schon (schon eingereicht?). Sonst: --nur-auswertung" >&2; exit 1; }
    if [ -e "$BA/configs/$R08.json" ] && ! cmp -s "$HIER/configs/$R08.json" "$BA/configs/$R08.json"; then
        echo "Abgebrochen: configs/$R08.json gibt es schon in einer anderen Fassung; nichts verändert." >&2; exit 1
    fi
fi
# Quellen von R08 und Stand von R01/R03/R04/R05 (nur Dateien lesen)
"$PY" - "$BA" "$NUR_AUSWERTUNG" <<'PYTHON' || { echo "Abgebrochen: Checkpoints für R08 fehlen (siehe oben)." >&2; exit 1; }
import csv, json, sys
from pathlib import Path
ba, nur_auswertung = Path(sys.argv[1]), sys.argv[2] == "1"
with (ba / "configs/training_priority_middle.csv").open(newline="") as handle:
    paare = [(z["tf"], {"CHS": "CHIP"}.get(z["assay"], z["assay"])) for z in csv.DictReader(handle)]
def fertig(experiment, tf, assay, seed):
    try:
        meta = json.loads((ba / "results" / experiment / "runs" / tf / f"train_{assay}" / f"seed_{seed:02d}"
                           / "run.json").read_text())
    except (OSError, ValueError):
        return False
    return meta.get("status") == "completed"
fehlt = []
for seed in (14, 15):
    quelle = f"01_basic_0p1cdo_seed{seed}"
    for tf, assay in paare:
        lauf = ba / "results" / quelle / "runs" / tf / f"train_{assay}" / f"seed_{seed:02d}"
        if not fertig(quelle, tf, assay, seed) or not (lauf / "training" / "model_for_prediction.pt").is_file():
            fehlt.append(f"{quelle} {tf}/{assay}")
if fehlt and not nur_auswertung:
    print(f"Ohne abgeschlossenen Lauf mit Checkpoint ({len(fehlt)}): " + ", ".join(fehlt[:8]))
    sys.exit(1)
print(f"Checkpoints für Seed 14 und 15: alle {2 * len(paare)} vorhanden" if not fehlt else
      f"Hinweis: {len(fehlt)} Seed-Läufe ohne Checkpoint")
for name in ("R01_A33_eval_range_middle", "R03_R01_crop128_middle", "R04_R01_crop64_middle", "R05_01_eval_range8_middle"):
    n = sum(fertig(name, tf, assay, 13) for tf, assay in paare)
    print(f"{name}: {n} von {len(paare)} Läufen abgeschlossen")
PYTHON

BA_ECHT="$(cd "$BA" && pwd -P)"
# Jobs dieses Projekts zu R01/R03/R04/R05 und R08 (Arrays über plans/*/submission.json, Sammeljobs über den Namen)
abhaengige() {
    squeue --me -h -o "%F|%j|%Z" | "$PY" -c '
import json, sys
from pathlib import Path
ba = Path(sys.argv[1]).resolve()
gesucht = set(sys.argv[2:])
arrays = {}
for pfad in (ba / "plans").glob("*/submission.json"):
    try:
        stand = json.loads(pfad.read_text())
    except (OSError, ValueError):
        continue
    if isinstance(stand, dict) and stand.get("array_id") is not None:
        arrays[str(stand["array_id"])] = set(stand.get("configs", []))
ids = set()
for zeile in sys.stdin:
    teile = zeile.strip().split("|")
    if len(teile) != 3 or not teile[2] or Path(teile[2]).resolve() != ba:
        continue
    job, name = teile[0], teile[1]
    if (name.startswith("h301_collect_") and name[len("h301_collect_"):] in gesucht) or \
       (name.startswith("h301_array_") and arrays.get(job, set()) & gesucht):
        ids.add(job)
print(":".join(sorted(ids, key=int)))
' "$BA_ECHT" "$@"
}

if [ "$NUR_AUSWERTUNG" = 0 ]; then
    echo "== Config R08"
    if [ -e "$BA/configs/$R08.json" ]; then
        echo "  configs/$R08.json ist schon da (gleiche Fassung)."
    else
        cp "$HIER/configs/$R08.json" "$BA/configs/$R08.json.neu"
        mv -n "$BA/configs/$R08.json.neu" "$BA/configs/$R08.json"
        cmp -s "$HIER/configs/$R08.json" "$BA/configs/$R08.json" \
            || { echo "Abgebrochen: configs/$R08.json nicht sauber angelegt." >&2; exit 1; }
        echo "  configs/$R08.json angelegt."
    fi

    echo "== R08 einreichen"
    AUSGABE="$(cd "$BA" && bash submit_array.sh "$R08" ${ACCOUNT[@]+"${ACCOUNT[@]}"} 2>&1)" \
        || { echo "$AUSGABE" >&2; echo "Abgebrochen: submit_array.sh $R08 ist gescheitert." >&2; exit 1; }
    echo "$AUSGABE"
    ARRAY="$(sed -n 's/^Jobarray \([0-9][0-9]*\):.*/\1/p' <<< "$AUSGABE" | sed -n 1p)"
    [ -n "$ARRAY" ] || { echo "Abgebrochen: Nummer des R08-Arrays nicht gefunden." >&2; exit 1; }

    echo "== Wartebedingung von R08 lösen (nutzt freie Plätze; N2 -> N3 bleibt)"
    if scontrol update JobId="$ARRAY" Dependency=; then
        echo "  $ARRAY: wartet auf nichts mehr"
    else
        echo "WARNUNG: Wartebedingung von $ARRAY nicht gelöst; R08 startet dann erst nach den bisherigen Arrays." >&2
    fi
fi

# Aufräumen neu einplanen, damit es auch auf R08 wartet: gleich nach dem Einreichen, damit ein späterer Fehler es
# nicht überspringt; mit --nur-auswertung nur, wenn R08 noch in der Queue steht.
R08_JOBS="$(squeue --me -h -o "%j")" || R08_JOBS=""
if [ "$NUR_AUSWERTUNG" = 0 ] || grep -q "^h301_\(array\|collect\)_$R08" <<< "$R08_JOBS"; then
    echo "== Aufräumen neu einplanen"
    AUFRAEUMEN="$(squeue --me -h -o "%i|%j|%Z" | awk -F'|' -v ba="$BA_ECHT" '$2 == "h301_aufraeumen" && $3 == ba {print $1}')" \
        || AUFRAEUMEN=""
    if [ -n "$AUFRAEUMEN" ]; then
        scancel $AUFRAEUMEN || true
        sleep 2
        (cd "$BA" && bash aufraeumen.sh --nach-jobs) \
            || echo "WARNUNG: Aufräumen nicht neu eingeplant – später: bash aufraeumen.sh --nach-jobs" >&2
    else
        echo "  Kein Aufräumen eingeplant."
    fi
fi

echo "== Auswertung als CPU-Job einplanen"
SPAETER="Auswertung später einplanen: bash $HIER/einplanen.sh --nur-auswertung"
WARTE="$(abhaengige R01_A33_eval_range_middle R03_R01_crop128_middle R04_R01_crop64_middle \
                    R05_01_eval_range8_middle "$R08")" \
    || { echo "Abgebrochen: Queue nicht lesbar. $SPAETER" >&2; exit 1; }
JOBS="$(squeue --me -h -o "%j|%P")" || { echo "Abgebrochen: Queue nicht lesbar. $SPAETER" >&2; exit 1; }
PARTITION="$(awk -F'|' -v n="h301_collect_$R08" '$1 == n {print $2; exit}' <<< "$JOBS")"
mkdir -p "$HIER/logs"
OPTIONEN=(--parsable --no-requeue --job-name=h301_r_ensemble --chdir="$HIER" --output="$HIER/logs/ensemble_%j.out"
          --time=04:00:00 --ntasks=1 --cpus-per-task=4 --mem=16G --export=ALL,ENSEMBLE_ORDNER="$HIER")
[ -n "$PARTITION" ] && OPTIONEN+=(--partition="$PARTITION")
[ -n "$WARTE" ] && OPTIONEN+=(--dependency=afterany:"$WARTE")
JOB="$(sbatch "${OPTIONEN[@]}" ${ACCOUNT[@]+"${ACCOUNT[@]}"} "$HIER/ensemble_job.sh")" \
    || { echo "Abgebrochen: sbatch für die Auswertung gescheitert. $SPAETER" >&2; exit 1; }
JOB="${JOB%%;*}"
echo "  Auswertung: Job $JOB" ${WARTE:+"(startet nach dem Ende von ${WARTE//:/, })"}

echo "== Wartende Jobs"
squeue --me -t PENDING -o "%.18i %.10Q %.20r %.45E %.55j"
echo "Log der Auswertung: $HIER/logs/ensemble_$JOB.out; Ergebnisse: $HIER/ergebnisse/"
