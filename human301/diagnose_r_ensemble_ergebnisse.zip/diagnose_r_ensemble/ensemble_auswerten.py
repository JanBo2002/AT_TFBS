#!/usr/bin/env python3
"""Längen-Ensemble aus R01 (256 bp), R03 (128 bp) und R04 (64 bp), mit Seed-Ensemble von 01 als Kontrolle.

Reine Auswertung vorhandener Testvorhersagen, kein Training. Je TF und Richtung (CG, CC, GG, GC):
  Ensemble      = gleich gewichtetes Mittel der Perzentilränge der Mitglieder (wie Idee B in diagnose_x01),
                  daraus AUPRC und AUROC. Nichts wird auf den Testdaten abgestimmt.
  Mitglieder    = R01, R03, R04 (Seed 13); alle drei Zweier zusätzlich.
  Kontrolle     = 01 mit Seed 13 (R05), 14 und 15 (R08), ausgewertet mit denselben Crops wie R01.
Vergleiche je Richtung und Maß, über die TFs: Mittel und Median der Differenz, besser/schlechter, Wilcoxon.
  a) Ensemble − Mittel seiner Mitglieder (reiner Ensemble-Gewinn), auch für die Seed-Ensembles
  b) Ensemble − bestes Mitglied (je Richtung und Maß fest: höchstes Mittel über die TFs)
  c) Ensemble − R01
  d) Längen-Gewinn − Seed-Gewinn je TF. Kontrolle für den Dreier ist das Seed-Ensemble aus drei Seeds, für die
     Zweier das Mittel der drei Seed-Zweier. Zwei Fassungen:
       d) gegen das Mittel:        Längen-Gewinn wie a)  − Seed-Gewinn wie a)
       d) gegen das beste Mitglied: Längen-Gewinn wie b)  − Seed-Gewinn wie a)
     Auf der Seed-Seite steht in beiden Fassungen das Mittel der Seeds: Seeds sind austauschbar, ein auf den
     Testdaten gewählter "bester" Seed wäre Rauschen und würde d) zugunsten der Längen verschieben.
Vor dem Mitteln wird geprüft, dass alle sechs Modelle abgeschlossen sind, dieselben Testdaten, exakt dieselben
Sequenzen mit denselben Labels, die erwarteten Crops (Summit +8/0/−1/−8 bp von der gelesenen Mitte) und die
erwarteten Checkpoints haben. Sonst Abbruch mit "Error" und ohne Ergebnisdateien.

Aufruf im Ordner diagnose_r_ensemble:  python ensemble_auswerten.py   (als CPU-Job über einplanen.sh)
Liest nur aus big_ablation und schreibt nur nach ergebnisse/; bestehende Ergebnisse werden nie überschrieben.
"""
from __future__ import annotations

import csv
import json
import math
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HIER = Path(__file__).resolve().parent
PROJEKT = Path(os.environ.get("ENSEMBLE_PROJEKT", HIER.parent / "big_ablation")).resolve()
ERGEBNISSE = Path(os.environ.get("ENSEMBLE_ERGEBNISSE", HIER / "ergebnisse")).resolve()

SEED_CONFIG = "R08_01_eval_range8_seed14_15_middle"
# Schlüssel -> (Experiment, Seed, Quelle des Checkpoints oder None bei eigenem Training)
MODELLE = {
    "R01": ("R01_A33_eval_range_middle", 13, None),
    "R03": ("R03_R01_crop128_middle", 13, None),
    "R04": ("R04_R01_crop64_middle", 13, None),
    "01s13": ("R05_01_eval_range8_middle", 13, "01_basic_0p1cdo"),
    "01s14": (SEED_CONFIG, 14, "01_basic_0p1cdo_seed14"),
    "01s15": (SEED_CONFIG, 15, "01_basic_0p1cdo_seed15"),
}
# Erwartete Crop-Starts: Summit (Position 150 im 301-bp-Fenster) liegt +8/0/−1/−8 bp von der gelesenen Mitte
CROPS = {"R01": (14, 22, 23, 30), "R03": (78, 86, 87, 94), "R04": (110, 118, 119, 126),
         "01s13": (14, 22, 23, 30), "01s14": (14, 22, 23, 30), "01s15": (14, 22, 23, 30)}
GRENZE_ABWEICHUNG = 1e-4                       # mehr als Rundung der gespeicherten Scores
DREIER, SEED_DREIER = "R01+R03+R04", "01s13+01s14+01s15"
LAENGEN = {DREIER: ("R01", "R03", "R04"), "R01+R03": ("R01", "R03"), "R01+R04": ("R01", "R04"),
           "R03+R04": ("R03", "R04")}
SEED_ZWEIER = {"01s13+01s14": ("01s13", "01s14"), "01s13+01s15": ("01s13", "01s15"),
               "01s14+01s15": ("01s14", "01s15")}
SEEDS = {SEED_DREIER: ("01s13", "01s14", "01s15"), **SEED_ZWEIER}
ENSEMBLES = {**LAENGEN, **SEEDS}
RICHTUNGEN = {"CG": ("CHIP", "GHTS"), "CC": ("CHIP", "CHIP"), "GG": ("GHTS", "GHTS"), "GC": ("GHTS", "CHIP")}
NAMEN = {"CG": "CHS→GHTS", "CC": "CHS→CHS", "GG": "GHTS→GHTS", "GC": "GHTS→CHS"}
MASSE = ("auprc", "auroc")


def lies_json(path: Path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def middle_tfs() -> list[str]:
    with (PROJEKT / "configs" / "training_priority_middle.csv").open(newline="") as handle:
        zeilen = sorted(csv.DictReader(handle), key=lambda zeile: int(zeile["priority"]))
    return list(dict.fromkeys(zeile["tf"] for zeile in zeilen))


def lies_modell(key: str, tf: str, train_assay: str, test_assay: str, crops: tuple[int, ...]):
    """(Daten, Fehler): Sample-IDs, Labels, Scores und Kennwerte einer Testauswertung."""
    import numpy as np
    experiment, seed, quelle = MODELLE[key]
    lauf = PROJEKT / "results" / experiment / "runs" / tf / f"train_{train_assay}" / f"seed_{seed:02d}"
    wo = f"{experiment} {tf}/{train_assay}→{test_assay}/Seed {seed}"
    meta = lies_json(lauf / "run.json")
    if not meta or meta.get("status") != "completed":
        return None, f"{wo}: kein abgeschlossener Lauf ({lauf})"
    if quelle is not None and (meta.get("checkpoint_source") or {}).get("source_config") != quelle:
        return None, f"{wo}: Checkpoint nicht aus {quelle}"
    ordner = lauf / "evaluations" / "standard" / test_assay
    metrics = lies_json(ordner / "metrics.json")
    if not metrics or metrics.get("status") != "completed":
        return None, f"{wo}: keine abgeschlossene Testauswertung ({ordner})"
    if (metrics.get("tf"), metrics.get("train_assay"), metrics.get("test_assay"), metrics.get("seed")) != (
            tf, train_assay, test_assay, seed):
        return None, f"{wo}: metrics.json gehört zu einem anderen Lauf"
    ansicht = metrics.get("inference_config") or {}
    if tuple(ansicht.get("crop_starts") or ()) != crops or ansicht.get("reverse_complement") is not True:
        return None, (f"{wo}: Crops {ansicht.get('crop_starts')} (RC {ansicht.get('reverse_complement')}), "
                      f"erwartet {list(crops)} mit RC")
    try:
        with (ordner / "predictions.tsv").open(newline="") as handle:
            reader = csv.reader(handle, delimiter="\t")
            kopf = next(reader)
            i_id, i_label, i_score = (kopf.index(k) for k in ("sample_id", "true_label", "binding_probability"))
            ids, labels, scores = [], [], []
            for zeile in reader:
                ids.append(zeile[i_id])
                labels.append(zeile[i_label])
                scores.append(zeile[i_score])
        labels = np.array(labels, dtype=np.int8)
        scores = np.array(scores, dtype=np.float64)
    except (OSError, ValueError, StopIteration, IndexError) as fehler:
        return None, f"{wo}: predictions.tsv unlesbar ({fehler})"
    if not np.isfinite(scores).all():
        return None, f"{wo}: nicht-endliche Scores in predictions.tsv"
    if not np.isin(labels, (0, 1)).all() or labels.size == 0 or labels.min() == labels.max():
        return None, f"{wo}: Labels nicht 0/1 oder nur eine Klasse"
    test_metrics = metrics.get("test_metrics") or {}
    return {"ids": np.array(ids), "labels": labels, "scores": scores,
            "test_cache": metrics.get("test_cache_sha256"), "checkpoint": metrics.get("checkpoint_sha256"),
            "aggregation": ansicht.get("aggregation"),
            "gespeichert": {m: test_metrics.get(m) for m in MASSE}}, ""


def perzentil_raenge(scores):
    """Perzentil-Ränge von 0 bis 1, Mittelrang bei Gleichstand (wie diagnose_x01)."""
    from scipy.stats import rankdata
    n = len(scores)
    return (rankdata(scores, method="average") - 1.0) / (n - 1.0) if n > 1 else scores * 0.0


def werte_richtung(tf: str, richtung: str, crops: dict) -> tuple[dict | None, list[str], dict]:
    """Prüft die sechs Modelle einer TF/Richtung und rechnet Einzel- und Ensemblewerte."""
    import numpy as np
    from sklearn.metrics import average_precision_score, roc_auc_score
    train_assay, test_assay = RICHTUNGEN[richtung]
    daten, fehler = {}, []
    for key in MODELLE:
        d, grund = lies_modell(key, tf, train_assay, test_assay, crops[key])
        if d is None:
            fehler.append(grund)
        else:
            daten[key] = d
    if fehler:
        return None, fehler, {}
    wo = f"{tf} {NAMEN[richtung]}"
    if len({d["test_cache"] for d in daten.values()}) != 1 or not daten["R01"]["test_cache"]:
        fehler.append(f"{wo}: verschiedene Testdaten (test_cache_sha256: "
                      + ", ".join(f"{k} {str(d['test_cache'])[:12]}" for k, d in daten.items()) + ")")
    if len({d["aggregation"] for d in daten.values()}) != 1:
        fehler.append(f"{wo}: verschiedene Aggregation der Ansichten")
    if len({d["checkpoint"] for d in daten.values()}) != len(daten):
        fehler.append(f"{wo}: zwei Modelle mit demselben Checkpoint")
    # exakt dieselben Sequenzen mit denselben Labels: Vergleich nach Sample-ID sortiert (Reihenfolge egal)
    reihenfolge = {"R01": np.argsort(daten["R01"]["ids"], kind="stable")}
    ref_ids, ref_labels = daten["R01"]["ids"][reihenfolge["R01"]], daten["R01"]["labels"][reihenfolge["R01"]]
    for key, d in daten.items():
        if key == "R01":
            continue
        if d["ids"].shape == daten["R01"]["ids"].shape and np.array_equal(d["ids"], daten["R01"]["ids"]):
            reihenfolge[key] = reihenfolge["R01"]           # gleiche Zeilenfolge wie R01
        else:
            reihenfolge[key] = np.argsort(d["ids"], kind="stable")
        ids, labels = d["ids"][reihenfolge[key]], d["labels"][reihenfolge[key]]
        if ids.shape != ref_ids.shape or not np.array_equal(ids, ref_ids):
            fehler.append(f"{wo}: {key} und R01 haben verschiedene Sequenzen ({ids.size} gegen {ref_ids.size} Zeilen)")
        elif not np.array_equal(labels, ref_labels):
            fehler.append(f"{wo}: {key} hat bei {int((labels != ref_labels).sum())} Sequenzen andere Labels als R01")
        d["ids"] = None                                     # Speicher: nur die Referenz-IDs bleiben
    if fehler:
        return None, fehler, {}
    raenge = {key: perzentil_raenge(daten[key]["scores"][reihenfolge[key]]) for key in daten}
    labels = ref_labels
    zeile = {"tf": tf, "richtung": richtung, "n": int(labels.size), "n_pos": int(labels.sum()),
             "doppelte_ids": int((ref_ids[1:] == ref_ids[:-1]).sum())}
    abweichung = {}
    for key, rang in raenge.items():
        zeile[f"auprc_{key}"] = float(average_precision_score(labels, rang))
        zeile[f"auroc_{key}"] = float(roc_auc_score(labels, rang))
        for mass in MASSE:
            gespeichert = daten[key]["gespeichert"].get(mass)
            if isinstance(gespeichert, (int, float)) and math.isfinite(gespeichert):
                abweichung[f"{key} {mass}"] = abs(zeile[f"{mass}_{key}"] - float(gespeichert))
    for name, mitglieder in ENSEMBLES.items():
        mittel_rang = np.mean([raenge[m] for m in mitglieder], axis=0)
        zeile[f"auprc_{name}"] = float(average_precision_score(labels, mittel_rang))
        zeile[f"auroc_{name}"] = float(roc_auc_score(labels, mittel_rang))
    return zeile, [], abweichung


def wilcoxon_zeile(differenzen) -> dict:
    """Gepaarter Wilcoxon über TFs wie in diagnose_x01: zweiseitig, SciPy-Standard.

    * bei p < 0,05, ~ bei p < 0,25, jeweils nur, wenn Mittel und Median dasselbe Vorzeichen haben."""
    import numpy as np
    from scipy.stats import wilcoxon
    d = np.asarray([x for x in differenzen if math.isfinite(x)], dtype=float)
    zeile = {"n_tfs": int(d.size), "mittel": math.nan, "median": math.nan,
             "besser": int((d > 0).sum()), "schlechter": int((d < 0).sum()), "p": math.nan, "marke": ""}
    if d.size == 0:
        return zeile
    zeile["mittel"], zeile["median"] = float(d.mean()), float(np.median(d))
    if d.size >= 2 and np.any(d != 0):
        try:
            zeile["p"] = float(wilcoxon(d).pvalue)
        except ValueError:
            pass
    gleich = np.sign(zeile["mittel"]) == np.sign(zeile["median"]) and zeile["median"] != 0
    if gleich and math.isfinite(zeile["p"]):
        zeile["marke"] = "*" if zeile["p"] < 0.05 else "~" if zeile["p"] < 0.25 else ""
    return zeile


def schreibe_csv(path: Path, zeilen: list[dict]) -> None:
    felder = list(dict.fromkeys(k for zeile in zeilen for k in zeile))
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=felder, extrasaction="ignore")
        writer.writeheader()
        for zeile in zeilen:
            writer.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v) for k, v in zeile.items()})


def vergleiche(zeilen: list[dict]) -> dict[str, list[dict]]:
    """Alle Vergleichstabellen; je Zeile Richtung, Maß, Ensemble, Bezug und die Kennzahlen über die TFs."""
    import numpy as np
    tabellen = {"gewinn": [], "bestes_mitglied": [], "r01": [], "laenge_gegen_seed": [],
                "laenge_gegen_seed_bestes": []}
    for richtung in RICHTUNGEN:
        sel = [z for z in zeilen if z["richtung"] == richtung]
        for mass in MASSE:
            wert = lambda z, k: z[f"{mass}_{k}"]
            mittel = lambda k: float(np.mean([wert(z, k) for z in sel]))
            bester = {name: max(mitglieder, key=mittel) for name, mitglieder in ENSEMBLES.items()}
            gewinn = {name: [wert(z, name) - float(np.mean([wert(z, m) for m in ENSEMBLES[name]])) for z in sel]
                      for name in ENSEMBLES}
            ueber_besten = {name: [wert(z, name) - wert(z, bester[name]) for z in sel] for name in ENSEMBLES}
            kopf = lambda name: {"richtung": NAMEN[richtung], "mass": mass.upper(), "ensemble": name,
                                 "art": "Länge" if name in LAENGEN else "Seed (Kontrolle)"}
            for name, mitglieder in ENSEMBLES.items():
                tabellen["gewinn"].append({**kopf(name), "mitglieder": "+".join(mitglieder),
                                           "mittel_ensemble": mittel(name),
                                           "mittel_mitglieder": float(np.mean([mittel(m) for m in mitglieder])),
                                           **wilcoxon_zeile(gewinn[name])})
                tabellen["bestes_mitglied"].append({**kopf(name), "bestes_mitglied": bester[name],
                                                    "mittel_ensemble": mittel(name),
                                                    "mittel_bestes": mittel(bester[name]),
                                                    **wilcoxon_zeile(ueber_besten[name])})
            for name in LAENGEN:
                tabellen["r01"].append({**kopf(name), "mittel_ensemble": mittel(name), "mittel_r01": mittel("R01"),
                                        **wilcoxon_zeile([wert(z, name) - wert(z, "R01") for z in sel])})
            # Seed-Seite in beiden Fassungen: Gewinn gegen das Mittel der Seeds (austauschbar, keine Auswahl)
            seed_gewinn = {DREIER: gewinn[SEED_DREIER]}
            paare = [float(np.mean([gewinn[s][i] for s in SEED_ZWEIER])) for i in range(len(sel))]
            for tabelle, laenge in (("laenge_gegen_seed", gewinn), ("laenge_gegen_seed_bestes", ueber_besten)):
                for name in LAENGEN:
                    seed = seed_gewinn.get(name, paare)
                    zeile = {**kopf(name), "kontrolle": SEED_DREIER if name == DREIER else "Mittel der drei Seed-Zweier",
                             "laenge_bezug": "Mittel der Mitglieder" if tabelle == "laenge_gegen_seed" else
                             f"bestes Mitglied ({bester[name]})", "seed_bezug": "Mittel der Seeds",
                             "mittel_gewinn_laenge": float(np.mean(laenge[name])), "mittel_gewinn_seed": float(np.mean(seed))}
                    zeile.update(wilcoxon_zeile([a - b for a, b in zip(laenge[name], seed)]))
                    tabellen[tabelle].append(zeile)
    return tabellen


def zusammenfassung(zeilen, tabellen, abweichung, doppelt) -> list[str]:
    finde = lambda tabelle, richtung, mass, name: next(
        z for z in tabellen[tabelle] if z["richtung"] == NAMEN[richtung] and z["mass"] == mass and z["ensemble"] == name)

    def kurz(z):
        p = f"p {z['p']:.3g}" if math.isfinite(z["p"]) else "p –"
        return (f"{z['mittel']:+.4f} (Median {z['median']:+.4f}, besser/schlechter {z['besser']}/{z['schlechter']}, "
                f"{p}{' ' + z['marke'] if z['marke'] else ''})")

    n_tfs = len({z["tf"] for z in zeilen})
    text = [f"Längen-Ensemble R01 (256 bp) + R03 (128 bp) + R04 (64 bp), Seed 13, Split v1, {n_tfs} Middle-TFs",
            "Kontrolle: Seed-Ensemble 01 mit Seed 13 (R05), 14 und 15 (R08), dieselben Crops wie R01.",
            "Kombination: Perzentilränge je TF und Richtung, gleich gewichtet gemittelt (Idee B aus diagnose_x01).",
            "Je Vergleich: Mittel der Differenz über die TFs (Median), besser/schlechter, Wilcoxon gepaart",
            "zweiseitig; * p < 0,05, ~ p < 0,25, nur bei gleichem Vorzeichen von Mittel und Median.", "",
            "Kurz (AUPRC):"]
    cg_b, cc_b = finde("bestes_mitglied", "CG", "AUPRC", DREIER), finde("bestes_mitglied", "CC", "AUPRC", DREIER)
    text += [f"  Schlägt das Ensemble in CHS→GHTS das beste Einzelmodell ({cg_b['bestes_mitglied']})? {kurz(cg_b)}",
             f"  Was kostet es in CHS→CHS gegenüber dem besten Einzelmodell ({cc_b['bestes_mitglied']})? {kurz(cc_b)}",
             "  Ergänzen sich die Längen über das reine Mitteln hinaus (Längen-Gewinn minus Seed-Gewinn)?"]
    for richtung in RICHTUNGEN:
        a = finde("laenge_gegen_seed", richtung, "AUPRC", DREIER)
        b = finde("laenge_gegen_seed_bestes", richtung, "AUPRC", DREIER)
        text.append(f"    {NAMEN[richtung]}: gegen das Mittel der Mitglieder {kurz(a)}")
        text.append(f"    {' ' * len(NAMEN[richtung])}  gegen das beste Mitglied     {kurz(b)}")
    text.append("")
    for richtung in RICHTUNGEN:
        sel = [z for z in zeilen if z["richtung"] == richtung]
        text.append(f"{NAMEN[richtung]} ({len(sel)} TFs)")
        for mass in ("AUPRC", "AUROC"):
            m = lambda k: sum(z[f"{mass.lower()}_{k}"] for z in sel) / len(sel)
            text.append(f"  {mass} im Mittel: R01 {m('R01'):.4f}, R03 {m('R03'):.4f}, R04 {m('R04'):.4f}, "
                        f"Ensemble {m(DREIER):.4f} | Seeds {m('01s13'):.4f}/{m('01s14'):.4f}/{m('01s15'):.4f}, "
                        f"Seed-Ensemble {m(SEED_DREIER):.4f}")
            g, s = finde("gewinn", richtung, mass, DREIER), finde("gewinn", richtung, mass, SEED_DREIER)
            b, r = finde("bestes_mitglied", richtung, mass, DREIER), finde("r01", richtung, mass, DREIER)
            d1 = finde("laenge_gegen_seed", richtung, mass, DREIER)
            d2 = finde("laenge_gegen_seed_bestes", richtung, mass, DREIER)
            text += [f"    a) Gewinn gegen das Mittel der Mitglieder: Längen {kurz(g)}",
                     f"                                            Seeds  {kurz(s)}",
                     f"    b) Ensemble gegen bestes Mitglied ({b['bestes_mitglied']}): {kurz(b)}",
                     f"    c) Ensemble gegen R01: {kurz(r)}",
                     f"    d) Längen- minus Seed-Gewinn, gegen das Mittel: {kurz(d1)}",
                     f"       Längen- minus Seed-Gewinn, gegen das beste Mitglied: {kurz(d2)}"]
        zweier = [f"{name} {finde('bestes_mitglied', richtung, 'AUPRC', name)['mittel']:+.4f}"
                  for name in LAENGEN if name != DREIER]
        text += ["  Zweier, beschreibend (AUPRC gegen das bessere Mitglied): " + ", ".join(zweier), ""]
    groesste = max(abweichung.values(), default=0.0)
    auffaellig = sorted(((v, k) for k, v in abweichung.items() if v > GRENZE_ABWEICHUNG), reverse=True)
    text += ["Lesart: d) gegen das Mittel zeigt, ob sich die Längen stärker ergänzen als Seeds. Belastbar ist ein",
             "positiver Befund dort, wo die Mitglieder ähnlich gut sind; R01, R03 und R04 teilen zudem Seed 13, ein",
             "Nullbefund ist deshalb nur eingeschränkt aussagekräftig. Ob sich das Ensemble lohnt, zeigen b) und d)",
             "gegen das beste Mitglied, vor allem wo die Mitglieder ungleich gut sind. Das beste Mitglied wird auf",
             "denselben Testdaten bestimmt; das begünstigt das Einzelmodell, beide Vergleiche sind also eher streng.",
             "Auf der Seed-Seite von d) steht immer das Mittel der Seeds: Seeds sind austauschbar, ein auf den",
             "Testdaten gewählter bester Seed wäre Rauschen und würde d) zugunsten der Längen verschieben.",
             "Hauptaussagen: der Dreier in CHS→GHTS und CHS→CHS sowie d) für den Dreier; die Zweier sind",
             "beschreibend (viele Tests).", "",
             "Kontrolle: Alle sechs Modelle haben je TF und Richtung dieselben Testdaten, exakt dieselben Sequenzen",
             "mit denselben Labels und die erwarteten Crops und Checkpoints.",
             f"Die aus predictions.tsv neu berechneten Einzelwerte weichen höchstens um {groesste:.1e} von metrics.json ab"
             + (" (Rundung der gespeicherten Scores)." if not auffaellig else
                f". ACHTUNG: {len(auffaellig)} Abweichung(en) über {GRENZE_ABWEICHUNG:.0e}, mehr als Rundung; Vorhersagen "
                "und metrics.json prüfen: " + "; ".join(f"{k} {v:.1e}" for v, k in auffaellig[:5])),
             f"Doppelte Sample-IDs im Testsatz: {doppelt if doppelt else 'keine'}."]
    return text


def main() -> int:
    if ERGEBNISSE.exists() and (not ERGEBNISSE.is_dir() or any(ERGEBNISSE.iterdir())):
        print(f"Error: {ERGEBNISSE} enthält schon Ergebnisse; nichts überschrieben. Den Ordner umbenennen, dann neu "
              "starten.", file=sys.stderr)
        return 1
    print("Erwartete Crops: " + ", ".join(f"{k} {list(v)}" for k, v in CROPS.items()), flush=True)
    zeilen, fehler, abweichung = [], [], {}
    for tf in middle_tfs():
        vorher = len(fehler)
        for richtung in RICHTUNGEN:
            zeile, probleme, abw = werte_richtung(tf, richtung, CROPS)
            fehler += probleme
            if zeile is not None:
                zeilen.append(zeile)
                abweichung.update({f"{tf} {richtung} {k}": v for k, v in abw.items()})
        print(f"{tf}: " + (f"{len(fehler) - vorher} Befund(e)" if len(fehler) > vorher else "geprüft"), flush=True)
    if fehler:
        print(f"Error: {len(fehler)} Befund(e); kein Ensemble gerechnet, nichts geschrieben.", file=sys.stderr)
        for meldung in fehler:
            print(f"Error: {meldung}", file=sys.stderr)
        return 1
    tabellen = vergleiche(zeilen)
    doppelt = sum(z["doppelte_ids"] for z in zeilen)
    text = zusammenfassung(zeilen, tabellen, abweichung, doppelt)
    zwischen = ERGEBNISSE.parent / f".{ERGEBNISSE.name}_entsteht_{os.getpid()}"
    zwischen.mkdir(parents=True)
    schreibe_csv(zwischen / "pro_tf.csv", zeilen)
    for name, tabelle in tabellen.items():
        schreibe_csv(zwischen / f"vergleich_{name}.csv", tabelle)
    (zwischen / "zusammenfassung.txt").write_text("\n".join(text) + "\n")
    if ERGEBNISSE.exists():
        if any(ERGEBNISSE.iterdir()):          # in der Zwischenzeit entstanden: nicht überschreiben
            print(f"Error: {ERGEBNISSE} ist inzwischen belegt; Ergebnisse liegen in {zwischen}.", file=sys.stderr)
            return 1
        ERGEBNISSE.rmdir()
    zwischen.rename(ERGEBNISSE)
    print("\n".join(text))
    print(f"\nErgebnisse: {ERGEBNISSE}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
