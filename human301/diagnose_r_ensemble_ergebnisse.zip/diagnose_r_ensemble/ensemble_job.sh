#!/usr/bin/env bash
# CPU-Job für das Längen-Ensemble; einplanen.sh reicht ihn mit Wartebedingung (afterany) auf R08 ein.
set -euo pipefail
cd "$ENSEMBLE_ORDNER"
PY="${CONDA_PREFIX:+$CONDA_PREFIX/bin/python}"
PY="${PY:-$(command -v python3)}"
echo "Längen-Ensemble als $(id -un) auf $(hostname) mit $PY, Job $SLURM_JOB_ID, $(date)"
"$PY" ensemble_auswerten.py
echo "Ende $(date)"
