#!/usr/bin/env python3
"""Abweichung eines einzelnen Laufs vermerken; sie erscheint in der Spalte "abweichung" der Ergebnisdatei.

    python ergebnisteil/abweichung_eintragen.py CONFIG TF ASSAY SEED "Text"
    z. B.  python ergebnisteil/abweichung_eintragen.py K4_A14_se_mean_middle LEF1 CHS 13 "Wiederholung nach NaN-Abbruch"

Schreibt (oder ergänzt) big_ablation/results/<CONFIG>/abweichungen.json. Steht der Sammeljob der Config nicht mehr
in der Queue, wird die Ergebnisdatei gleich neu gesammelt; sonst übernimmt das der Sammeljob. Gefüllt werden die
Lauf- und Auswertungszeilen des ausgewählten Laufs dieser TF/Assay/Seed-Kombination, sonst bleibt die Spalte leer.
Experimente ohne Vermerk behalten ihre Ergebnisdatei unverändert. Wirkt mit dem Code ab dem K11-Update.
"""
from __future__ import annotations

import getpass
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

H301 = Path(__file__).resolve().parent.parent
BA = H301 / "big_ablation"


def main() -> int:
    if len(sys.argv) != 6:
        print(__doc__.split("\n\n")[1], file=sys.stderr)
        return 2
    config, tf, assay, seed, text = sys.argv[1:]
    assay = {"CHS": "CHIP"}.get(assay.upper(), assay.upper())
    experiment = BA / "results" / config
    lauf = experiment / "runs" / tf / f"train_{assay}" / f"seed_{int(seed):02d}"
    if not (BA / "configs" / f"{config}.json").is_file() or not experiment.is_dir():
        print(f"Error: Config oder Ergebnisordner {config} nicht gefunden", file=sys.stderr)
        return 1
    if assay not in ("CHIP", "GHTS") or not (experiment / "runs" / tf).is_dir():
        print(f"Error: {tf} {assay} kommt in {config} nicht vor (Assay CHIP/CHS oder GHTS; TF wie im Ordner runs/)",
              file=sys.stderr)
        return 1
    if not lauf.is_dir():
        print(f"Hinweis: {lauf} gibt es (noch) nicht; der Vermerk gilt, sobald der Lauf dort liegt.")
    pfad = experiment / "abweichungen.json"
    stand = json.loads(pfad.read_text()) if pfad.is_file() else {"abweichungen": []}
    eintraege = [e for e in stand["abweichungen"]
                 if (e["tf"], e["train_assay"], str(e["seed"])) != (tf, assay, str(int(seed)))]
    eintraege.append({"tf": tf, "train_assay": assay, "seed": int(seed), "text": text})
    maske = os.umask(0)
    os.umask(maske)
    fd, tmp = tempfile.mkstemp(prefix="abweichungen.", dir=experiment)
    os.fchmod(fd, 0o666 & ~maske)          # Rechte wie eine normal angelegte Datei (mkstemp setzt sonst 0600)
    with os.fdopen(fd, "w") as handle:
        json.dump({"abweichungen": eintraege}, handle, indent=1, ensure_ascii=False)
        handle.write("\n")
    os.replace(tmp, pfad)
    print(f"Vermerkt in {pfad}: {tf} {assay} Seed {int(seed)}: {text}")
    queue = subprocess.run(["squeue", "-h", "-u", getpass.getuser(), "-o", "%j"], capture_output=True, text=True)
    if queue.returncode:
        print(f"Error: squeue gescheitert ({queue.stderr.strip()}); Vermerk gespeichert, Ergebnisdatei nicht neu "
              "gesammelt", file=sys.stderr)
        return 1
    if f"h301_collect_{config}" in queue.stdout.split():
        print("Der Sammeljob dieser Config steht noch in der Queue; er übernimmt den Vermerk.")
        return 0
    sammeln = subprocess.run([sys.executable, str(BA / "run_experiment.py"), "collect", "--config", config],
                             cwd=BA, capture_output=True, text=True)
    if sammeln.stdout.strip():
        print(sammeln.stdout.strip()[-600:])
    if sammeln.returncode:
        print(sammeln.stderr.strip()[-1200:], file=sys.stderr)
        print("Error: Neu-Sammeln gescheitert (Ausgabe oben); der Vermerk ist gespeichert.", file=sys.stderr)
        if "mix code/config versions" in sammeln.stderr and not (BA / "certified_code").is_dir():
            print("Ursache: certified_code/ wurde mit Teil 2 von aufraeumen.sh entfernt. Dann einmal mit "
                  "ABLATION_ALLOW_CODE_VERSION_MISMATCH=1 vor demselben Aufruf wiederholen.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
