#!/usr/bin/env python3
"""Kontrolle zu K11: Ist der Verlauf der ungemittelten Gewichte bit-gleich zu K5?

Das EMA liest nur mit. Deshalb muss der Trainings-Loss jeder Epoche von K11 dem von K5 entsprechen, solange beide
Läufe trainieren (K11 kann wegen der Auswahl über das EMA früher oder später stoppen). Verglichen wird je TF und
Trainingsassay (Seed 13) der Trainings-Loss jeder Epoche aus training/history.json.

    python ergebnisteil/k11_kontrolle.py      # im Ordner human301; liest nur, schreibt nach ergebnisteil/k11_kontrolle/

Maßstab: Zwei GPU-Läufe desselben Codes müssen nicht bit-gleich sein (andere GPU-Typen, nichtdeterministische
Rückwärtsschritte, etwa in der Attention). Deshalb vergleicht das Script zusätzlich die Wiederholungen der
NaN-Diagnose (Punkt 6) mit ihren Originalen: gleicher Code, gleicher Seed, nur ein zweiter Lauf. Weicht schon diese
Wiederholung ab, sind Abweichungen K11 gegen K5 derselben Größenordnung Rechenrauschen und kein Effekt des EMA.

Ausgabe: verlauf_gegen_k5.csv, wiederholung_gegen_original.csv und zusammenfassung.txt.
"""
from __future__ import annotations

import csv
import json
import math
import os
import re
import sys
from pathlib import Path

HIER = Path(__file__).resolve().parent
BA = HIER.parent / "big_ablation"
AUS = HIER / "k11_kontrolle"
DIAGNOSE = Path(os.environ.get("DIAG_AUSGABE", HIER / "diagnose_nan")).resolve()
K5, K11 = "K5_A14_readout_lse16_se_mean_middle", "K11_K5_ema2_middle"


def verlauf(pfad: Path) -> list[float]:
    zeilen = json.loads(pfad.read_text())
    werte = []
    for zeile in zeilen:
        loss = zeile.get("train", {}).get("loss")
        loss = loss.get("total") if isinstance(loss, dict) else loss
        if loss is None:
            raise ValueError(f"kein Trainings-Loss in Epoche {zeile.get('epoch')}")
        werte.append(float(loss))
    return werte


def vergleich(a: list[float], b: list[float]) -> dict:
    """b ist die Referenz. Beidseitig NaN gilt als gleich; einseitiges NaN wird eigens ausgewiesen."""
    erste = nan_ab = None
    absolut = relativ = 0.0
    for epoche, (x, y) in enumerate(zip(a, b), start=1):
        if x == y or (math.isnan(x) and math.isnan(y)):
            continue
        erste = erste or epoche
        if math.isnan(x) or math.isnan(y):
            nan_ab = nan_ab or epoche
            continue
        absolut = max(absolut, abs(x - y))
        relativ = max(relativ, abs(x - y) / max(abs(y), 1e-12))
    return {"verglichen": min(len(a), len(b)), "bit_gleich": erste is None, "erste_abweichende_epoche": erste or "",
            "groesste_abweichung": absolut, "groesste_relative_abweichung": relativ, "nan_nur_einseitig_ab_epoche": nan_ab or ""}


def knoten(ordner: Path) -> str:
    try:
        return json.loads((ordner / "run.json").read_text()).get("hostname", "")
    except (OSError, ValueError):
        return ""


def schreiben(name: str, zeilen: list[dict]) -> None:
    if zeilen:
        with (AUS / name).open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(zeilen[0]))
            writer.writeheader()
            writer.writerows(zeilen)


def beschreibung(z: dict) -> str:
    teile = [f"ab Epoche {z['erste_abweichende_epoche']}"]
    if z["groesste_abweichung"]:
        teile.append(f"größte Abweichung {z['groesste_abweichung']:.3g} (relativ {z['groesste_relative_abweichung']:.2g})")
    if z["nan_nur_einseitig_ab_epoche"]:
        teile.append(f"NaN nur in einem der Läufe ab Epoche {z['nan_nur_einseitig_ab_epoche']}")
    return ", ".join(teile)


def main() -> int:
    zeilen, fehler = [], []
    k11_runs = BA / "results" / K11 / "runs"
    for lauf in sorted(k11_runs.glob("*/train_*/seed_13")):
        rel = lauf.relative_to(k11_runs)
        k5 = BA / "results" / K5 / "runs" / rel
        try:
            a, b = verlauf(lauf / "training" / "history.json"), verlauf(k5 / "training" / "history.json")
        except (OSError, ValueError) as grund:
            fehler.append(f"{rel.parts[0]}/{rel.parts[1].removeprefix('train_')}: {grund}")
            continue
        zeilen.append({"tf": rel.parts[0], "train_assay": rel.parts[1].removeprefix("train_"),
                       "epochen_k5": len(b), "epochen_k11": len(a), **vergleich(a, b),
                       "knoten_k5": knoten(k5), "knoten_k11": knoten(lauf)})
    if not zeilen:
        print("Error: keine vergleichbaren K11-Läufe gefunden" + (f" ({fehler[0]})" if fehler else ""), file=sys.stderr)
        return 1

    basis = []
    for original in sorted((DIAGNOSE / "spuren").glob("*/training/history.json")):
        fall = original.parent.parent.name
        muster = re.compile(re.escape(fall) + r"_\d{8}_\d{6}")
        kandidaten = sorted(p for p in (DIAGNOSE / "wiederholung").glob(f"{fall}_*/training/history.json")
                            if muster.fullmatch(p.parent.parent.name))
        if not kandidaten:
            continue
        try:
            a, b = verlauf(kandidaten[-1]), verlauf(original)
        except (OSError, ValueError) as grund:
            fehler.append(f"Wiederholung {fall}: {grund}")
            continue
        basis.append({"fall": fall, "epochen_original": len(b), "epochen_wiederholung": len(a), **vergleich(a, b)})

    AUS.mkdir(exist_ok=True)
    schreiben("verlauf_gegen_k5.csv", zeilen)
    schreiben("wiederholung_gegen_original.csv", basis)
    gleich = sum(z["bit_gleich"] for z in zeilen)
    text = [f"K11 gegen K5, Trainings-Loss je Epoche: {gleich} von {len(zeilen)} Läufen bit-gleich."]
    abweichend = sorted((z for z in zeilen if not z["bit_gleich"]), key=lambda z: -z["groesste_relative_abweichung"])
    for z in abweichend[:20]:
        text.append(f"  {z['tf']}/{z['train_assay']}: {beschreibung(z)}; Knoten K5 {z['knoten_k5'] or '?'}, "
                    f"K11 {z['knoten_k11'] or '?'}")
    if len(abweichend) > 20:
        text.append(f"  … und {len(abweichend) - 20} weitere (verlauf_gegen_k5.csv)")
    text.append("Maßstab, Wiederholung desselben Laufs in der NaN-Diagnose:")
    for z in basis:
        text.append(f"  {z['fall']}: {z['verglichen']} Epochen, " + ("bit-gleich" if z["bit_gleich"] else beschreibung(z)))
    if not basis:
        text.append("  keine Wiederholung gefunden (ergebnisteil/diagnose_nan/wiederholung/).")
    for zeile in fehler:
        text.append(f"Error: nicht vergleichbar: {zeile}")
    (AUS / "zusammenfassung.txt").write_text("\n".join(text) + "\n")
    print("\n".join(text))
    return 1 if fehler else 0


if __name__ == "__main__":
    sys.exit(main())
