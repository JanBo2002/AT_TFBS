#!/usr/bin/env python3
"""Diagnose A mit gemittelter Basis: Helfen die Einzeländerungen denselben Sequenzen?

Je TF und Richtung (CC, GG, CG, GC) werden die Testscores jedes Modells in Perzentil-Ränge r(m, i) von 0 bis 1
umgerechnet (Mittelrang bei Gleichstand). Alle Größen werden getrennt für Positive und Negative berechnet.
  Basis b(i) = Mittel der Ränge von 01 mit Seed 13, 14 und 15.
  Δ(c, i) = s(i) * (r(c, i) - b(i)), s = +1 für Positive, -1 für Negative; c = eine der neun Einzeländerungen (Seed 13).
Je TF, Richtung und Klasse:
  1. Paar-Korrelation: Pearson-Korrelation von Δ(c1) und Δ(c2), alle 36 Paare.
  2. Seed-Rauschen: σ² = Var(r(01 Seed 14) - r(01 Seed 15)) / 2.
  3. Erwartung ohne Überlappung: (σ²/3) / Wurzel(Var Δ(c1) * Var Δ(c2)).
  4. Diagonale (dieselbe Änderung mit neuem Seed): (Var Δ(c) - σ²) / Var Δ(c), Werte <= 0 als 0.
  5. Erwartung bei voller Überlappung: Wurzel(Diagonale(c1) * Diagonale(c2)).
Lage = (1 - 3) / (5 - 3): 0 = keine, 1 = volle Überlappung. Ein Paar ist näher an 3, wenn Lage < 0,5. Liegen 3 und 5
weniger als 0,05 auseinander, gilt das Paar als nicht unterscheidbar.
Lesehilfe: Eine Änderung ohne eigenen Effekt hat die Diagonale etwa 0,25, nicht 0, weil Δ und ihr neu geseedeter
Zwilling dieselbe Basis teilen; zwei solche Änderungen haben 3 = 5 = 0,25. Lage über 1 heißt: stärker korreliert, als
für volle Überlappung erwartet.
Test mit bekannter Wahrheit: Die Lage trifft die echte Überlappung (0; 0,4; 0,6; 1). Verbessert eine Änderung alle
Sequenzen gleichmäßig, liegt sie etwas höher (in Rängen trifft das zuerst die Grenzfälle, für alle Änderungen dieselben).

Zusatz (nicht Teil der Vorgabe, Spalten zusatz_*): Alle Einzeländerungen laufen wie 01 Seed 13 mit Seed 13. Teilen
Läufe mit gleichem Seed einen Teil ihres Rauschens, liegen beide Bezugspunkte höher als in 3 und 5 angenommen.
  k(c) = Kov(r(c) - r(01 S14), r(01 S13) - r(01 S15)), mit S14 und S15 vertauscht gemittelt: das Rauschen, das c mit
  01 Seed 13 teilt; kappa(c) = k(c) / σ². Annahme: Zwei Einzeländerungen teilen k12 = Wurzel(k1 * k2).
  Korrigiert: 3' = 3 + (k12 - (k1 + k2) / 3) / W und 5' = 5 + k12 / W mit W = Wurzel(Var Δ(c1) * Var Δ(c2)).
  Bei kappa = 0 sind 3' und 5' gleich 3 und 5.

Aufruf im Ordner diagnose_x01:  python diag_a2_mittelbasis.py
Ergebnisse in ergebnisse/: a2_pro_tf.csv (alle TFs; dieselben Zeilen je TF in a2_pro_tf/<TF>.csv), a2_median.csv,
a2_matrix.csv (9x9 je Richtung und Klasse: Paar-Korrelation, auf der Diagonale Punkt 4), a2_zusammenfassung.txt
"""
from __future__ import annotations

import itertools
import math
import sys

import diag_gemeinsam as g

KLASSEN = {"positiv": 1, "negativ": 0}
BASIS_SEEDS = ("01s13", "01s14", "01s15")
MIN_ABSTAND = 0.05
WERTE = ("korrelation", "erwartung_keine", "diagonale_c1", "diagonale_c2", "erwartung_volle")
ZUSATZ = ("zusatz_kappa_c1", "zusatz_kappa_c2", "zusatz_erwartung_keine", "zusatz_erwartung_volle")


def endlich(x) -> bool:
    return isinstance(x, float) and math.isfinite(x)


def median(werte) -> float:
    import numpy as np
    x = np.asarray([v for v in werte if endlich(v)], dtype=float)
    return float(np.median(x)) if x.size else math.nan


def pearson(x, y) -> float:
    import numpy as np
    xc, yc = x - x.mean(), y - y.mean()
    nenner = math.sqrt(float(np.dot(xc, xc)) * float(np.dot(yc, yc)))
    return float(np.dot(xc, yc)) / nenner if nenner > 0 else math.nan


def kov(x, y) -> float:
    import numpy as np
    return float(np.mean((x - x.mean()) * (y - y.mean())))


def lage(beobachtet: float, keine: float, volle: float) -> float:
    if not all(endlich(v) for v in (beobachtet, keine, volle)) or volle - keine < MIN_ABSTAND:
        return math.nan
    return (beobachtet - keine) / (volle - keine)


def naeher(wert: float) -> str:
    return "nicht unterscheidbar" if not endlich(wert) else "keine" if wert < 0.5 else "volle"


def analyse(tf: str, richtung: str, modelle: dict, einzel: list[str]):
    import numpy as np
    labels, r, _auprc, fehlt = g.lade_richtung(tf, richtung, modelle)
    probleme = [f"{tf}/{richtung} {k}: {v}" for k, v in fehlt.items()]
    if labels is None or any(b not in r for b in BASIS_SEEDS):
        return [], probleme + [f"{tf}/{richtung}: Basis 01 Seed 13/14/15 unvollständig, nicht ausgewertet"]
    zeilen = []
    vorhanden = [c for c in einzel if c in r]
    for klasse, wert in KLASSEN.items():
        maske = labels == wert
        n = int(maske.sum())
        if n < 10:
            probleme.append(f"{tf}/{richtung}/{klasse}: zu wenige Sequenzen ({n})")
            continue
        vorzeichen = 1.0 if wert == 1 else -1.0
        r13, r14, r15 = (r[b][maske] for b in BASIS_SEEDS)
        basis = (r13 + r14 + r15) / 3.0
        sigma2 = float(np.var(r14 - r15)) / 2.0
        delta, var, diag, k = {}, {}, {}, {}
        for c in vorhanden:
            rc = r[c][maske]
            delta[c] = vorzeichen * (rc - basis)
            var[c] = float(np.var(delta[c]))
            diag[c] = max(0.0, (var[c] - sigma2) / var[c]) if var[c] > 0 else math.nan
            k[c] = 0.5 * (kov(rc - r14, r13 - r15) + kov(rc - r15, r13 - r14))
        for c1, c2 in itertools.combinations(vorhanden, 2):
            w = math.sqrt(var[c1] * var[c2]) if var[c1] > 0 and var[c2] > 0 else math.nan
            keine = (sigma2 / 3.0) / w
            volle = math.sqrt(diag[c1] * diag[c2])
            korrelation = pearson(delta[c1], delta[c2])
            k12 = math.sqrt(max(k[c1], 0.0) * max(k[c2], 0.0))
            keine13 = keine + (k12 - (k[c1] + k[c2]) / 3.0) / w
            volle13 = volle + k12 / w
            zeilen.append({
                "tf": tf, "richtung": richtung, "klasse": klasse, "n": n, "c1": c1, "c2": c2,
                "korrelation": korrelation, "sigma2": sigma2,
                "var_delta_c1": var[c1], "var_delta_c2": var[c2],
                "erwartung_keine": keine, "diagonale_c1": diag[c1], "diagonale_c2": diag[c2],
                "erwartung_volle": volle, "lage": lage(korrelation, keine, volle),
                "zusatz_kappa_c1": k[c1] / sigma2 if sigma2 > 0 else math.nan,
                "zusatz_kappa_c2": k[c2] / sigma2 if sigma2 > 0 else math.nan,
                "zusatz_erwartung_keine": keine13, "zusatz_erwartung_volle": volle13,
                "zusatz_lage": lage(korrelation, keine13, volle13)})
    return zeilen, probleme


def je_tf(zeilen: list[dict], c: str, schluessel: str) -> list[float]:
    """Ein Wert je TF für eine Änderung (Diagonale oder kappa stehen in jeder Paarzeile dieser Änderung)."""
    werte = {}
    for z in zeilen:
        if z["c1"] == c:
            werte[z["tf"]] = z[schluessel + "_c1"]
        elif z["c2"] == c:
            werte[z["tf"]] = z[schluessel + "_c2"]
    return list(werte.values())


def zaehlung(paare: list[dict], schluessel: str) -> str:
    keine = sum(1 for p in paare if p[schluessel] == "keine")
    volle = sum(1 for p in paare if p[schluessel] == "volle")
    rest = len(paare) - keine - volle
    return (f"näher an keiner Überlappung {keine}, an voller {volle}"
            + (f", nicht unterscheidbar {rest}" if rest else "") + f" von {len(paare)}")


def main() -> int:
    modelle = {k: v for k, v in g.modelle_ab().items() if k != "X01"}
    einzel = [g.kurz(e) for e in g.EINZEL]
    tfs = g.middle_tfs()
    zeilen, probleme = [], []
    for tf in tfs:
        for richtung in g.RICHTUNGEN:
            z, p = analyse(tf, richtung, modelle, einzel)
            zeilen += z
            probleme += p
        print(f"{tf}: fertig", flush=True)
    out = g.ERGEBNISSE
    g.schreibe_csv(out / "a2_pro_tf.csv", zeilen)
    for tf in dict.fromkeys(z["tf"] for z in zeilen):         # dieselben Zeilen zusätzlich als eine Datei je TF
        g.schreibe_csv(out / "a2_pro_tf" / f"{tf}.csv", [z for z in zeilen if z["tf"] == tf])

    median_zeilen, matrix = [], []
    text = ["Diagnose A mit gemittelter Basis (01 Seed 13, 14, 15)",
            "Je Paar: beobachtete Korrelation (1) gegen die Erwartung ohne Überlappung (3) und bei voller Überlappung (5),",
            "jeweils Median über die TFs. Lage = (1 - 3) / (5 - 3): 0 keine, 1 volle Überlappung; näher an 3 heißt Lage < 0,5.",
            "Nicht unterscheidbar: 3 und 5 liegen weniger als 0,05 auseinander. Lage über 1: stärker korreliert als für volle",
            "Überlappung erwartet. Eine Änderung ohne eigenen Effekt hat die Diagonale etwa 0,25 (Δ und ihr neu geseedeter",
            "Zwilling teilen dieselbe Basis).", ""]
    gesamt = {"keine": 0, "volle": 0, "lagen": [], "keine13": 0, "volle13": 0, "lagen13": []}
    for richtung in g.RICHTUNGEN:
        text.append(f"Richtung {richtung}")
        for klasse in KLASSEN:
            sel = [z for z in zeilen if z["richtung"] == richtung and z["klasse"] == klasse]
            if not sel:
                text.append(f"  {klasse}: keine auswertbaren TFs")
                continue
            paare = []
            for c1, c2 in itertools.combinations(einzel, 2):
                rows = [z for z in sel if z["c1"] == c1 and z["c2"] == c2]
                if not rows:
                    continue
                m = {key: median([z[key] for z in rows]) for key in WERTE}
                mz = {key: median([z[key] for z in rows]) for key in ZUSATZ}
                l_roh = lage(m["korrelation"], m["erwartung_keine"], m["erwartung_volle"])
                l_13 = lage(m["korrelation"], mz["zusatz_erwartung_keine"], mz["zusatz_erwartung_volle"])
                zeile = {"richtung": richtung, "klasse": klasse, "c1": c1, "c2": c2, "n_tfs": len(rows), **m,
                         "lage": l_roh, "naeher_an": naeher(l_roh), **mz,
                         "zusatz_lage": l_13, "zusatz_naeher_an": naeher(l_13)}
                median_zeilen.append(zeile)
                paare.append(zeile)
            # 9x9-Matrix: außerhalb der Diagonale die Paar-Korrelation, auf der Diagonale Punkt 4 (je Median über TFs)
            diag_med = {c: median(je_tf(sel, c, "diagonale")) for c in einzel}
            kappa_med = {c: median(je_tf(sel, c, "zusatz_kappa")) for c in einzel}
            nach_paar = {(p["c1"], p["c2"]): p["korrelation"] for p in paare}
            for c1 in einzel:
                zeile = {"richtung": richtung, "klasse": klasse, "aenderung": c1}
                for c2 in einzel:
                    zeile[c2] = diag_med[c1] if c1 == c2 else nach_paar.get(
                        tuple(sorted((c1, c2), key=einzel.index)), math.nan)
                matrix.append(zeile)
            # Zusammenfassung dieser Richtung und Klasse
            sigma2 = median(list({z["tf"]: z["sigma2"] for z in sel}.values()))
            diags = sorted((v, c) for c, v in diag_med.items() if endlich(v))
            lagen = [p["lage"] for p in paare if endlich(p["lage"])]
            groesste = max(((p["lage"], f"{p['c1']}/{p['c2']}") for p in paare if endlich(p["lage"])), default=None)
            text.append(f"  {klasse}: {zaehlung(paare, 'naeher_an')}; Lage im Median {median(lagen):.2f}"
                        + (f"; größte {groesste[1]} {groesste[0]:.2f}" if groesste else ""))
            text.append(f"    σ² {sigma2:.3g}; Diagonale " + (f"{diags[0][0]:.2f} ({diags[0][1]}) bis "
                                                            f"{diags[-1][0]:.2f} ({diags[-1][1]})" if diags else "–")
                        + f"; Zusatz Seed 13: kappa im Median {median(list(kappa_med.values())):.2f}, korrigiert "
                        + zaehlung(paare, "zusatz_naeher_an").replace(" Überlappung", ""))
            gesamt["keine"] += sum(1 for p in paare if p["naeher_an"] == "keine")
            gesamt["volle"] += sum(1 for p in paare if p["naeher_an"] == "volle")
            gesamt["lagen"] += lagen
            gesamt["keine13"] += sum(1 for p in paare if p["zusatz_naeher_an"] == "keine")
            gesamt["volle13"] += sum(1 for p in paare if p["zusatz_naeher_an"] == "volle")
            gesamt["lagen13"] += [p["zusatz_lage"] for p in paare if endlich(p["zusatz_lage"])]
        text.append("")

    def urteil(keine: int, volle: int) -> str:
        if keine + volle == 0:
            return "nicht bestimmbar"
        anteil = keine / (keine + volle)
        return ("überwiegend näher an Punkt 3, keiner Überlappung" if anteil >= 2 / 3 else
                "überwiegend näher an Punkt 5, voller Überlappung" if anteil <= 1 / 3 else "gemischt")

    text.append(f"Gesamt (alle Richtungen und Klassen): {urteil(gesamt['keine'], gesamt['volle'])} – "
                f"{gesamt['keine']} Paare näher an keiner, {gesamt['volle']} näher an voller Überlappung; "
                f"Lage im Median {median(gesamt['lagen']):.2f}.")
    text.append(f"Zusatz mit Seed-13-Korrektur: {urteil(gesamt['keine13'], gesamt['volle13'])} – "
                f"{gesamt['keine13']} zu {gesamt['volle13']}; Lage im Median {median(gesamt['lagen13']):.2f}.")
    text.append("Zusatz: kappa ist der Anteil des Seed-Rauschens, den eine Einzeländerung mit 01 Seed 13 teilt (gleicher Seed).")
    text.append("Liegt er deutlich über 0 (etwa ab 0,1), ist die korrigierte Zählung die belastbarere; bei kappa nahe 0 sind beide gleich.")
    if probleme:
        text.append(f"Nicht ausgewertet ({len(probleme)}), z. B.: " + "; ".join(probleme[:6]))
    g.schreibe_csv(out / "a2_median.csv", median_zeilen)
    g.schreibe_csv(out / "a2_matrix.csv", matrix)
    (out / "a2_zusammenfassung.txt").write_text("\n".join(text) + "\n")
    print("\n".join(text))
    return 0


if __name__ == "__main__":
    sys.exit(main())
