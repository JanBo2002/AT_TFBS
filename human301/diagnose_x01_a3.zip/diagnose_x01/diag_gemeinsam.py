"""Gemeinsame Teile der Diagnose-Analysen zu X01 (A, B, C).

Die Analysen lesen nur aus big_ablation (Configs, Caches, Läufe) und schreiben nur in diesen Ordner.
Sie liegen bewusst außerhalb von big_ablation: Neue .py-Dateien dort würden den Code-Hash laufender
Experimente verändern.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True                      # nichts in big_ablation/__pycache__ schreiben
HIER = Path(__file__).resolve().parent
PROJEKT = Path(os.environ.get("DIAG_PROJEKT", HIER.parent / "big_ablation")).resolve()
ERGEBNISSE = Path(os.environ.get("DIAG_ERGEBNISSE", HIER / "ergebnisse")).resolve()
if str(PROJEKT) not in sys.path:
    sys.path.insert(0, str(PROJEKT))

BASIS = "01_basic_0p1cdo"
EINZEL = [
    "A14_kernel_3_6_9_12_128c_do0p2_100epo",
    "A32_pwm_target03_middle",
    "B03_groupnorm_middle",
    "B04_gelu_middle",
    "B08_se_max_middle",
    "B09_bottleneck128_middle",
    "B12_stochastic_depth_0p1_middle",
    "B14_readout_lse16_middle",
    "B17_encoder_kernel3_middle",
]
KOMBI = "X01_bestA_beginnB"
SEED = 13
ASSAYS = ("CHIP", "GHTS")
KURZ_ASSAY = {"CHIP": "C", "GHTS": "G"}


def kurz(name: str) -> str:
    """Kurzname: Teil vor dem ersten Unterstrich (01, A14, ..., X01)."""
    return name.split("_", 1)[0]


def middle_tfs() -> list[str]:
    """Die 21 TFs des Middle-Sets in der Reihenfolge der Prioritätsliste (ohne torch zu laden)."""
    with (PROJEKT / "configs" / "training_priority_middle.csv").open(newline="") as handle:
        zeilen = sorted(csv.DictReader(handle), key=lambda zeile: int(zeile["priority"]))
    return list(dict.fromkeys(zeile["tf"] for zeile in zeilen))


def caches() -> dict[tuple[str, str], Path]:
    with (PROJEKT / "configs" / "caches.csv").open(newline="") as handle:
        return {(row["tf"], row["assay"]): Path(row["cache"]) for row in csv.DictReader(handle)}


def laufordner(experiment: str, tf: str, assay: str, seed: int = SEED) -> Path:
    return PROJEKT / "results" / experiment / "runs" / tf / f"train_{assay}" / f"seed_{seed:02d}"


def lies_json(path: Path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def zahl(value) -> float:
    try:
        value = float(value)
    except (TypeError, ValueError):
        return math.nan
    return value if math.isfinite(value) else math.nan


def wilcoxon_zeile(differenzen) -> dict:
    """Gepaarter Wilcoxon über TFs wie bisher: zweiseitig, SciPy-Standard (exakt ohne Nullen und Bindungen).

    * bei p < 0,05, ~ bei p < 0,25, jeweils nur, wenn Mittelwert und Median dasselbe Vorzeichen haben.
    """
    import numpy as np
    from scipy.stats import wilcoxon

    d = np.asarray([x for x in differenzen if math.isfinite(x)], dtype=float)
    zeile = {"n_tfs": int(d.size), "mittel": math.nan, "median": math.nan,
             "besser": int((d > 0).sum()), "schlechter": int((d < 0).sum()), "p": math.nan, "marke": ""}
    if d.size == 0:
        return zeile
    zeile["mittel"], zeile["median"] = float(d.mean()), float(np.median(d))
    if d.size >= 2 and np.any(d != 0):
        try:
            zeile["p"] = float(wilcoxon(d).pvalue)
        except ValueError:
            pass
    gleich = np.sign(zeile["mittel"]) == np.sign(zeile["median"]) and zeile["median"] != 0
    if gleich and math.isfinite(zeile["p"]):
        zeile["marke"] = "*" if zeile["p"] < 0.05 else "~" if zeile["p"] < 0.25 else ""
    return zeile


def schreibe_csv(path: Path, zeilen: list[dict], felder: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    felder = felder or list(dict.fromkeys(k for zeile in zeilen for k in zeile))
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=felder, extrasaction="ignore")
        writer.writeheader()
        for zeile in zeilen:
            writer.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v) for k, v in zeile.items()})


# ---------------------------------------------------------------- Testvorhersagen (für A und B)
RICHTUNGEN = {"CC": ("CHIP", "CHIP"), "GG": ("GHTS", "GHTS"), "CG": ("CHIP", "GHTS"), "GC": ("GHTS", "CHIP")}
SEED_BASEN = {14: "01_basic_0p1cdo_seed14", 15: "01_basic_0p1cdo_seed15"}


def modelle_ab() -> dict[str, tuple[str, int]]:
    """Schlüssel -> (Experiment, Seed): 01 mit Seed 13/14/15, die neun Einzeländerungen und X01 (Seed 13)."""
    modelle = {"01s13": (BASIS, SEED), "01s14": (SEED_BASEN[14], 14), "01s15": (SEED_BASEN[15], 15)}
    modelle.update({kurz(e): (e, SEED) for e in EINZEL})
    modelle["X01"] = (KOMBI, SEED)
    return modelle


def lies_vorhersagen(experiment: str, seed: int, tf: str, train_assay: str, test_assay: str):
    """(Daten, Grund): Sample-IDs, Labels, Scores und Testdaten-Prüfsumme einer Auswertung, sonst (None, Grund)."""
    import numpy as np
    lauf = laufordner(experiment, tf, train_assay, seed)
    meta = lies_json(lauf / "run.json") or {}
    if meta.get("status") != "completed":
        return None, "kein abgeschlossener Lauf"
    ordner = lauf / "evaluations" / "standard" / test_assay
    metrics = lies_json(ordner / "metrics.json") or {}
    if metrics.get("status", "completed") != "completed":
        return None, "keine abgeschlossene Testauswertung"
    try:
        with (ordner / "predictions.tsv").open(newline="") as handle:
            reader = csv.reader(handle, delimiter="\t")
            header = next(reader)
            i_id, i_label, i_score = (header.index(k) for k in ("sample_id", "true_label", "binding_probability"))
            ids, labels, scores = [], [], []
            for row in reader:
                ids.append(row[i_id]); labels.append(row[i_label]); scores.append(row[i_score])
    except (OSError, ValueError, StopIteration) as error:
        return None, f"predictions.tsv unlesbar: {error}"
    scores = np.array(scores, dtype=np.float64)
    if not np.isfinite(scores).all():
        return None, "nicht-endliche Scores in predictions.tsv"
    return {"ids": np.array(ids), "labels": np.array(labels, dtype=np.int8),
            "scores": scores, "test_cache": metrics.get("test_cache_sha256"),
            "auprc": zahl((metrics.get("test_metrics") or {}).get("auprc")),
            "config_hash": meta.get("config_hash")}, ""


def perzentil_raenge(scores):
    """Perzentil-Ränge von 0 bis 1, Mittelrang bei Gleichstand."""
    from scipy.stats import rankdata
    n = len(scores)
    return (rankdata(scores, method="average") - 1.0) / (n - 1.0) if n > 1 else scores * 0.0


def lade_richtung(tf: str, richtung: str, modelle: dict[str, tuple[str, int]]):
    """Labels und Perzentil-Ränge aller Modelle einer TF/Richtung, über die Sample-ID ausgerichtet.

    Ein Modell fällt heraus, wenn sein Lauf fehlt, seine Testdaten (test_cache_sha256) von den übrigen abweichen
    oder es andere Sequenzen enthält. Rückgabe (labels, {Schlüssel: Ränge}, {Schlüssel: gespeicherte AUPRC},
    {Schlüssel: Grund})."""
    import numpy as np
    from collections import Counter
    train_assay, test_assay = RICHTUNGEN[richtung]
    geladen, fehlt = {}, {}
    for key, (experiment, seed) in modelle.items():
        daten, grund = lies_vorhersagen(experiment, seed, tf, train_assay, test_assay)
        if daten is None:
            fehlt[key] = grund
        else:
            geladen[key] = daten
    if not geladen:
        return None, {}, {}, fehlt
    # Testdaten: Mehrheit der vorhandenen Prüfsummen; ein Lauf ohne Prüfsumme wird nur über die Sequenzen geprüft
    summen = Counter(d["test_cache"] for d in geladen.values() if d["test_cache"])
    if summen:
        referenz = summen.most_common(1)[0][0]
        for key in [k for k, d in geladen.items() if d["test_cache"] and d["test_cache"] != referenz]:
            fehlt[key] = "andere Testdaten (test_cache_sha256)"
            del geladen[key]
    if not geladen:
        return None, {}, {}, fehlt
    # Sequenzen und Labels: Referenz ist die Fassung der Mehrheit, nicht das zuerst geladene Modell
    sortiert, kennung = {}, {}
    for key, d in geladen.items():
        o = np.argsort(d["ids"], kind="stable")
        sortiert[key] = o
        kennung[key] = hashlib.sha256(d["ids"][o].astype(str).tobytes() + d["labels"][o].tobytes()).hexdigest()
    mehrheit = Counter(kennung.values()).most_common(1)[0][0]
    raenge, auprc, labels = {}, {}, None
    for key, d in geladen.items():
        if kennung[key] != mehrheit:
            fehlt[key] = "andere Sequenzen oder Labels als die übrigen Modelle"
            continue
        o = sortiert[key]
        if labels is None:
            labels = d["labels"][o]
        raenge[key] = perzentil_raenge(d["scores"][o])
        auprc[key] = d["auprc"]
    return labels, raenge, auprc, fehlt
