#!/usr/bin/env python3
"""Diagnose A, Ergänzung: Paar-Korrelationen verwandter Configs und Seed-Korrelation der 01-Läufe.

Gleiche Methode wie diag_a2_mittelbasis.py:
  Je TF und Richtung (CC, GG, CG, GC) Perzentil-Ränge r(m, i) von 0 bis 1 über alle Testsequenzen
  (Mittelrang bei Gleichstand), danach getrennt für Positive und Negative.
  Basis b(i) = Mittel der Ränge von 01 Seed 13, 14 und 15.
  Δ(c, i) = s(i) * (r(c, i) - b(i)), s = +1 für Positive, -1 für Negative.
1. Pearson-Korrelation von Δ(c1) und Δ(c2) für alle Paare der 16 Configs unten (alle Seed 13), je TF, Richtung und
   Klasse, dazu der Median über die Middle-TFs. Die Spalte gleiche_gruppe markiert Paare innerhalb einer Gruppe.
   Dazu die AUPRC je Config, TF und Richtung aus denselben Vorhersagen (plus 01 Seed 13), zum Abgleich auch der
   Wert aus metrics.json.
2. Pearson-Korrelation der Perzentil-Ränge selbst (nicht der Δ) zwischen 01 Seed 13, 14 und 15, je TF, Richtung und
   Klasse, dazu der Median über die TFs.

Aufruf im Ordner diagnose_x01:  python diag_a3_paare.py
Ergebnisse in ergebnisse/: a3_pro_tf.csv, a3_median.csv, a3_auprc.csv, a3_seeds.csv
"""
from __future__ import annotations

import itertools
import math
import sys

import diag_gemeinsam as g

GRUPPEN = {
    "Kernel": [("A14", "A14_kernel_3_6_9_12_128c_do0p2_100epo"),
               ("A45", "A45_kernel_3_5_7_9_128c_cdo0p2_100epo_middle"),
               ("A46", "A46_kernel_7_128c_cdo0p2_100epo")],
    "PWM-Ziel": [("A32_t01", "A32_pwm_target01_middle"),
                 ("A32_t03", "A32_pwm_target03_middle"),
                 ("A32_t05", "A32_pwm_target05_middle")],
    "SE": [("B08", "B08_se_max_middle"), ("B25", "B25_se_mean_middle"), ("B26", "B26_se_window16_middle")],
    "Readout": [("B14", "B14_readout_lse16_middle"), ("B22", "B22_readout_lse24_middle"),
                ("B28", "B28_readout_max16_middle")],
    "Aktivierung": [("B04", "B04_gelu_middle"), ("B05", "B05_silu_middle")],
    "Stoch. Depth": [("B12", "B12_stochastic_depth_0p1_middle"), ("B24", "B24_stochastic_depth_0p2_middle")],
}
CONFIGS = [kurz for gruppe in GRUPPEN.values() for kurz, _ in gruppe]
EXPERIMENT = {kurz: name for gruppe in GRUPPEN.values() for kurz, name in gruppe}
GRUPPE = {kurz: gname for gname, gruppe in GRUPPEN.items() for kurz, _ in gruppe}
SEEDS = {"01s13": (g.BASIS, 13), "01s14": (g.SEED_BASEN[14], 14), "01s15": (g.SEED_BASEN[15], 15)}
SEED_PAARE = (("01s13", "01s14"), ("01s13", "01s15"), ("01s14", "01s15"))
KLASSEN = {"positiv": 1, "negativ": 0}


def endlich(x) -> bool:
    return isinstance(x, float) and math.isfinite(x)


def median(werte) -> float:
    import numpy as np
    x = np.asarray([v for v in werte if endlich(v)], dtype=float)
    return float(np.median(x)) if x.size else math.nan


def pearson(x, y) -> float:
    import numpy as np
    xc, yc = x - x.mean(), y - y.mean()
    nenner = math.sqrt(float(np.dot(xc, xc)) * float(np.dot(yc, yc)))
    return float(np.dot(xc, yc)) / nenner if nenner > 0 else math.nan


def analyse(tf: str, richtung: str, modelle: dict):
    from sklearn.metrics import average_precision_score
    labels, r, gespeichert, fehlt = g.lade_richtung(tf, richtung, modelle)
    probleme = {k: v for k, v in fehlt.items()}
    paare, auprc, seeds = [], [], []
    if labels is None:
        return paare, auprc, seeds, probleme
    for key in ["01s13", *CONFIGS]:
        if key in r:
            auprc.append({"tf": tf, "richtung": richtung, "config": key,
                          "experiment": EXPERIMENT.get(key, g.BASIS + " (Seed 13)"), "gruppe": GRUPPE.get(key, "Basis"),
                          "auprc": float(average_precision_score(labels, r[key])),
                          "auprc_metrics_json": gespeichert.get(key, math.nan)})
    basis_da = all(s in r for s in SEEDS)
    vorhanden = [c for c in CONFIGS if c in r]
    for klasse, wert in KLASSEN.items():
        maske = labels == wert
        n = int(maske.sum())
        if n < 10:
            probleme[f"{klasse}"] = f"zu wenige Sequenzen ({n})"
            continue
        zeile = {"tf": tf, "richtung": richtung, "klasse": klasse, "n_sequenzen": n}
        for a, b in SEED_PAARE:
            zeile[f"seed_{a[-2:]}_{b[-2:]}"] = pearson(r[a][maske], r[b][maske]) if a in r and b in r else math.nan
        seeds.append(zeile)
        if not basis_da:
            continue
        vorzeichen = 1.0 if wert == 1 else -1.0
        basis = sum(r[s][maske] for s in SEEDS) / 3.0
        delta = {c: vorzeichen * (r[c][maske] - basis) for c in vorhanden}
        for c1, c2 in itertools.combinations(vorhanden, 2):
            paare.append({"tf": tf, "richtung": richtung, "klasse": klasse, "n": n, "c1": c1, "c2": c2,
                          "gruppe_c1": GRUPPE[c1], "gruppe_c2": GRUPPE[c2],
                          "gleiche_gruppe": "ja" if GRUPPE[c1] == GRUPPE[c2] else "nein",
                          "korrelation": pearson(delta[c1], delta[c2])})
    if not basis_da:
        probleme["Basis"] = "01 Seed 13/14/15 unvollständig, keine Paar-Korrelationen"
    return paare, auprc, seeds, probleme


def main() -> int:
    modelle = {**SEEDS, **{c: (EXPERIMENT[c], 13) for c in CONFIGS}}
    tfs = g.middle_tfs()
    paare, auprc, seeds, probleme = [], [], [], []
    for tf in tfs:
        for richtung in g.RICHTUNGEN:
            p, a, s, fehlt = analyse(tf, richtung, modelle)
            paare += p
            auprc += a
            seeds += s
            probleme += [(tf, richtung, k, v) for k, v in fehlt.items()]
        print(f"{tf}: fertig", flush=True)
    out = g.ERGEBNISSE

    median_zeilen = []
    for richtung in g.RICHTUNGEN:
        for klasse in KLASSEN:
            sel = [z for z in paare if z["richtung"] == richtung and z["klasse"] == klasse]
            for c1, c2 in itertools.combinations(CONFIGS, 2):
                werte = [z["korrelation"] for z in sel if z["c1"] == c1 and z["c2"] == c2]
                if werte:
                    median_zeilen.append({"richtung": richtung, "klasse": klasse, "c1": c1, "c2": c2,
                                          "gruppe_c1": GRUPPE[c1], "gruppe_c2": GRUPPE[c2],
                                          "gleiche_gruppe": "ja" if GRUPPE[c1] == GRUPPE[c2] else "nein",
                                          "n_tfs": len(werte), "korrelation": median(werte)})
    seed_median = []
    spalten = [f"seed_{a[-2:]}_{b[-2:]}" for a, b in SEED_PAARE]
    for richtung in g.RICHTUNGEN:
        for klasse in KLASSEN:
            sel = [z for z in seeds if z["richtung"] == richtung and z["klasse"] == klasse]
            if sel:
                zeile = {"tf": "Median", "richtung": richtung, "klasse": klasse,
                         "n_tfs": sum(1 for z in sel if any(endlich(z[s]) for s in spalten))}
                zeile.update({s: median([z[s] for z in sel]) for s in spalten})
                seed_median.append(zeile)

    felder_seeds = ["tf", "richtung", "klasse", "n_sequenzen", "n_tfs", *spalten]
    g.schreibe_csv(out / "a3_pro_tf.csv", paare)
    g.schreibe_csv(out / "a3_median.csv", median_zeilen)
    g.schreibe_csv(out / "a3_auprc.csv", auprc)
    g.schreibe_csv(out / "a3_seeds.csv", seeds + seed_median, felder_seeds)

    # Kurzer Überblick nur auf dem Bildschirm
    print("\nÜberblick (Median über TFs, dann über Paare):")
    for richtung in g.RICHTUNGEN:
        for klasse in KLASSEN:
            sel = [z for z in median_zeilen if z["richtung"] == richtung and z["klasse"] == klasse]
            innen = median([z["korrelation"] for z in sel if z["gleiche_gruppe"] == "ja"])
            aussen = median([z["korrelation"] for z in sel if z["gleiche_gruppe"] == "nein"])
            sm = next((z for z in seed_median if z["richtung"] == richtung and z["klasse"] == klasse), {})
            print(f"  {richtung} {klasse}: Δ-Paare innerhalb der Gruppen {innen:.2f}, zwischen den Gruppen {aussen:.2f}; "
                  f"Ränge 01 Seed 13–14 {sm.get('seed_13_14', math.nan):.2f}, 13–15 {sm.get('seed_13_15', math.nan):.2f}, "
                  f"14–15 {sm.get('seed_14_15', math.nan):.2f}")
    abw = [abs(z["auprc"] - z["auprc_metrics_json"]) for z in auprc if endlich(z["auprc_metrics_json"])]
    if abw:
        print(f"AUPRC aus den Vorhersagen gegen metrics.json: größte Abweichung {max(abw):.2g}")
    fehlend = {}
    for tf, richtung, key, grund in probleme:
        fehlend.setdefault((key, grund), []).append(f"{tf}/{richtung}")
    for (key, grund), orte in sorted(fehlend.items()):
        print(f"Fehlt: {key} – {grund}: {len(orte)}× (z. B. {', '.join(orte[:3])})")
    print(f"Geschrieben: {out}/a3_pro_tf.csv, a3_median.csv, a3_auprc.csv, a3_seeds.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
