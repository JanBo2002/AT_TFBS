#!/usr/bin/env bash
# Stand der Läufe für den Ergebnisteil (nur lesen). Im Ordner human301:  bash ergebnisteil/status.sh
# Je Config: abgeschlossene, gescheiterte und laufende Läufe von 42 und ob noch Jobs in der Queue stehen.
# Gescheiterte Läufe erscheinen als "Error: ..." mit der Fehlermeldung des Laufs.
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/gemeinsam.sh"
BA_ECHT="$(cd "$BA" && pwd -P)"
NAMEN="$(squeue --me -h -o "%F|%j|%T" 2>/dev/null)" || NAMEN=""
EXTRA=()
[ -f "$ZUSTAND" ] && while read -r name; do EXTRA+=("$name"); done < <("$PY" -c \
    'import json,sys; [print(c) for e in json.load(open(sys.argv[1]))["eingereiht"] for c in e["configs"]]' "$ZUSTAND")
NAMEN="$NAMEN" "$PY" - "$BA" "$HIER" "${KBLOCK[@]}" "${SPAETER[@]}" "${P3[@]}" "${P1[@]}" "${P2[@]}" "${P4[@]}" \
    "${P5[@]}" ${EXTRA[@]+"${EXTRA[@]}"} <<'PYTHON'
import json, os, sys
from pathlib import Path
ba, hier, configs = Path(sys.argv[1]), Path(sys.argv[2]), list(dict.fromkeys(sys.argv[3:]))
queue = [z.split("|") for z in os.environ.get("NAMEN", "").splitlines() if z.count("|") == 2]
arrays = {}
for pfad in (ba / "plans").glob("*/submission.json"):
    try:
        stand = json.loads(pfad.read_text())
    except (OSError, ValueError):
        continue
    if isinstance(stand, dict) and stand.get("array_id") is not None:
        arrays[str(stand["array_id"])] = set(stand.get("configs", []))
fehler = []
print(f"{'Config':48s} {'fertig':>6s} {'Fehler':>6s} {'läuft':>6s}  Queue")
for name in configs:
    pfad = ba / "configs" / f"{name}.json"
    soll = None
    if pfad.is_file():
        c = json.loads(pfad.read_text())
        soll = 42 * len(c.get("seeds", [13]))
    zaehler = {"completed": 0, "failed": 0, "running": 0}
    for run in sorted((ba / "results" / name / "runs").glob("*/train_*/seed_*/run.json")):
        try:
            meta = json.loads(run.read_text())
        except (OSError, ValueError):
            continue
        status = meta.get("status", "running")
        zaehler[status if status in zaehler else "running"] += 1
        if status == "failed":
            teile = run.parent.relative_to(ba / "results" / name / "runs").parts
            fehler.append(f"Error: {name} {teile[0]}/{teile[1].removeprefix('train_')}/{teile[2]}: {meta.get('error', '')}")
    jobs = sorted({zustand for nummer, job, zustand in queue if job == f"h301_collect_{name}"
                   or (job.startswith("h301_array_") and name in arrays.get(nummer, set()))})
    print(f"{name:48s} {zaehler['completed']:>6d} {zaehler['failed']:>6d} {zaehler['running']:>6d}  "
          f"{'/'.join(jobs) if jobs else '–'}{'' if soll is None else f'  (von {soll})'}")
bericht = hier / "diagnose_nan" / "bericht.txt"
print(f"\nNaN-Diagnose: {'Bericht liegt vor: ' + str(bericht) if bericht.is_file() else 'noch kein Bericht'}"
      + ("; Job läuft/wartet" if any(j == "h301_nan_diagnose" for _, j, _ in queue) else ""))
for zeile in fehler:
    print(zeile)
PYTHON
