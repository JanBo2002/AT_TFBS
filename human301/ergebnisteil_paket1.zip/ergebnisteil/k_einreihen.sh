#!/usr/bin/env bash
# Weitere Configs vor die noch wartenden Punkte 3, 1, 2, 4, 5 einreihen (K8, K11, eigene K-Configs, die Wiederholungen
# aus Punkt 6). Auf dem Login-Knoten, in at_env, im Ordner human301, nach einreichen.sh:
#
#   bash ergebnisteil/k_einreihen.sh [--account=NAME] CONFIG [CONFIG ...]
#   bash ergebnisteil/k_einreihen.sh --restart [--account=NAME] CONFIG [CONFIG ...]   # nur fehlende Läufe neu
#
# - Die Config muss in big_ablation/configs liegen oder in ergebnisteil/configs (wird dann kopiert).
# - submit_array.sh reicht ein (unverändert); danach wird die Wartebedingung des neuen Arrays gelöst, es nutzt also
#   freie Plätze. Ältere wartende Tasks gehen vor; solange N3 noch auf den K-Block wartet, auch vor N3.
# - Bei jedem noch ganz wartenden Array der Punkte 3, 1, 2, 4, 5 wird das neue Array als Vorgänger eingetragen.
#   Schon laufende Arrays bleiben unberührt. Mehrere Aufrufe reihen sich in ihrer Reihenfolge ein.
# - --restart: Nur, wenn kein Job dieser Configs mehr in der Queue steht (submit_array.sh --restart würde ihn sonst
#   abbrechen). Abgebrochene Läufe verschiebt submit_array.sh in den Plan-Ordner; nichts wird überschrieben.
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/gemeinsam.sh"
ACCOUNT=()
RESTART=()
CONFIGS=()
for arg in "$@"; do
    case "$arg" in
        --account=?*) ACCOUNT=("$arg") ;;
        --restart) RESTART=(--restart) ;;
        --*) echo "Unbekannte Option: $arg" >&2; exit 2 ;;
        *) CONFIGS+=("${arg%.json}") ;;
    esac
done
[ "${#CONFIGS[@]}" -gt 0 ] || { echo "Aufruf: bash ergebnisteil/k_einreihen.sh [--restart] [--account=NAME] CONFIG ..." >&2; exit 2; }

echo "== Prüfen"
werkzeuge_pruefen
[ -f "$ZUSTAND" ] || fehler "$ZUSTAND fehlt – zuerst bash ergebnisteil/einreichen.sh"
STAND="$(projekt)" || fehler "squeue nicht abfragbar"
if [ "${#RESTART[@]}" -gt 0 ]; then
    # Die NaN-Diagnose liest die abgebrochenen Läufe von K4 und B26; --restart verschiebt sie
    NAMEN="$(squeue --me -h -o "%j")" || fehler "squeue nicht abfragbar"
    for name in "${CONFIGS[@]}"; do
        case "$name" in
            K4_A14_se_mean_middle|B26_se_window16_middle)
                if grep -qx "h301_nan_diagnose" <<< "$NAMEN"; then
                    fehler "Die NaN-Diagnose steht noch in der Queue und liest die abgebrochenen Läufe; --restart erst danach."
                fi
                [ -f "$HIER/diagnose_nan/bericht.txt" ] || fehler "Kein Diagnosebericht (ergebnisteil/diagnose_nan/bericht.txt); --restart erst danach." ;;
        esac
    done
fi
for name in "${CONFIGS[@]}"; do
    if [ ! -e "$BA/configs/$name.json" ]; then
        [ -f "$HIER/configs/$name.json" ] || fehler "configs/$name.json weder in big_ablation noch in ergebnisteil"
    elif [ -f "$HIER/configs/$name.json" ] && ! cmp -s "$HIER/configs/$name.json" "$BA/configs/$name.json"; then
        fehler "configs/$name.json in big_ablation weicht von ergebnisteil/configs ab; nichts eingereicht."
    fi
    if [ "${#RESTART[@]}" -gt 0 ]; then
        # Arrays mit dieser Config (über plans/*/submission.json) und ihre Sammeljobs dürfen nicht mehr in der Queue sein
        belegt="$(STAND="$STAND" "$PY" - "$BA" "$name" <<'PYTHON'
import json, os, sys
from pathlib import Path
ba, name = Path(sys.argv[1]), sys.argv[2]
arrays = set()
for pfad in (ba / "plans").glob("*/submission.json"):
    try:
        stand = json.loads(pfad.read_text())
    except (OSError, ValueError):
        continue
    if isinstance(stand, dict) and name in stand.get("configs", []):
        arrays.add(str(stand.get("array_id")))
print(" ".join(sorted({z.split("|")[0] for z in os.environ["STAND"].splitlines()
                      if z.split("|")[0] in arrays or z.split("|")[1:2] == [f"h301_collect_{name}"]})))
PYTHON
)" || fehler "Queue für $name nicht prüfbar"
        [ -z "$belegt" ] || fehler "$name hat noch Jobs in der Queue ($belegt); --restart würde sie abbrechen. Später erneut."
    elif [ -e "$BA/results/$name" ]; then
        fehler "results/$name existiert schon; für fehlende Läufe --restart verwenden."
    fi
done
for name in "${CONFIGS[@]}"; do
    if [ ! -e "$BA/configs/$name.json" ]; then
        cp "$HIER/configs/$name.json" "$BA/configs/$name.json.neu"
        mv -n "$BA/configs/$name.json.neu" "$BA/configs/$name.json"
        cmp -s "$HIER/configs/$name.json" "$BA/configs/$name.json" || fehler "configs/$name.json nicht sauber angelegt"
        echo "  configs/$name.json angelegt."
    fi
done

echo "== Einreichen"
ARRAY="$(einreichen ${RESTART[@]+"${RESTART[@]}"} "${CONFIGS[@]}")" || { [ $? = 3 ] && FEHLER=1 \
    || fehler "kein Array eingereicht (Ausgabe oben)${RESTART[*]:+; mit --restart können Läufe schon in den Plan-Ordner verschoben sein}."; }
abhaengigkeit "$ARRAY" "" || true
STAND="$(projekt)" || fehler "Queue nicht lesbar ($ARRAY ist eingereicht; Einreihen später wiederholen: bitte melden)."
SAMMLER="$(sammler "$STAND" "${CONFIGS[@]}")"
"$PY" - "$ZUSTAND" "$ARRAY" "$SAMMLER" "${CONFIGS[*]}" <<'PYTHON'
import json, sys
pfad, array, sammler, configs = sys.argv[1:5]
zustand = json.load(open(pfad))
zustand["eingereiht"].append({"array": array, "sammler": [s for s in sammler.split(":") if s], "configs": configs.split()})
json.dump(zustand, open(pfad, "w"), indent=1)
PYTHON

echo "== Vor die wartenden Punkte"
EINGEREIHT="$("$PY" -c 'import json,sys; z=json.load(open(sys.argv[1])); print(" ".join([e["array"] for e in z["eingereiht"]] + [s for e in z["eingereiht"] for s in e["sammler"]]))' "$ZUSTAND")"
IM_STAND="$(awk -F'|' '{print $1}' <<< "$STAND" | sort -un)"
NOCH_DA=""
for job in $EINGEREIHT; do grep -qx "$job" <<< "$IM_STAND" && NOCH_DA="$NOCH_DA $job"; done
while read -r punkt array; do
    [ -n "$array" ] || continue
    if ! grep -qx "$array" <<< "$IM_STAND"; then
        echo "  Punkt $punkt ($array): nicht mehr in der Queue."
    elif ! nur_wartend "$array" "$STAND"; then
        echo "  Punkt $punkt ($array): läuft schon; unverändert."
    else
        abhaengigkeit "$array" "afterany:$(liste "$(vorgaenger "$array" "$STAND")" $NOCH_DA)" || true
    fi
done < <("$PY" -c 'import json,sys; [print(h["punkt"], h["array"]) for h in json.load(open(sys.argv[1]))["hinten"]]' "$ZUSTAND")

echo "== Aufräumen neu einplanen (wartet dann auch auf das neue Array)"
aufraeumen_neu

echo "== Wartende Jobs"
squeue --me -t PENDING -o "%.18i %.10Q %.20r %.45E %.55j"
[ "$FEHLER" = 0 ] || { echo "Error: Mindestens ein Schritt ist gescheitert (Meldungen oben)." >&2; exit 1; }
