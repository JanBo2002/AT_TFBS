#!/usr/bin/env bash
# Läufe für den Ergebnisteil, Paket 1. Auf dem Login-Knoten, in at_env, im Ordner human301:
#
#   bash ergebnisteil/einreichen.sh [--account=NAME]
#
# 1. Prüft die Basis-Configs (K5, N1, R03, A37) gegen die Fassung, aus der die neuen Configs abgeleitet sind, und
#    kopiert die neuen Configs nach big_ablation/configs, nur wenn sie dort fehlen (andere Fassung: Error).
#    Kein Programmcode ändert sich; laufende Arrays und bestehende Ergebnisse bleiben unberührt.
# 2. K-Block (K6, K7, K9, K10, K5 mit Seed 14/15) als ein Array ohne Wartebedingung: nimmt die nächsten freien
#    Plätze; ältere wartende Tasks (etwa ein Rest von N2 oder R08) gehen vor.
# 3. Die wartenden Tasks von N3 warten zusätzlich auf den K-Block; laufende N3-Tasks rechnen weiter.
# 4. Punkte 3, 1, 2, 4, 5 je als eigenes Array dahinter; submit_array.sh reiht sie in dieser Folge ein.
# 5. NaN-Diagnose (Punkt 6) sofort als einzelner GPU-Job; Ausgabe nur in ergebnisteil/diagnose_nan/.
# 6. Aufräumen neu einplanen.
# K8 kommt nach Punkt 6, K11 mit Paket 2, weitere K-Configs jederzeit: bash ergebnisteil/k_einreihen.sh CONFIG
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/gemeinsam.sh"
ACCOUNT=()
for arg in "$@"; do
    case "$arg" in
        --account=?*) ACCOUNT=("$arg") ;;
        *) echo "Unbekannte Option: $arg (Aufruf: bash ergebnisteil/einreichen.sh [--account=NAME])" >&2; exit 2 ;;
    esac
done
ALLE=("${KBLOCK[@]}" "${P3[@]}" "${P1[@]}" "${P2[@]}" "${P4[@]}" "${P5[@]}" "${SPAETER[@]}")

echo "== Prüfen"
werkzeuge_pruefen
[ ! -e "$ZUSTAND" ] || fehler "$ZUSTAND existiert schon (schon eingereicht?). Nachreichen: k_einreihen.sh"
NAMEN="$(squeue --me -h -o "%j")" || fehler "squeue nicht abfragbar"
if grep -qx "h301_nan_diagnose" <<< "$NAMEN"; then fehler "Die NaN-Diagnose steht schon in der Queue."; fi
for name in "${ALLE[@]}"; do
    [ ! -e "$BA/results/$name" ] || fehler "results/$name existiert schon; nichts eingereicht."
    if [ -e "$BA/configs/$name.json" ] && ! cmp -s "$HIER/configs/$name.json" "$BA/configs/$name.json"; then
        fehler "configs/$name.json gibt es schon in einer anderen Fassung; nichts eingereicht."
    fi
done
# Basis-Configs: Rezept wie in der Fassung, aus der die neuen Configs abgeleitet sind; Caches mit Negativtypen für N
"$PY" - "$BA" "$HIER" <<'PYTHON' || fehler "Prüfung der Basis-Configs oder Caches gescheitert (siehe oben); nichts eingereicht."
import json, sys
from pathlib import Path
ba, hier = Path(sys.argv[1]), Path(sys.argv[2])
probleme = []
for kopie in sorted((hier / "basis").glob("*.json")):
    installiert = ba / "configs" / kopie.name
    if not installiert.is_file():
        probleme.append(f"configs/{kopie.name} fehlt")
        continue
    a, b = json.loads(kopie.read_text()), json.loads(installiert.read_text())
    anders = sorted(k for k in set(a) | set(b) if k not in ("name", "description", "reference") and a.get(k) != b.get(k))
    if anders:
        probleme.append(f"configs/{kopie.name} weicht im Rezept ab ({', '.join(anders)})")
sys.path.insert(0, str(ba))
sys.dont_write_bytecode = True
import data
rows = data._negative_rows(ba / "configs/caches.csv", None, ba / "configs/training_priority_middle.csv")
fehlen = [f"{r['tf']}/{r['assay']}" for r in rows if not data.negative_cache_path(r["cache"], "ras").is_file()]
if fehlen:
    probleme.append("Caches mit Negativtypen fehlen für " + ", ".join(fehlen))
for p in probleme:
    print("Error: " + p, file=sys.stderr)
print(f"Basis-Configs wie erwartet; Caches mit Negativtypen für alle {len(rows)} Paare" if not probleme else "")
sys.exit(1 if probleme else 0)
PYTHON

echo "== Configs anlegen"
for name in "${ALLE[@]}"; do
    if [ ! -e "$BA/configs/$name.json" ]; then
        cp "$HIER/configs/$name.json" "$BA/configs/$name.json.neu"
        mv -n "$BA/configs/$name.json.neu" "$BA/configs/$name.json"
        cmp -s "$HIER/configs/$name.json" "$BA/configs/$name.json" || fehler "configs/$name.json nicht sauber angelegt"
    fi
done
echo "  ${#ALLE[@]} Configs in big_ablation/configs (K8 wird erst nach Punkt 6 eingereicht)."

echo "== K-Block einreichen (vor N3)"
ARRAY_K="$(einreichen "${KBLOCK[@]}")" || { [ $? = 3 ] && FEHLER=1 || fehler "K-Block nicht eingereicht; sonst nichts verändert."; }
abhaengigkeit "$ARRAY_K" "" || true
"$PY" -c 'import json,sys; json.dump({"kblock": sys.argv[2], "hinten": [], "eingereiht": []}, open(sys.argv[1], "w"), indent=1)' \
    "$ZUSTAND" "$ARRAY_K"
STAND="$(projekt)" || fehler "Queue nicht lesbar (K-Block $ARRAY_K ist eingereicht)."
SAMMLER_K="$(sammler "$STAND" "${KBLOCK[@]}")"

echo "== N3 hinter den K-Block"
N3_ARRAY="$(awk -F'|' '$2 == "h301_array_N3_01_all_negatives_middle" {print $1}' <<< "$STAND" | sort -un | sed -n 1p)"
N3_WARTET="$(awk -F'|' -v a="$N3_ARRAY" '$1 == a && $3 == "PENDING"' <<< "$STAND")"
if [ -z "$N3_ARRAY" ]; then
    echo "  N3 steht nicht mehr in der Queue."
elif [ -z "$N3_WARTET" ]; then
    echo "  N3 ($N3_ARRAY) hat keine wartenden Tasks mehr; unverändert."
else
    NEU="afterany:$(liste "$(vorgaenger "$N3_ARRAY" "$STAND")" "$ARRAY_K" "$SAMMLER_K")"
    abhaengigkeit "$N3_ARRAY" "$NEU" || true
    roh="$(squeue --me -h -t PENDING -o "%F|%E")" || roh=""
    jetzt="$(awk -F'|' -v a="$N3_ARRAY" '$1 == a {print $2}' <<< "$roh" | sed -n 1p)"
    if grep -q "$ARRAY_K" <<< "$jetzt"; then
        echo "  N3 ($N3_ARRAY): wartende Tasks starten nach dem K-Block; laufende laufen zu Ende."
    else
        scontrol hold "$N3_ARRAY" && echo "  N3 ($N3_ARRAY): Slurm nimmt die Wartebedingung nicht an; die wartenden Tasks" \
            "sind angehalten. Freigeben, sobald der K-Block ($ARRAY_K) durch ist:  scontrol release $N3_ARRAY" \
            || merke_fehler "N3 ($N3_ARRAY) weder umgestellt noch angehalten – bitte melden."
    fi
fi

echo "== Punkte 3, 1, 2, 4, 5 dahinter"
HINTEN=()
for punkt in 3 1 2 4 5; do
    eval "gruppe=(\"\${P$punkt[@]}\")"
    array="$(einreichen "${gruppe[@]}")" || { [ $? = 3 ] && FEHLER=1 \
        || fehler "Punkt $punkt nicht eingereicht; eingereicht sind K-Block und ${HINTEN[*]:-keiner} (Stand in $ZUSTAND)."; }
    HINTEN+=("$punkt:$array")
    "$PY" -c 'import json,sys; z=json.load(open(sys.argv[1])); z["hinten"].append({"punkt": int(sys.argv[2]), "array": sys.argv[3]}); json.dump(z, open(sys.argv[1], "w"), indent=1)' \
        "$ZUSTAND" "$punkt" "$array"
    echo "  Punkt $punkt: Array $array (${gruppe[*]})"
done

echo "== NaN-Diagnose (Punkt 6) als einzelner GPU-Job"
mkdir -p "$HIER/diagnose_nan/logs"
DATEI="$HIER/diagnose_nan/diagnose.sbatch"
{
    echo "#!/usr/bin/env bash"
    grep -E '^#SBATCH' "$BA/train_array.sbatch" | grep -v -E -- '--(job-name|output|error|array|open-mode|time)' || true
    echo "set -euo pipefail"
    echo "echo \"NaN-Diagnose als \$(id -un) auf \$(hostname), Job \$SLURM_JOB_ID, \$(date)\""
    printf '%q ' "$PY" "$HIER/diagnose_nan.py"
    echo
    echo "echo \"Ende \$(date)\""
} > "$DATEI"
DIAG="$(sbatch --parsable --no-requeue --job-name=h301_nan_diagnose --chdir="$H301" \
        --output="$HIER/diagnose_nan/logs/diagnose_%j.out" --time=12:00:00 --export=ALL ${ACCOUNT[@]+"${ACCOUNT[@]}"} "$DATEI")" \
    || { merke_fehler "NaN-Diagnose nicht eingereicht; später: sbatch $DATEI"; DIAG=""; }
DIAG="${DIAG%%;*}"
[ -n "$DIAG" ] && echo "  Job $DIAG; Bericht danach: ergebnisteil/diagnose_nan/bericht.txt"

echo "== Aufräumen neu einplanen"
aufraeumen_neu

echo "== Wartende Jobs"
squeue --me -t PENDING -o "%.18i %.10Q %.20r %.45E %.55j"
echo "Stand der Läufe jederzeit: bash ergebnisteil/status.sh"
[ "$FEHLER" = 0 ] || { echo "Error: Mindestens ein Schritt ist gescheitert (Meldungen oben)." >&2; exit 1; }
