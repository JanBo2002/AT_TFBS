#!/usr/bin/env python3
"""Diagnose der NaN-Abbrüche aus Punkt 6, als GPU-Job über einreichen.sh (schreibt nichts in big_ablation).

Fälle: K4_A14_se_mean_middle LEF1/CHS (Abbruch nach 14 Epochen) und B26_se_window16_middle RORB/GHTS (nach 41).
1. Spuren: kopiert run.json, config.json, train.log, records.jsonl und training/*.json der abgebrochenen Läufe
   nach diagnose_nan/spuren/. Die Originale bleiben, wo sie sind.
2. Wiederholung: derselbe Lauf mit dem installierten Code, der gespeicherten Config, denselben Daten (Prüfsumme des
   Caches wie im Original) und demselben Seed, in diagnose_nan/wiederholung/. Die Prüfpunkte lesen nur mit:
   - je Trainingsschritt: Loss, Gradienten (nicht endlich = der GradScaler verwirft den Schritt), Gewichte,
     rmsbatch-Statistiken (running_mean_square) und die Ausgaben der Blöcke;
   - je Epoche: größte Aktivierung je Block (fp16 reicht bis 65.504), nicht-endliche Vorhersagen in Training und
     Validierung, Zahl der verworfenen Schritte.
   Ende beim Fehler oder 5 Epochen nach der ursprünglichen Abbruchepoche ("nicht reproduziert").
3. Bericht: diagnose_nan/bericht.txt und bericht.json.

Aufruf (im Job):  python ergebnisteil/diagnose_nan.py
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import inspect
import json
import math
import os
import shutil
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

sys.dont_write_bytecode = True
HIER = Path(__file__).resolve().parent
BA = Path(os.environ.get("DIAG_PROJEKT", HIER.parent / "big_ablation")).resolve()
AUS = Path(os.environ.get("DIAG_AUSGABE", HIER / "diagnose_nan")).resolve()
FAELLE = [("K4_A14_se_mean_middle", "LEF1", "CHIP", 13), ("B26_se_window16_middle", "RORB", "GHTS", 13)]
FP16_MAX = 65504.0
sys.path.insert(0, str(BA))


class Genug(Exception):
    """Stopp nach der ursprünglichen Abbruchepoche plus Reserve."""


class Zustand:
    def __init__(self):
        self.neu(None)

    def neu(self, stopp_nach):
        self.model, self.norms, self.phase, self.epoche, self.schritt = None, [], None, 0, 0
        self.stopp_nach, self.reihenfolge, self.gesehen = stopp_nach, [], set()
        self.max_akt, self.schlecht, self.loss_schlecht = {}, {}, None
        self.erstes, self.epochen, self.verworfen_epoche, self.verworfen = None, [], 0, 0
        self.fehler_test, self.erster_verworfen, self.soll_argumente = None, None, None


Z = Zustand()


def erster_tensor(wert):
    import torch
    if isinstance(wert, torch.Tensor):
        return wert
    if isinstance(wert, dict):
        wert = list(wert.values())
    if isinstance(wert, (list, tuple)):
        for teil in wert:
            t = erster_tensor(teil)
            if t is not None:
                return t
    return None


def haken(name):
    import torch

    def hook(module, inputs, output):
        t = erster_tensor(output)
        if t is None or not t.is_floating_point():
            return None
        if Z.fehler_test and Z.phase == "train" and name == Z.fehler_test[0] and Z.schritt + 1 == Z.fehler_test[1]:
            t = t.clone()
            t.view(-1)[0] = float("inf")          # nur im Test: eingeschleuster Überlauf
            output = t if isinstance(output, torch.Tensor) else output
        if name not in Z.gesehen:
            Z.gesehen.add(name)
            Z.reihenfolge.append(name)
        amax = t.detach().abs().amax().float()
        alt = Z.max_akt.get(name)
        Z.max_akt[name] = amax if alt is None else torch.maximum(alt, amax)
        schlecht = ~torch.isfinite(amax)
        Z.schlecht[name] = schlecht if name not in Z.schlecht else (Z.schlecht[name] | schlecht)
        return output if Z.fehler_test else None
    return hook


def installiere_pruefpunkte():
    """Patcht nur Funktionen dieses Prozesses; der Code in big_ablation bleibt unverändert."""
    import torch
    import model as M
    import training as T

    alt_init = M.HumanTFBindingModel.__init__

    def init(self, *args, **kwargs):
        alt_init(self, *args, **kwargs)
        Z.model = self
        Z.norms = [(n, m) for n, m in self.named_modules() if isinstance(m, M.RMSBatchNorm1d)]
        for name, modul in self.named_modules():
            if name and (name.count(".") == 0 or isinstance(modul, (M.RMSBatchNorm1d, M.SqueezeExcite))
                         or (name.count(".") == 1 and isinstance(getattr(self, name.split(".")[0]), torch.nn.ModuleList))):
                modul.register_forward_hook(haken(name))
    M.HumanTFBindingModel.__init__ = init

    alt_loss = T.compute_multitask_loss

    def loss(*args, **kwargs):
        wert, teile = alt_loss(*args, **kwargs)
        schlecht = ~torch.isfinite(wert.detach())
        Z.loss_schlecht = schlecht if Z.loss_schlecht is None else (Z.loss_schlecht | schlecht)
        return wert, teile
    T.compute_multitask_loss = loss

    alt_clip = torch.nn.utils.clip_grad_norm_

    def clip(parameters, max_norm, *args, **kwargs):
        parameters = list(parameters)
        norm = alt_clip(parameters, max_norm, *args, **kwargs)
        if Z.model is not None and Z.phase == "train":
            Z.schritt += 1
            schritt_pruefen(norm)
        return norm
    torch.nn.utils.clip_grad_norm_ = clip

    alt_train = T.train_command

    def train_command(args, *weitere, **kwargs):
        if Z.soll_argumente is not None:
            fluechtig = {"output_dir", "cache_path", "dataset_root", "device"}
            ist = json.loads(json.dumps({k: v for k, v in vars(args).items() if k not in fluechtig}, default=str))
            soll = {k: v for k, v in Z.soll_argumente.items() if k not in fluechtig}
            # nur die Argumente des Originals vergleichen: später hinzugekommene Schalter stehen auf ihrem Standard
            anders = sorted(k for k in soll if ist.get(k) != soll[k])
            if anders:
                raise ValueError("Error: Trainingsargumente weichen vom Original ab: "
                                 + ", ".join(f"{k} {soll.get(k)!r} -> {ist.get(k)!r}" for k in anders[:6]))
            print("  Trainingsargumente wie im Original (Datenlader-Prozesse eingeschlossen).", flush=True)
        return alt_train(args, *weitere, **kwargs)
    T.train_command = train_command

    alt_epoche = T.run_epoch
    signatur = inspect.signature(alt_epoche)

    def run_epoch(*args, **kwargs):
        gebunden = signatur.bind(*args, **kwargs)
        training = gebunden.arguments.get("optimizer") is not None
        if training:
            Z.epoche += 1
            if Z.stopp_nach and Z.epoche > Z.stopp_nach:
                raise Genug()
            Z.verworfen_epoche = 0
        Z.phase = "train" if training else "val"
        Z.max_akt, Z.schlecht, Z.loss_schlecht = {}, {}, None
        begonnen = time.perf_counter()
        try:
            ergebnis = alt_epoche(*args, **kwargs)
        except Exception as fehler:
            epoche_abschliessen(None, fehler, time.perf_counter() - begonnen)
            raise
        epoche_abschliessen(ergebnis, None, time.perf_counter() - begonnen)
        return ergebnis
    T.run_epoch = run_epoch


def schritt_pruefen(norm):
    """Eine Synchronisation je Schritt: Gradienten, Loss, Aktivierungen, rmsbatch-Statistik, Gewichte."""
    import torch
    falsch = torch.zeros((), dtype=torch.bool, device=norm.device)
    akt = torch.stack(list(Z.schlecht.values())).any() if Z.schlecht else falsch
    puffer = (~torch.stack([torch.isfinite(m.running_mean_square).all() for _, m in Z.norms]).all()
              if Z.norms else falsch)
    gewichte = ~torch.stack([torch.isfinite(p.detach()).all() for p in Z.model.parameters()]).all()
    loss = Z.loss_schlecht if Z.loss_schlecht is not None else falsch
    werte = torch.stack([~torch.isfinite(norm.detach()), loss.to(norm.device), akt.to(norm.device),
                         puffer.to(norm.device), gewichte.to(norm.device)]).cpu().tolist()
    grad, loss_n, akt_n, puffer_n, gewichte_n = werte
    if grad:
        # Mit AMP verwirft der GradScaler Schritte mit übergelaufenen Gradienten routinemäßig (Startskala 65.536,
        # Anstieg alle 2.000 Schritte); das allein ist kein Fehler und wird nur gezählt.
        Z.verworfen_epoche += 1
        Z.verworfen += 1
        if Z.erster_verworfen is None:
            Z.erster_verworfen = {"epoche": Z.epoche, "schritt": Z.schritt}
    if (loss_n or akt_n or puffer_n or gewichte_n) and Z.erstes is None:
        module = [n for n in Z.reihenfolge if n in Z.schlecht and bool(Z.schlecht[n].item())]
        normen = [n for n, m in Z.norms if not bool(torch.isfinite(m.running_mean_square).all().item())]
        Z.erstes = {"phase": "Training", "epoche": Z.epoche, "schritt": Z.schritt,
                    "gradienten_nicht_endlich": bool(grad), "loss_nicht_endlich": bool(loss_n),
                    "aktivierung_nicht_endlich": bool(akt_n), "erstes_modul": module[0] if module else None,
                    "module": module[:8], "rmsbatch_nicht_endlich": bool(puffer_n), "rmsbatch_module": normen[:8],
                    "gewichte_nicht_endlich": bool(gewichte_n)}
        print(f"  erstes nicht-endliches Ereignis: {json.dumps(Z.erstes, ensure_ascii=False)}", flush=True)
    Z.schlecht, Z.loss_schlecht = {}, None


def epoche_abschliessen(ergebnis, fehler, sekunden):
    import numpy as np
    import torch
    maxima = {n: float(t.item()) for n, t in Z.max_akt.items()}
    nicht_endlich = [n for n in Z.reihenfolge if n in Z.schlecht and bool(Z.schlecht[n].item())]
    vorhersagen = None
    if ergebnis is not None and getattr(ergebnis, "probabilities", None) is not None:
        p = np.asarray(ergebnis.probabilities, dtype=np.float64)
        vorhersagen = {"anzahl": int(p.size), "nicht_endlich": int((~np.isfinite(p)).sum())}
    puffer = [float(m.running_mean_square.max().item()) for _, m in Z.norms] if Z.norms else []
    zeile = {"phase": "Training" if Z.phase == "train" else "Validierung", "epoche": Z.epoche,
             "sekunden": round(sekunden, 1), "verworfene_schritte": Z.verworfen_epoche if Z.phase == "train" else None,
             "groesste_aktivierung": max(maxima.values(), default=None),
             "naechste_an_fp16": sorted(maxima.items(), key=lambda kv: -kv[1] if math.isfinite(kv[1]) else -math.inf)[:5],
             "module_nicht_endlich": nicht_endlich[:8], "vorhersagen": vorhersagen,
             "rmsbatch_max": max(puffer, default=None),
             "rmsbatch_nicht_endlich": [n for (n, m), w in zip(Z.norms, puffer) if not math.isfinite(w)][:8],
             "fehler": f"{type(fehler).__name__}: {fehler}" if fehler is not None else None}
    loss_val = Z.phase == "val" and Z.loss_schlecht is not None and bool(Z.loss_schlecht.item())
    zeile["loss_nicht_endlich"] = loss_val if Z.phase == "val" else None
    Z.epochen.append(zeile)
    if Z.phase == "val" and Z.erstes is None and (nicht_endlich or (vorhersagen and vorhersagen["nicht_endlich"])
                                                   or zeile["rmsbatch_nicht_endlich"] or loss_val or fehler is not None):
        Z.erstes = {"phase": "Validierung", "epoche": Z.epoche, "erstes_modul": nicht_endlich[0] if nicht_endlich else None,
                    "module": nicht_endlich[:8], "vorhersagen_nicht_endlich": vorhersagen and vorhersagen["nicht_endlich"],
                    "loss_nicht_endlich": loss_val, "rmsbatch_module": zeile["rmsbatch_nicht_endlich"],
                    "fehler": zeile["fehler"]}
    print(f"  Epoche {Z.epoche:3d} {zeile['phase']:11s} {sekunden:6.1f}s  größte Aktivierung "
          f"{zeile['groesste_aktivierung'] if zeile['groesste_aktivierung'] is None else round(zeile['groesste_aktivierung'], 1)}"
          f"  verworfen {zeile['verworfene_schritte']}  nicht endlich {nicht_endlich[:3]}"
          f"{'  Vorhersagen NaN ' + str(vorhersagen['nicht_endlich']) if vorhersagen and vorhersagen['nicht_endlich'] else ''}",
          flush=True)
    torch.cuda.synchronize() if torch.cuda.is_available() else None


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 22), b""):
            h.update(block)
    return h.hexdigest()


def letzte_epoche(lauf: Path, meta: dict) -> int | None:
    if isinstance(meta.get("epochs_run"), int) and meta["epochs_run"] > 0:
        return meta["epochs_run"]
    try:
        zeilen = (lauf / "train.log").read_text(errors="replace").splitlines()
    except OSError:
        return None
    nummern = [int(z.split()[1]) for z in zeilen if z.startswith("Epoch ") and z.split()[1].isdigit()]
    return max(nummern) if nummern else None


def spuren(experiment, tf, assay, seed):
    lauf = BA / "results" / experiment / "runs" / tf / f"train_{assay}" / f"seed_{seed:02d}"
    ziel = AUS / "spuren" / f"{experiment}_{tf}_{assay}"
    ziel.mkdir(parents=True, exist_ok=True)
    kopiert = []
    for name in ("run.json", "config.json", "train.log", "records.jsonl", "training/history.json",
                 "training/configuration.json", "training/validation_metrics.json"):
        if (lauf / name).is_file():
            (ziel / name).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(lauf / name, ziel / name)
            kopiert.append(name)
    meta = json.loads((lauf / "run.json").read_text()) if (lauf / "run.json").is_file() else {}
    ende = []
    if (lauf / "train.log").is_file():
        ende = (lauf / "train.log").read_text(errors="replace").splitlines()[-12:]
    return lauf, meta, {"ordner": str(lauf), "kopiert": kopiert, "status": meta.get("status"), "fehler": meta.get("error"),
                        "epochen": letzte_epoche(lauf, meta), "host": meta.get("hostname"),
                        "gpu": meta.get("device_name"), "logende": ende}


def wiederholen(experiment, tf, assay, seed, lauf, meta, stopp_nach):
    import torch
    import training as T
    config_pfad = lauf / "config.json" if (lauf / "config.json").is_file() else BA / "results" / experiment / "config.json"
    config = json.loads(config_pfad.read_text())
    cache = Path(meta.get("train_cache_path", ""))
    if not cache.is_file():
        return {"ergebnis": f"Error: Trainings-Cache fehlt ({cache})"}
    soll = meta.get("train_cache_sha256")
    if not soll:
        return {"ergebnis": "Error: Das Original hat keine Prüfsumme des Trainings-Caches; Daten nicht prüfbar"}
    ist = sha256(cache)
    if ist != soll:
        return {"ergebnis": f"Error: Trainings-Cache hat eine andere Prüfsumme als im Original ({ist[:12]} statt {soll[:12]})"}
    ordner = AUS / "wiederholung" / f"{experiment}_{tf}_{assay}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    Z.neu(stopp_nach)
    Z.soll_argumente = meta.get("resolved_training_arguments")
    if not Z.soll_argumente:
        return {"ergebnis": "Error: Das Original hat keine aufgelösten Trainingsargumente; Wiederholung nicht prüfbar"}
    if os.environ.get("DIAG_TEST_FEHLER"):
        modul, schritt = os.environ["DIAG_TEST_FEHLER"].rsplit("@", 1)
        Z.fehler_test = (modul, int(schritt))
    run_id = "diagnose_" + datetime.now().strftime("%Y%m%dT%H%M%S")
    recorder = T.RunRecorder(T.metadata(config, "diagnose", run_id, tf, assay, seed, cache), ordner)
    context = T.RunContext(config, BA / "configs" / f"{experiment}.json", BA, ordner, tf, assay, seed, {assay: cache},
                           recorder, device=os.environ.get("DIAG_DEVICE", "cuda"),
                           workers=Z.soll_argumente.get("num_workers"), tf_ids=(tf,))
    gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "keine"
    print(f"== Wiederholung {experiment} {tf}/{assay} Seed {seed} auf {gpu}, Stopp spätestens nach Epoche {stopp_nach}",
          flush=True)
    begonnen = time.perf_counter()
    try:
        T.invoke(config["fitting"], context, {assay: cache})
        ergebnis = "durchgelaufen ohne Abbruch"
    except Genug:
        ergebnis = f"nicht reproduziert (kein Abbruch bis Epoche {stopp_nach})"
    except Exception as fehler:
        # eigene Prüfungen melden "Error: ..."; jeder andere Abbruch ist ein Befund der Wiederholung
        ergebnis = str(fehler) if str(fehler).startswith("Error:") else f"Abbruch: {type(fehler).__name__}: {fehler}"
        traceback.print_exc()
    return {"ergebnis": ergebnis, "gpu": gpu, "ordner": str(ordner), "minuten": round((time.perf_counter() - begonnen) / 60, 1),
            "erstes_ereignis": Z.erstes, "erster_verworfener_schritt": Z.erster_verworfen,
            "verworfene_schritte": Z.verworfen, "schritte": Z.schritt, "verlauf": Z.epochen}


def bericht_text(alle) -> list[str]:
    text = ["Diagnose der NaN-Abbrüche (Punkt 6)", ""]
    for f in alle:
        s, w = f["spuren"], f["wiederholung"]
        text += [f"{f['experiment']} {f['tf']}/{f['assay']}, Seed {f['seed']}",
                 f"  Original: Status {s['status']}, {s['epochen']} Epochen, Fehler: {s['fehler']}",
                 f"            Host {s['host']}, GPU {s['gpu']}; Spuren in diagnose_nan/spuren/ ({len(s['kopiert'])} Dateien)",
                 f"  Wiederholung: {w['ergebnis']}" + (f" ({w.get('minuten')} min auf {w.get('gpu')})" if "gpu" in w else "")]
        e = w.get("erstes_ereignis")
        if e:
            was = [k for k, v in e.items() if k.endswith("nicht_endlich") and v]
            text.append(f"  Erstes nicht-endliches Ereignis: {e['phase']}, Epoche {e['epoche']}"
                        + (f", Schritt {e['schritt']}" if "schritt" in e else "") + f"; betroffen: {', '.join(was) or '–'}")
            text.append(f"    zuerst im Modul: {e.get('erstes_modul')}; rmsbatch nicht endlich in: {e.get('rmsbatch_module') or '–'}")
        elif "verlauf" in w:
            text.append("  Kein nicht-endlicher Wert gefunden.")
        if "verlauf" in w:
            train = [z for z in w["verlauf"] if z["phase"] == "Training"]
            spitze = max((z["groesste_aktivierung"] or 0 for z in train), default=0)
            erster = w.get("erster_verworfener_schritt")
            text.append(f"  Verworfene Schritte (GradScaler, mit AMP üblich) insgesamt: {w['verworfene_schritte']} von "
                        f"{w['schritte']}" + (f", der erste in Epoche {erster['epoche']}, Schritt {erster['schritt']}" if erster else "")
                        + f"; größte Aktivierung im Training {spitze:,.0f} (fp16-Grenze {FP16_MAX:,.0f})")
        text.append("")
    text += ["Lesart: Liegt das erste Ereignis in der rmsbatch-Statistik oder in einer Aktivierung, während Loss und",
             "Gewichte endlich bleiben, hat ein fp16-Überlauf die laufende Statistik verdorben; dann liefert jede spätere",
             "Validierung NaN. Nicht-endliche Gewichte zeigen dagegen einen Fehler im Optimierungsschritt."]
    return text


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--fall", action="append", help=argparse.SUPPRESS)   # EXP:TF:ASSAY:SEED, nur für Tests
    args = parser.parse_args()
    faelle = [(e, t, a, int(s)) for e, t, a, s in (f.split(":") for f in args.fall)] if args.fall else FAELLE
    AUS.mkdir(parents=True, exist_ok=True)
    installiere_pruefpunkte()
    # Zuerst alle Spuren sichern: ein späterer Neustart verschiebt die abgebrochenen Läufe
    gesichert = [(fall, *spuren(*fall)) for fall in faelle]
    alle = []
    for (experiment, tf, assay, seed), lauf, meta, s in gesichert:
        alle.append({"experiment": experiment, "tf": tf, "assay": assay, "seed": seed, "spuren": s,
                     "wiederholung": {"ergebnis": "noch nicht gelaufen"}})
    for eintrag, ((experiment, tf, assay, seed), lauf, meta, s) in zip(alle, gesichert):
        if not meta:
            eintrag["wiederholung"] = {"ergebnis": f"Error: kein run.json in {lauf}"}
        else:
            eintrag["wiederholung"] = wiederholen(experiment, tf, assay, seed, lauf, meta, (s["epochen"] or 45) + 5)
        (AUS / "bericht.json").write_text(json.dumps(alle, indent=1, ensure_ascii=False, default=str) + "\n")
        (AUS / "bericht.txt").write_text("\n".join(bericht_text(alle)) + "\n")
    text = bericht_text(alle)
    print("\n".join(text))
    fehler = [f for f in alle if str(f["wiederholung"]["ergebnis"]).startswith("Error")]
    for f in fehler:
        print(f"Error: {f['experiment']} {f['tf']}/{f['assay']}: {f['wiederholung']['ergebnis']}", file=sys.stderr)
    return 1 if fehler else 0


if __name__ == "__main__":
    sys.exit(main())
