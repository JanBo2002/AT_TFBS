# Gemeinsame Teile von einreichen.sh, k_einreihen.sh und status.sh (mit source geladen, nicht direkt ausführen).
HIER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
H301="$(cd "$HIER/.." && pwd)"
BA="$H301/big_ablation"
ZUSTAND="$HIER/warteschlange.json"
PY="${CONDA_PREFIX:+$CONDA_PREFIX/bin/python}"
PY="${PY:-$(command -v python3)}"

# Gruppen in der vereinbarten Reihenfolge; K8 und K11 kommen später über k_einreihen.sh dazu
KBLOCK=(K6_K5_readout_max16_middle K7_K5_relative_bias_middle K9_K5_bottleneck32_middle K10_K5_gelu_middle
        K5_A14_readout_lse16_se_mean_middle_seed14 K5_A14_readout_lse16_se_mean_middle_seed15)
P3=(N1_01_aliens_shades_middle_seed14 N1_01_aliens_shades_middle_seed15)
P1=(N4_N1_random5_aliens5_middle N5_N1_random10_shades1_middle)
P2=(N6_N1_random8_aliens2_middle N7_N1_random2_aliens8_middle)
P4=(R09_R03_crop192_middle R10_R03_crop96_middle)
P5=(A47_kernel_9_do0p1_cdo0p1_middle A48_kernel_11_do0p1_cdo0p1_middle A49_kernel_15_do0p1_cdo0p1_middle
    A50_kernel_19_do0p1_cdo0p1_middle A51_kernel_25_do0p1_cdo0p1_middle)
SPAETER=(K8_K5_se_window16_middle)

FEHLER=0
fehler() { echo "Error: $*" >&2; exit 1; }
merke_fehler() { echo "Error: $*" >&2; FEHLER=1; }

werkzeuge_pruefen() {
    local exe
    for exe in sbatch squeue scontrol scancel; do
        command -v "$exe" >/dev/null || fehler "$exe fehlt (auf dem Login-Knoten starten)"
    done
    "$PY" -c "import json, csv" 2>/dev/null || fehler "$PY ist kein lauffähiges Python – zuerst at_env aktivieren"
    BA_ECHT="$(cd "$BA" && pwd -P)" || fehler "big_ablation nicht gefunden neben $HIER"
}

# Jobs dieses Projekts: Arraynummer (%F) | Name | Zustand; squeue erst in eine Variable, dann filtern
projekt() {
    local roh
    roh="$(squeue --me -h -o "%F|%j|%T|%Z")" || return 1
    awk -F'|' -v ba="$BA_ECHT" '$4 == ba && $2 ~ /^h301_(array|collect)_/ {print $1 "|" $2 "|" $3}' <<< "$roh" | sort -u
}

# Config(s) über submit_array.sh einreichen (unverändert); gibt die Arraynummer aus, die Ausgabe geht nach stderr.
# Rückgabe 1: kein Array; 3: Array steht, submit_array.sh ist danach gescheitert (Aufrufer setzt FEHLER=1).
einreichen() {
    local ausgabe nummer code=0
    ausgabe="$(cd "$BA" && bash submit_array.sh "$@" ${ACCOUNT[@]+"${ACCOUNT[@]}"} 2>&1)" || code=$?
    echo "$ausgabe" >&2
    nummer="$(sed -n 's/^Jobarray \([0-9][0-9]*\):.*/\1/p' <<< "$ausgabe" | sed -n 1p)"
    if [ -z "$nummer" ]; then
        echo "Error: submit_array.sh $* hat kein Array eingereicht (Ausgabe oben)." >&2
        return 1
    fi
    if [ "$code" != 0 ]; then
        # Das Array steht; gescheitert ist danach nur ein Sammeljob (die Zusammenfassung macht der letzte Lauf)
        echo "Error: submit_array.sh $* endete mit Fehler nach dem Einreichen von Array $nummer (Ausgabe oben);" \
             "das Array bleibt, es wird weiter eingeplant." >&2
        echo "$nummer"
        return 3
    fi
    echo "$nummer"
}

abhaengigkeit() {   # Job, neue Bedingung (leer = keine)
    if scontrol update JobId="$1" Dependency="$2"; then
        if [ -n "$2" ]; then echo "  $1: wartet auf ${2#afterany:}"; else echo "  $1: wartet auf nichts mehr"; fi
    else
        merke_fehler "Wartebedingung von $1 nicht geändert – Ausgabe oben prüfen."
        return 1
    fi
}

sammler() {   # Stand, Config-Namen -> IDs ihrer Sammeljobs, mit : getrennt
    local stand="$1" name
    shift
    for name in "$@"; do awk -F'|' -v n="h301_collect_$name" '$2 == n {print $1}' <<< "$stand"; done | sort -un | paste -sd: -
}

vorgaenger() {   # Arraynummer, Stand -> Jobs dieses Projekts mit kleinerer Nummer, mit : getrennt
    awk -F'|' -v z="$1" '$1 + 0 < z + 0 {print $1}' <<< "$2" | sort -un | paste -sd: -
}

nur_wartend() {   # Arraynummer, Stand -> 0, wenn das Array in der Queue steht und noch kein Task angelaufen ist
    awk -F'|' -v a="$1" '$1 == a {n++; if ($3 != "PENDING") l++} END {exit !(n > 0 && l == 0)}' <<< "$2" || return 1
    local konto
    if konto="$(sacct -X -n -P -j "$1" -o JobID,State 2>/dev/null)"; then
        # squeue zeigt beendete Tasks nicht; sacct schon. Ein Task jenseits von PENDING heißt: angelaufen
        awk -F'|' 'NF >= 2 && $2 !~ /^PENDING/ {exit 1}' <<< "$konto"
    else
        return 0
    fi
}

liste() {   # Teile mit : verbinden, leere und doppelte weglassen
    tr ':' '\n' <<< "$*" | tr ' ' '\n' | awk 'NF' | sort -un | paste -sd: -
}

aufraeumen_neu() {
    local job
    job="$(squeue --me -h -o "%i|%j|%Z" | awk -F'|' -v ba="$BA_ECHT" '$2 == "h301_aufraeumen" && $3 == ba {print $1}')" || job=""
    if [ -n "$job" ]; then
        scancel $job || true
        sleep 2
        (cd "$BA" && bash aufraeumen.sh --nach-jobs) \
            || merke_fehler "Aufräumen nicht neu eingeplant – später: bash aufraeumen.sh --nach-jobs"
    else
        echo "  Kein Aufräumen eingeplant."
    fi
}
