#!/usr/bin/env bash
# Version: 2026-11-07-folgelaeufe-2
# Folgeläufe nach Block A/B. Ruft submit_array.sh unverändert auf und legt keine .py-Datei an
# (der Code-Hash laufender Experimente bleibt unberührt); neu entstehen nur Configs (.json).
#
#   bash submit_folgelaeufe.sh [pruefen]
#        Stand, Warteschlange und alle Prüfungen; ändert nichts.
#   bash submit_folgelaeufe.sh start [kombination] [abstimmung] [splits] [a15] [--sofort] [--parallel=N] [--account=NAME]
#        kombination  A36_A14_plus_A32_middle (A14 + A32 auf Middle, 42 Aufgaben)
#        abstimmung   vier A32-Varianten auf Middle: Gewicht 3,0 und 0,1, eine und fünf PWMs (168 Aufgaben)
#        splits       01_basic_0p1cdo und A18 auf split_v2/v3, 30 TFs (240 Aufgaben)
#        a15          A15_PWM03_30TF_split_v2/v3 (120 Aufgaben; nur wenn ausdrücklich genannt)
#        Ohne Gruppe: kombination, abstimmung und splits, je ein Array. Die Arrays warten nur auf die Jobs,
#        die schon vorher liefen, und laufen danach parallel. --sofort: nicht warten. --parallel=N: bis zu
#        N Tasks je neuem Array (submit_array.sh setzt 8).
#   bash submit_folgelaeufe.sh vergleichen [kernel | CONFIG CONFIG ...]
#        Mittlere AUPRC je Richtung auf den gemeinsamen Läufen, ohne Argument mit Entscheidungsvorschlag
#        für die A32-Abstimmung und die Kombination; kernel: A18 gegen A14 auf allen drei Splits.
#   bash submit_folgelaeufe.sh hochskalieren CONFIG [--pwm-v2=ORDNER] [--pwm-v3=ORDNER] [--nur-v1]
#                                            [--sofort] [--parallel=N] [--account=NAME]
#        Legt aus einer Middle-Config <Name>_30TF (alle 30 TFs) und <Name>_30TF_split_v2/v3 an und reicht
#        sie ein. PWM-Configs nutzen auf v2/v3 dieselbe PWM-Bank wie auf dem Original-Split (mit dem
#        PWM-Split-Update; jeder Run vermerkt das). Eine split-eigene Bank wird genommen, wenn sie unter
#        <pwm_root>_split_v2 bzw. _split_v3 liegt oder mit --pwm-v2/--pwm-v3 angegeben ist.
#
# Ist das Aufräumen (aufraeumen.sh --nach-jobs) eingeplant, plant das Script es nach dem Einreichen neu ein,
# damit es erst nach den neuen Arrays startet.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -n "${SLURM_JOB_ID:-}" ]]; then
    echo "Abgebrochen: auf dem Login-Knoten starten, nicht in einem Slurm-Job." >&2
    exit 1
fi
exec "${ABLATION_PYTHON:-python3}" - "$ROOT" "$@" <<'FOLGELAEUFE'
import copy
import json
import math
import os
import pwd
import re
import shutil
import subprocess
import sys
import tempfile
import time
from argparse import Namespace
from pathlib import Path
from types import SimpleNamespace

root = Path(sys.argv[1]).resolve()
arguments = sys.argv[2:]
sys.path.insert(0, str(root))
CONFIGS, RESULTS, PLANS = root / "configs", root / "results", root / "plans"
ME = pwd.getpwuid(os.getuid()).pw_name
CLEANUP_JOB = "h301_aufraeumen"

A32 = "A32_pwm_target03_middle"
A14 = "A14_kernel_3_6_9_12_128c_do0p2_100epo"
A18 = "A18_kernel_7_do0p1_cdo0p1"
A36 = "A36_A14_plus_A32_middle"
B00, B01 = "00_basic", "01_basic_0p1cdo"
GROUPS = {
    "kombination": [A36],
    "abstimmung": ["A32_pwm_target03_w3p0_middle", "A32_pwm_target03_w0p1_middle",
                   "A32_pwm_target01_middle", "A32_pwm_target05_middle"],
    "splits": [B01 + "_split_v2", B01 + "_split_v3", A18 + "_split_v2", A18 + "_split_v3"],
    "a15": ["A15_PWM03_30TF_split_v2", "A15_PWM03_30TF_split_v3"],
}
DEFAULT_GROUPS = ["kombination", "abstimmung", "splits"]
GROUP_TEXT = {
    "kombination": "A14 + A32, Middle",
    "abstimmung": "A32 abstimmen, Middle",
    "splits": "01_basic und A18 auf split_v2/v3, 30 TFs",
    "a15": "A15 auf split_v2/v3 mit pwms_ranked10, 30 TFs; nur mit start a15",
}


class Same:
    """Erwarteter Wert: derselbe wie in einer anderen Config."""
    def __init__(self, name):
        self.name = name


# Woraus jede Config abgeleitet ist und was sich unterscheiden darf (alles andere muss gleich sein).
DERIVED = {
    A36: [(A32, {"predictor.params.embed_channels": 128, "predictor.params.motif_kernels": [3, 6, 9, 12],
                 "predictor.params.channel_dropout": 0.2}),
          (A14, {"predictor.factory": "model:maa_pwm_target", "predictor.params.pwm_root": Same(A32),
                 "predictor.params.pwm_count": Same(A32), "predictor.params.pwm_target_weight": Same(A32),
                 "task_profile": "middle"})],
    "A32_pwm_target03_w3p0_middle": [(A32, {"predictor.params.pwm_target_weight": 3.0})],
    "A32_pwm_target03_w0p1_middle": [(A32, {"predictor.params.pwm_target_weight": 0.1})],
    "A32_pwm_target01_middle": [(A32, {"predictor.params.pwm_count": 1})],
    "A32_pwm_target05_middle": [(A32, {"predictor.params.pwm_count": 5})],
}
REFERENCE = {A36: B01, **{name: B01 for name in GROUPS["abstimmung"]}}
for _variant in ("split_v2", "split_v3"):
    for _base in (B01, A18):
        DERIVED[f"{_base}_{_variant}"] = [(_base, {"data.params.split_variant": _variant})]
    REFERENCE[f"{B01}_{_variant}"] = f"{B00}_{_variant}"
    REFERENCE[f"{A18}_{_variant}"] = f"{B00}_{_variant}"
    REFERENCE[f"A15_PWM03_30TF_{_variant}"] = f"{B00}_{_variant}"

LEGACY = {"ablation.providers": "data", "ablation.builders": "model", "ablation.fitting": "training",
          "ablation.inference": "training", "ablation.workflows": "training", "ablation.planning": "training"}
MISSING = object()


def fail(message):
    print("Abgebrochen: " + message, file=sys.stderr)
    raise SystemExit(1)


def load(name):
    return json.loads((CONFIGS / f"{name}.json").read_text())


def flatten(value, prefix=""):
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            result.update(flatten(item, f"{prefix}.{key}" if prefix else key))
        return result
    if prefix.endswith("factory") and isinstance(value, str):
        module, sep, attr = value.partition(":")
        return {prefix: LEGACY.get(module, module) + sep + attr}
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return {prefix: float(value)}
    if isinstance(value, list):
        return {prefix: json.dumps([float(x) if isinstance(x, (int, float)) and not isinstance(x, bool) else x
                                    for x in value])}
    return {prefix: value}


def derivation_problems(name, config):
    problems = []
    if name in REFERENCE and config.get("reference") != REFERENCE[name]:
        problems.append(f"Referenz {config.get('reference')!r} statt {REFERENCE[name]!r}")
    for base, expected in DERIVED.get(name, []):
        if not (CONFIGS / f"{base}.json").is_file():
            problems.append(f"Ausgangs-Config {base} fehlt")
            continue
        new, old = flatten(config), flatten(load(base))
        wanted = {}
        for key, value in expected.items():
            wanted[key] = flatten(load(value.name)).get(key, MISSING) if isinstance(value, Same) \
                else flatten(value, key)[key]
        for key in sorted(set(new) | set(old)):
            if key.split(".")[0] in ("name", "description", "reference"):
                continue
            if key in wanted:
                if new.get(key, MISSING) != wanted[key]:
                    problems.append(f"{key} = {new.get(key, 'fehlt')} (erwartet {wanted[key]})")
            elif new.get(key, MISSING) != old.get(key, MISSING):
                problems.append(f"{key} weicht von {base} ab ({old.get(key, 'fehlt')} -> {new.get(key, 'fehlt')})")
    return problems


def squeue_rows(only_me=False):
    """Jobs mit diesem Projekt als Arbeitsordner: [(Basis-ID, Name, Zustand, Konto)]; None = nicht abfragbar."""
    if not shutil.which("squeue"):
        return None
    command = ["squeue", "--noheader", "--format=%i|%j|%Z|%T|%u"] + (["--me"] if only_me else [])
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=120)
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode:
        return None
    rows = []
    for line in result.stdout.splitlines():
        fields = [field.strip() for field in line.split("|", 4)]
        if len(fields) == 5 and fields[2] and Path(os.path.realpath(fields[2])) == root:
            rows.append((fields[0].split("_", 1)[0], fields[1], fields[3], fields[4]))
    return rows


def queued_ids(only_me=True):
    return {row[0] for row in squeue_rows(only_me) or []}


def submissions():
    states = []
    for path in sorted(PLANS.glob("*/submission.json")) if PLANS.is_dir() else []:
        try:
            state = json.loads(path.read_text())
        except (OSError, ValueError):
            continue
        if isinstance(state, dict):
            states.append((path.parent, state))
    return states


def training_or_collector(name):
    # Dieselbe Einteilung wie in submit_array.sh.
    return (name.startswith(("h301_array_", "hum301_array", "h301_collect_"))
            or re.match(r"A\d+_", name) is not None)


def show_queue():
    rows = squeue_rows()
    if rows is None:
        print("Warteschlange: squeue nicht abfragbar.")
        return None
    owners = {}
    for directory, state in submissions():
        if state.get("array_id") is not None:
            owners[str(state["array_id"])] = ("array", state.get("configs") or state.get("requested_configs") or [])
        for name, job in (state.get("collectors") or {}).items():
            owners[str(job)] = ("collect", [name])
    jobs = {}
    for job, name, state, user in rows:
        entry = jobs.setdefault(job, {"name": name, "states": set(), "user": user})
        entry["states"].add(state)
    if not jobs:
        print("Warteschlange: keine Jobs dieses Projekts.")
        return rows
    print("Warteschlange (Jobs dieses Projekts):")
    collectors = []
    for job in sorted(jobs, key=lambda x: int(x) if x.isdigit() else 0):
        entry = jobs[job]
        status = "läuft" if "RUNNING" in entry["states"] else "wartet"
        kind, configs = owners.get(job, (None, []))
        account = "" if entry["user"] == ME else f", Konto {entry['user']}"
        if entry["name"] == CLEANUP_JOB:
            print(f"  {job}  Aufräumen ({status}{account})")
        elif kind == "collect" or entry["name"].startswith("h301_collect_"):
            collectors.append(job)
        elif kind == "array":
            label = configs[0] if len(configs) == 1 else f"{configs[0]} … {configs[-1]} ({len(configs)} Configs)"
            print(f"  {job}  Array {label} ({status}{account})")
        else:
            print(f"  {job}  {entry['name']} ({status}{account})")
    if collectors:
        print(f"  dazu {len(collectors)} Sammeljob(s): {', '.join(collectors)}")
    return rows


def completed_runs(name):
    runs = RESULTS / name / "runs"
    count = 0
    for path in runs.rglob("run.json") if runs.is_dir() else []:
        try:
            count += json.loads(path.read_text()).get("status") == "completed"
        except (OSError, ValueError):
            pass
    return count


def plan_rows(path):
    import run_experiment
    arguments = Namespace(config=[str(path)], all_configs=False, manifest=CONFIGS / "caches.csv", tf=None,
                          train_assay=None, seed=None, priority_file=CONFIGS / "training_priority.csv")
    return run_experiment.make_plan(arguments)


def pwm_problems(config, rows):
    params = config["predictor"]["params"]
    if "pwm_root" not in params:
        return []
    import model
    problems = []
    for tf, assay in dict.fromkeys((row["tf"], row["train_assay"]) for row in rows):
        context = SimpleNamespace(tf=tf, train_assay=assay, config=config, artifacts=None)
        try:
            model._load_pwm_bank(context, params["pwm_root"], params["pwm_count"],
                                 params.get("sequence_length", 256), params.get("embed_channels", 64))
        except Exception as error:  # noqa: BLE001 - jeder Fehler hier hieße: Task bricht beim Start ab
            problems.append(f"{tf}/{assay}: {error}")
    return problems


def check_config(path, name=None):
    """Prüft eine Config wie beim Taskstart: Schema, Ableitung, Aufgabenplan, PWM-Bank.
    -> (Aufgaben, Probleme, Hinweise)"""
    import training
    name = name or path.stem
    try:
        config = training.load_config(path)
    except Exception as error:  # noqa: BLE001
        return [], [f"ungültig: {error}"], []
    problems, notes = [], []
    if config["name"] != name:
        problems.append(f"Name in der Datei ist {config['name']!r}")
    problems += derivation_problems(name, config)
    try:
        rows = plan_rows(path)
    except Exception as error:  # noqa: BLE001
        if "Split cache missing" not in str(error):
            return [], problems + [f"Aufgabenplan: {error}"], notes
        # submit_array.sh legt fehlende Split-Caches vor dem Planen an; die Aufgaben sind dieselben wie ohne Split.
        original = copy.deepcopy(config)
        original["data"]["params"].pop("split_variant", None)
        with tempfile.TemporaryDirectory() as temporary:
            copy_path = Path(temporary) / path.name
            copy_path.write_text(json.dumps(original))
            rows = plan_rows(copy_path)
        notes.append("Split-Caches fehlen noch, submit_array.sh legt sie vor dem Einreichen an (dauert)")
    problems += pwm_problems(config, rows)
    return rows, problems, notes


def active_configs():
    """{Config: Job} für Trainingsarrays und Sammeljobs, die noch in der Warteschlange stehen (alle Konten)."""
    queued = queued_ids(only_me=False)
    active = {}
    for _, state in submissions():
        if state.get("array_id") is not None and str(state["array_id"]) in queued:
            for name in state.get("configs") or []:
                active.setdefault(name, str(state["array_id"]))
        for name, job in (state.get("collectors") or {}).items():
            if str(job) in queued:
                active.setdefault(name, str(job))
    return active


def config_status(name, active=None):
    """-> (Text, einreichbar)"""
    path = CONFIGS / f"{name}.json"
    if not path.is_file():
        return "Config fehlt in configs/", False
    job = (active if active is not None else active_configs()).get(name)
    if job:
        return f"schon eingereicht (Job {job} in der Warteschlange) – wird übersprungen", False
    rows, problems, notes = check_config(path)
    if any("PWM run needs" in problem for problem in problems):
        return "noch nicht einreichbar: erst das PWM-Split-Update installieren (data.py lehnt die Bank sonst ab)", False
    if problems:
        return "nicht einreichbar: " + "; ".join(problems[:3]) + (" …" if len(problems) > 3 else ""), False
    if (RESULTS / name).exists():
        return (f"schon gestartet ({completed_runs(name)} von {len(rows)} Läufen fertig) – wird übersprungen; "
                f"Fehlendes ergänzen: bash submit_array.sh --restart {name}"), False
    reference = load(name)["reference"]
    if not (RESULTS / "Results_all" / f"{reference}.csv").is_file():
        notes.append(f"Referenz {reference} hat noch keine Zusammenfassung (Vergleichsspalten bleiben leer)")
    return f"bereit, {len(rows)} Aufgaben" + "".join("; " + note for note in notes), True


DATA_PWMSPLIT = "bab35d9093c9"


def program_state():
    import hashlib
    expected = {"model.py": {"5839dae12329"}, "data.py": {"51265f5843b7", DATA_PWMSPLIT},
                "training.py": {"98667ae8b452"}, "run_experiment.py": {"bfccdef0aaa8"}}
    found = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()[:12] if (root / name).is_file() else "fehlt"
             for name in expected}
    bad = [f"{name} {found[name]}" for name in expected if found[name] not in expected[name]]
    if bad:
        return "weicht vom Block-B-Stand ab (" + ", ".join(bad) + ") – die Configs sind mit dem Block-B-Stand getestet"
    return "Block-B-Stand mit PWM-Split-Update" if found["data.py"] == DATA_PWMSPLIT else \
        "Block-B-Stand (PWM-Split-Update noch nicht installiert)"


def split_bank_report(variant):
    """Welche PWM-Bank A32 mit 30 TFs auf diesem Split nutzen würde und ob das installierte data.py sie annimmt."""
    source = load(A32)
    bank = Path(source["predictor"]["params"]["pwm_root"] + "_" + variant)
    if not bank.is_dir():
        bank = Path(source["predictor"]["params"]["pwm_root"])
    config = copy.deepcopy(source)
    config["name"] = "pwm_bank_check"
    config["task_profile"] = "long"
    config["data"]["params"]["split_variant"] = variant
    config["predictor"]["params"]["pwm_root"] = str(bank)
    with tempfile.TemporaryDirectory() as temporary:
        path = Path(temporary) / "pwm_bank_check.json"
        path.write_text(json.dumps(config))
        rows, problems, _ = check_config(path)
    pairs = len({(row["tf"], row["train_assay"]) for row in rows})
    if problems:
        if any("PWM run needs" in problem for problem in problems):
            return f"{bank.name}: abgelehnt – erst das PWM-Split-Update installieren"
        return f"{bank.name}: {len(problems)} von {pairs} TF/Assay nicht nutzbar, z. B. {problems[0]}"
    return f"{bank.name} für alle {pairs} TF/Assay nutzbar"


# ------------------------------------------------------------------------------------------- Einreichen

def run_scontrol(job, setting):
    result = subprocess.run(["scontrol", "update", f"JobId={job}", setting], capture_output=True, text=True,
                            timeout=60)
    if result.returncode:
        print(f"  Warnung: scontrol update JobId={job} {setting} fehlgeschlagen: "
              + (result.stderr.strip() or result.stdout.strip()))
        return False
    return True


def submit(configs, account):
    """-> (Zustand aus submission.json oder None, fehlerfrei)"""
    before = {directory for directory, _ in submissions()}
    command = ["bash", str(root / "submit_array.sh"), *configs] + ([f"--account={account}"] if account else [])
    print("\n$ bash submit_array.sh " + " ".join(command[2:]), flush=True)
    result = subprocess.run(command, cwd=root, env=dict(os.environ, ABLATION_PYTHON=sys.executable))
    created = [(directory, state) for directory, state in submissions()
               if directory not in before and state.get("requested_configs") == configs]
    state = created[-1][1] if created else {}
    if state.get("array_id") is None:
        if result.returncode:
            print("Fehler: submit_array.sh hat dieses Array nicht eingereicht (Meldung oben).", file=sys.stderr)
        return None, result.returncode == 0
    if result.returncode:
        print("Warnung: Das Trainingsarray ist eingereicht, aber nicht jeder Sammeljob (Meldung oben).")
    return state, result.returncode == 0


def after_submit(arrays, old_ids, immediately, parallel):
    """Abhängigkeiten der neuen Arrays setzen, Parallelität setzen, Aufräumen neu einplanen."""
    if not arrays:
        return
    queued = queued_ids()
    wait = sorted(old_ids & queued, key=int)
    for state in arrays:
        job = str(state["array_id"])
        current = sorted(set(state.get("wait_for_jobs") or []), key=int)
        target = [] if immediately else wait
        if current != target:
            setting = "Dependency=" + ("afterany:" + ":".join(target) if target else "")
            if run_scontrol(job, setting):
                state["wait_for_jobs"] = target
        if parallel:
            run_scontrol(job, f"ArrayTaskThrottle={parallel}")
    print("\nNeue Arrays:")
    for state in arrays:
        configs = state.get("configs") or []
        throttle = parallel or state.get("max_parallel", 8)
        print(f"  {state['array_id']}: {state.get('task_count')} Aufgaben ({', '.join(configs)}); "
              f"bis zu {throttle} gleichzeitig; {describe_wait(state.get('wait_for_jobs'))}")
    reschedule_cleanup()


def describe_wait(jobs):
    """'startet nach 75263, 75434 (+17 Sammeljobs)' statt der vollständigen Liste."""
    if not jobs:
        return "startet sofort (sobald GPUs frei sind)"
    arrays = {str(state["array_id"]) for _, state in submissions() if state.get("array_id") is not None}
    main = [job for job in jobs if job in arrays]
    rest = len(jobs) - len(main)
    if not main:
        return "startet nach Job " + ", ".join(jobs)
    return "startet nach dem Ende von " + ", ".join(main) + (f" (+{rest} Sammeljobs)" if rest else "")


def reschedule_cleanup():
    rows = squeue_rows()
    scheduled = [row for row in rows or [] if row[1] == CLEANUP_JOB]
    if not scheduled:
        return
    job, _, state, user = scheduled[0]
    if state != "PENDING":
        print(f"\nAufräumen (Job {job}) läuft gerade – nicht verändert.")
        return
    if user != ME:
        print(f"\nAufräumen (Job {job}) gehört Konto {user} und startet vor den neuen Arrays; "
              "dieses Konto kann ihn mit scancel abbrechen und mit bash aufraeumen.sh --nach-jobs neu einplanen.")
        return
    if not (root / "aufraeumen.sh").is_file():
        print(f"\nAufräumen ist als Job {job} eingeplant, aber aufraeumen.sh fehlt – nicht verändert.")
        return
    print(f"\nAufräumen war als Job {job} eingeplant und wartete nur auf die bisherigen Jobs. Neu einplanen, "
          "damit es auch die neuen Arrays abwartet:")
    subprocess.run(["scancel", job], capture_output=True, text=True, timeout=60)
    deadline = time.monotonic() + 60
    while job in queued_ids(only_me=False) and time.monotonic() < deadline:
        time.sleep(2)
    result = subprocess.run(["bash", str(root / "aufraeumen.sh"), "--nach-jobs"], cwd=root,
                            env=dict(os.environ, ABLATION_PYTHON=sys.executable), capture_output=True, text=True)
    lines = []
    for line in (result.stdout + result.stderr).strip().splitlines():
        if line.startswith("Startet, sobald diese Jobs beendet sind:"):
            count = len([x for x in line.split(":", 1)[1].split(",") if x.strip()])
            line = f"Startet nach dem Ende aller {count} Jobs dieses Projekts, einschließlich der neuen Arrays."
        lines.append(line)
    print("  " + "\n  ".join(lines))
    if result.returncode:
        print("  Warnung: nicht neu eingeplant – später selbst: bash aufraeumen.sh --nach-jobs")


def parse_options(values, allowed):
    options, rest = {}, []
    for value in values:
        if value.startswith("--"):
            key, sep, item = value[2:].partition("=")
            if key not in allowed or (allowed[key] and not sep) or (not allowed[key] and sep):
                fail(f"Unbekannte oder unvollständige Option: {value}")
            options[key] = item if sep else True
        else:
            rest.append(value)
    if "parallel" in options and not re.fullmatch(r"[1-9][0-9]*", options["parallel"]):
        fail("--parallel=N mit einer ganzen Zahl ab 1 angeben.")
    return options, rest


def own_old_jobs():
    rows = squeue_rows(only_me=True)
    if rows is None:
        fail("squeue nicht abfragbar.")
    return {job for job, name, _, _ in rows if training_or_collector(name)}


def command_start(values):
    options, groups = parse_options(values, {"sofort": False, "parallel": True, "account": True})
    for group in groups:
        if group not in GROUPS:
            fail(f"Unbekannte Gruppe {group!r} – möglich: {', '.join(GROUPS)}.")
    groups = [group for group in GROUPS if group in groups] or list(DEFAULT_GROUPS)
    print(f"Projekt: {root}\nProgrammdateien: {program_state()}")
    active = active_configs()
    plan = {}
    for group in groups:
        print(f"\n{group} ({GROUP_TEXT[group]}):")
        plan[group] = []
        for name in GROUPS[group]:
            text, ready = config_status(name, active)
            print(f"  {name:<40} {text}")
            if ready:
                plan[group].append(name)
    if not any(plan.values()):
        print("\nNichts einzureichen.")
        return 0
    old_ids = own_old_jobs()
    arrays, ok = [], True
    for group in groups:
        if plan[group]:
            state, ok = submit(plan[group], options.get("account"))
            if state:
                arrays.append(state)
            if not ok:
                later = [g for g in groups[groups.index(group) + 1:] if plan[g]]
                if later:
                    print("Nicht mehr eingereicht: " + ", ".join(later) + " – nach der Fehlerbehebung "
                          "bash submit_folgelaeufe.sh start " + " ".join(later))
                break
    after_submit(arrays, old_ids, options.get("sofort", False), options.get("parallel"))
    print("\nStand ansehen: squeue --me | Auswertung, sobald Läufe fertig sind: bash submit_folgelaeufe.sh vergleichen")
    return 0 if ok else 1


# ------------------------------------------------------------------------------------------- Vergleichen

DIRECTIONS = [("CHIP", "CHIP"), ("GHTS", "GHTS"), ("CHIP", "GHTS"), ("GHTS", "CHIP")]
SHORT = {"CHIP": "CHS", "GHTS": "GHTS"}


def evaluations(name):
    """{(TF, Trainingsassay, Testassay, Seed): AUPRC} aus den abgeschlossenen Läufen (auch während ein Array läuft)."""
    values = {}
    runs = RESULTS / name / "runs"
    for path in sorted(runs.rglob("run.json")) if runs.is_dir() else []:
        try:
            meta = json.loads(path.read_text())
        except (OSError, ValueError):
            continue
        if meta.get("status") != "completed" or not meta.get("tf"):
            continue
        for test in ("CHIP", "GHTS"):
            try:
                metrics = json.loads((path.parent / "evaluations" / "standard" / test / "metrics.json").read_text())
            except (OSError, ValueError):
                continue
            value = (metrics.get("test_metrics") or {}).get("auprc")
            if metrics.get("status") == "completed" and isinstance(value, (int, float)) and math.isfinite(value):
                values[(meta["tf"], meta["train_assay"], test, int(meta["seed"]))] = float(value)
    summary = RESULTS / "Results_all" / f"{name}.csv"
    if not values and summary.is_file():
        # Ohne Run-Ordner (z. B. verschoben): die Zusammenfassung von collect.
        import csv
        csv.field_size_limit(sys.maxsize)
        with summary.open(newline="") as handle:
            for row in csv.DictReader(handle):
                if (row.get("row_type") == "evaluation" and row.get("included_in_summary") == "True"
                        and row.get("status") == "completed" and row.get("evaluation_id") in ("standard", "")):
                    try:
                        value = float(row["auprc"])
                        key = (row["tf"], row["train_assay"], row["test_assay"], int(float(row["seed"])))
                    except (KeyError, TypeError, ValueError):
                        continue
                    if math.isfinite(value):
                        values[key] = value
    return values


def mean(values):
    return sum(values) / len(values) if values else None


def text(value, signed=False):
    if value is None:
        return "–"
    return f"{value:+.3f}" if signed else f"{value:.3f}"


def compare(names, title):
    """Tabelle der mittleren AUPRC je Richtung auf den gemeinsamen Auswertungen aller vorhandenen Configs."""
    data = {name: evaluations(name) for name in names}
    present = [name for name in names if data[name]]
    print(f"\n{title}")
    for name in names:
        if not data[name]:
            print(f"  {name}: noch keine abgeschlossenen Läufe")
    if len(present) < 2:
        return data, set()
    common = set.intersection(*(set(data[name]) for name in present))
    width = max(len(name) for name in present) + 2
    print(f"  {'Config':<{width}}" + "".join(f"{SHORT[a] + '→' + SHORT[b]:>11}" for a, b in DIRECTIONS)
          + "   Läufe fertig")
    for name in present:
        cells = [mean([data[name][key] for key in common if key[1:3] == direction]) for direction in DIRECTIONS]
        runs = len({key[:2] + key[3:] for key in data[name]})
        print(f"  {name:<{width}}" + "".join(f"{text(value):>11}" for value in cells) + f"   {runs:>5}")
    per_direction = ", ".join(f"{SHORT[a]}→{SHORT[b]} {sum(1 for key in common if key[1:3] == (a, b))}"
                              for a, b in DIRECTIONS)
    print(f"  Mittel über die gemeinsamen Auswertungen ({per_direction}).")
    return data, common


def delta(data, common, name, other, direction):
    keys = [key for key in common if key[1:3] == direction]
    if not keys or name not in data or other not in data or not data[name] or not data[other]:
        return None, 0, 0
    values = [data[name][key] - data[other][key] for key in keys]
    return mean(values), sum(1 for value in values if value > 0), len(keys)


def complete(name, data):
    runs = len({key[:2] + key[3:] for key in data.get(name, {})})
    try:
        expected = len(plan_rows(CONFIGS / f"{name}.json"))
    except Exception:  # noqa: BLE001
        expected = None
    return runs, expected


def decide_tuning():
    names = [B01, A32] + GROUPS["abstimmung"]
    data, common = compare(names, "A32 abstimmen (Middle) – mittlere AUPRC")
    if not data[A32] or not common:
        return
    cross, ins = ("CHIP", "GHTS"), [("CHIP", "CHIP"), ("GHTS", "GHTS")]
    print("  Gegenüber A32 (Δ = Mittel der gepaarten Differenzen; Siege = TFs, in denen die Variante besser ist):")
    candidates = [(mean([data[A32][k] for k in common if k[1:3] == cross]) or 0.0, A32)]
    for name in GROUPS["abstimmung"]:
        if not data[name]:
            continue
        value, wins, count = delta(data, common, name, A32, cross)
        in_deltas = [delta(data, common, name, A32, direction)[0] for direction in ins]
        keeps = all(d is not None and d >= 0 for d in in_deltas)
        print(f"    {name:<32} CHS→GHTS {text(value, True)} ({wins}/{count})   CHS→CHS {text(in_deltas[0], True)}"
              f"   GHTS→GHTS {text(in_deltas[1], True)}   " + ("In-Assay gehalten" if keeps else "In-Assay verloren"))
        if keeps and value is not None:
            candidates.append((candidates[0][0] + value, name))
    best = max(candidates)[1]
    unfinished = [f"{name} {runs}/{expected}" for name in [A32] + GROUPS["abstimmung"]
                  for runs, expected in [complete(name, data)] if expected and runs < expected]
    suffix = f" (vorläufig, noch nicht fertig: {', '.join(unfinished)})" if unfinished else ""
    print(f"  Vorschlag: {best}{suffix}")
    print("    Regel: höchste CHS→GHTS-AUPRC unter A32 und den Varianten, die in CHS→CHS und GHTS→GHTS nicht "
          "unter A32 liegen.")
    print(f"    Hochskalieren: bash submit_folgelaeufe.sh hochskalieren {best}")


def decide_combination():
    data, common = compare([B01, A14, A32, A36], "Kombination A14 + A32 (Middle) – mittlere AUPRC")
    if not data[A36] or not common or not data[A14] or not data[A32]:
        return
    cross = ("CHIP", "GHTS")
    score = {name: mean([data[name][k] for k in common if k[1:3] == cross]) for name in (A14, A32, A36)}
    if None in score.values():
        return
    better = A14 if score[A14] >= score[A32] else A32
    value, wins, count = delta(data, common, A36, better, cross)
    in_deltas = [delta(data, common, A36, better, direction)[0] for direction in [("CHIP", "CHIP"), ("GHTS", "GHTS")]]
    ok = value is not None and value >= 0 and all(d is not None and d >= 0 for d in in_deltas)
    print(f"  Bessere Einzeländerung in CHS→GHTS: {better}. Kombination dagegen: CHS→GHTS {text(value, True)} "
          f"({wins}/{count}), CHS→CHS {text(in_deltas[0], True)}, GHTS→GHTS {text(in_deltas[1], True)}.")
    unfinished = [f"{name} {runs}/{expected}" for name in (A14, A32, A36)
                  for runs, expected in [complete(name, data)] if expected and runs < expected]
    suffix = f" (vorläufig, noch nicht fertig: {', '.join(unfinished)})" if unfinished else ""
    print(f"  Kriterium (CHS→GHTS mindestens so gut, In-Assay nicht schlechter): "
          f"{'erfüllt' if ok else 'nicht erfüllt'}{suffix}")
    if ok:
        print(f"    Hochskalieren: bash submit_folgelaeufe.sh hochskalieren {A36}")


def command_compare(values):
    if not values:
        decide_tuning()
        decide_combination()
    elif values == ["kernel"]:
        for label, suffix in (("Original-Split", ""), ("split_v2", "_split_v2"), ("split_v3", "_split_v3")):
            compare([B00 + suffix, A14 + suffix, A18 + suffix], f"Kernel-Entscheidung, {label} – mittlere AUPRC")
    else:
        for name in values:
            if not ((CONFIGS / f"{name}.json").is_file() or (RESULTS / name).is_dir()
                    or (RESULTS / "Results_all" / f"{name}.csv").is_file()):
                fail(f"Unbekannte Config: {name}")
        data, common = compare(values, "Vergleich – mittlere AUPRC")
        if common:
            print(f"  Gegenüber {values[0]} (Δ und Siege je Richtung):")
            for name in values[1:]:
                cells = []
                for direction in DIRECTIONS:
                    value, wins, count = delta(data, common, name, values[0], direction)
                    cells.append(f"{SHORT[direction[0]]}→{SHORT[direction[1]]} {text(value, True)} ({wins}/{count})")
                print(f"    {name}: " + "   ".join(cells))
    return 0


# ------------------------------------------------------------------------------------------- Hochskalieren

def command_scale(values):
    options, names = parse_options(values, {"pwm-v2": True, "pwm-v3": True, "nur-v1": False, "sofort": False,
                                            "parallel": True, "account": True})
    if len(names) != 1:
        fail("Genau eine Middle-Config angeben, z. B. bash submit_folgelaeufe.sh hochskalieren " + A32)
    name = names[0]
    if not (CONFIGS / f"{name}.json").is_file():
        fail(f"Config fehlt: configs/{name}.json")
    source = load(name)
    if source.get("task_profile") != "middle":
        fail(f"{name} ist keine Middle-Config.")
    base = name[: -len("_middle")] if name.endswith("_middle") else name
    first = copy.deepcopy(source)
    first["name"] = base + "_30TF"
    first["task_profile"] = "long"
    description = source.get("description", "")
    first["description"] = (description.replace("middle TF profile", "all 30 TFs (long profile)")
                            if "middle TF profile" in description else description + " All 30 TFs (long profile).")
    first["description"] += f" Scaled-up copy of {name}."
    wanted, skipped = [first], []
    for variant, option in (("split_v2", "pwm-v2"), ("split_v3", "pwm-v3")):
        if options.get("nur-v1"):
            break
        config = copy.deepcopy(first)
        config["name"] += "_" + variant
        config["reference"] += "_" + variant
        config["description"] += " Chromosome split: " + variant + "."
        config["data"]["params"]["split_variant"] = variant
        if not (CONFIGS / f"{config['reference']}.json").is_file():
            skipped.append(f"{variant}: Referenz-Config {config['reference']} fehlt")
            continue
        params = config["predictor"]["params"]
        if "pwm_root" in params:
            if option in options:
                bank = Path(options[option]).expanduser().resolve()
                if not bank.is_dir():
                    skipped.append(f"{variant}: PWM-Bank fehlt ({bank})")
                    continue
                params["pwm_root"] = str(bank)
            elif Path(params["pwm_root"] + "_" + variant).is_dir():
                params["pwm_root"] = params["pwm_root"] + "_" + variant
        wanted.append(config)
    print(f"Projekt: {root}\nProgrammdateien: {program_state()}\n\nHochskalieren von {name}:")
    ready, active = [], active_configs()
    with tempfile.TemporaryDirectory() as temporary:
        for config in wanted:
            target = CONFIGS / f"{config['name']}.json"
            if config["name"] in active:
                print(f"  {config['name']:<44} schon eingereicht (Job {active[config['name']]} in der Warteschlange) "
                      "– übersprungen")
                continue
            if target.is_file() and json.loads(target.read_text()) != config:
                print(f"  {config['name']:<44} configs/ enthält eine abweichende Fassung – nicht verändert, "
                      "übersprungen")
                continue
            path = Path(temporary) / f"{config['name']}.json"
            path.write_text(json.dumps(config, indent=2) + "\n")
            rows, problems, notes = check_config(path, config["name"])
            if problems:
                if any("PWM run needs" in problem for problem in problems):
                    print(f"  {config['name']:<44} übersprungen: das installierte data.py lehnt die PWM-Bank auf "
                          "diesem Split noch ab – erst das PWM-Split-Update installieren, dann denselben Befehl "
                          "wiederholen")
                else:
                    print(f"  {config['name']:<44} übersprungen: {len(problems)} Problem(e), z. B. {problems[0]}")
                continue
            if (RESULTS / config["name"]).exists():
                print(f"  {config['name']:<44} schon gestartet ({completed_runs(config['name'])} von {len(rows)} "
                      f"Läufen fertig) – übersprungen; Fehlendes: bash submit_array.sh --restart {config['name']}")
                continue
            if not target.is_file():
                shutil.copyfile(path, target)
                note = "neu angelegt"
            else:
                note = "Config schon vorhanden"
            bank = config["predictor"]["params"].get("pwm_root")
            if bank and config["data"]["params"].get("split_variant", "original") != "original":
                notes.append(f"PWM-Bank {Path(bank).name}")
            print(f"  {config['name']:<44} {note}, {len(rows)} Aufgaben" + "".join("; " + n for n in notes))
            ready.append(config["name"])
    for line in skipped:
        print(f"  übersprungen – {line}")
    if not ready:
        print("\nNichts einzureichen.")
        return 0
    old_ids = own_old_jobs()
    state, ok = submit(ready, options.get("account"))
    after_submit([state] if state else [], old_ids, options.get("sofort", False), options.get("parallel"))
    return 0 if ok else 1


# ------------------------------------------------------------------------------------------- Prüfen

def command_check(values):
    if values:
        fail("pruefen hat keine weiteren Argumente.")
    print(f"Projekt: {root}\nProgrammdateien: {program_state()}")
    rows = show_queue()
    if rows:
        if any(training_or_collector(name) and user == ME for _, name, _, user in rows):
            print("  Neue Arrays warten auf diese Trainings-/Sammeljobs und laufen danach parallel; "
                  "mit --sofort starten sie gleich.")
        if any(name == CLEANUP_JOB for _, name, _, _ in rows):
            print("  Das eingeplante Aufräumen wird beim Einreichen neu eingeplant, damit es die neuen Arrays "
                  "abwartet.")
    total, active = 0, active_configs()
    for group, names in GROUPS.items():
        print(f"\n{group} ({GROUP_TEXT[group]}):")
        for name in names:
            status, ready = config_status(name, active)
            print(f"  {name:<40} {status}")
            if ready and group in DEFAULT_GROUPS:
                total += int(re.search(r"(\d+) Aufgaben", status).group(1))
    print(f"\nEinreichbar: {total} Aufgaben.  Einreichen: bash submit_folgelaeufe.sh start [--sofort] [--parallel=N]")
    print("\nSpäter (hochskalieren auf 30 TFs × 3 Splits): PWM-Bank für A32 und die Kombination auf v2/v3")
    for variant in ("split_v2", "split_v3"):
        try:
            report = split_bank_report(variant)
        except Exception as error:  # noqa: BLE001
            report = f"nicht prüfbar: {error}"
        print(f"  {variant}: {report}")
    return 0


def main():
    if not arguments or arguments[0] == "pruefen":
        return command_check(arguments[1:])
    command, rest = arguments[0], arguments[1:]
    if command == "start":
        return command_start(rest)
    if command == "vergleichen":
        return command_compare(rest)
    if command == "hochskalieren":
        return command_scale(rest)
    if command in ("hilfe", "-h", "--help"):
        print(Path(root / "submit_folgelaeufe.sh").read_text().split("set -euo pipefail")[0])
        return 0
    fail(f"Unbekannter Befehl {command!r} – pruefen, start, vergleichen, hochskalieren oder hilfe.")


try:
    raise SystemExit(main())
except KeyboardInterrupt:
    raise SystemExit(130)
FOLGELAEUFE
