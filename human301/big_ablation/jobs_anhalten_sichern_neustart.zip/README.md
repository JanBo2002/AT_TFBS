# Wartende Jobs anhalten, alten Code sichern und später fortsetzen

Im bisherigen `big_ablation` auf dem Login-Knoten mit aktiviertem `at_env`
ausführen. Das Paket enthält keine zusätzliche `.py`-Datei, die bereits beim
Entpacken die Versionskennung der laufenden Serie ändern würde.

## Jetzt: sichern, wartende alte Tasks abmelden und patchen

```bash
cd /data/projects/SFB_A03/jan/AT_TFBS/human301/big_ablation
unzip jobs_anhalten_sichern_neustart.zip -d altcode_restart_v2
bash altcode_restart_v2/jobs_sichern_neustarten.sh sichern --patch altcode_restart_v2/embedder_depth.patch
```

Ohne `--patch ...` werden der alte Code gesichert und die wartenden alten
Tasks abgemeldet. Das Patchen kann dann separat erfolgen.

Das Script liest die aktuelle Queue und bearbeitet nur die Trainingsarrays
und zugehörigen Sammler aus diesem `big_ablation`-Verzeichnis. Wartende
Patch-Jobs aus dem früheren Automatikpaket werden ebenfalls gehalten.
Mit `--arrays 73906 73916 73918` können konkrete Arrays angegeben werden;
weitere aktive Arrays im selben Ordner müssen dann ebenfalls einbezogen
werden, damit sie nach einem Codewechsel nicht unvermittelt starten.

- `scontrol hold` verhindert neue Starts. Laufende Jobs werden dabei nicht
  suspendiert oder abgebrochen; die ArrayTaskThrottle wird nicht verändert.
- Die aktuelle Versionskennung wird mit den Ergebnissen der betroffenen
  Konfigurationen abgeglichen. Passt sie nicht, bleibt die Queue gehalten,
  aber der Code wird nicht als Original bestätigt und nicht gepatcht.
- Alle zur Framework-Kennung gehörenden Python-Dateien, die Shell- und
  Slurm-Scripts, Konfigurationen und ursprünglichen Aufgabenpläne werden
  gesichert. Für externe Factories wie `mex_pwm_model` werden die auffindbaren
  Python-Dateien zusätzlich mit eigenen Prüfsummen gesichert. Der alte
  Framework-Code-Hash allein enthält diese externen Dateien nicht.
- Pro Konfiguration liegt danach ein Archiv im bisherigen Ergebnisordner:
  `results/<CONFIG>/code_vor_patch_<Sicherung>.zip`. Es wird nicht für jeden
  TF erneut gespeichert. Wo möglich teilen die Archivnamen denselben
  Speicherplatz über Hardlinks.
- Die selbständige Neustart-Steuerung liegt unter
  `results/Code_snapshots/<Sicherung>/`.
- Nach bestätigter Sicherung werden die wartenden alten Trainings und Sammler
  mit expliziten Pending-Task-IDs und `--state=PENDING` aus der Queue genommen.
  Laufende Task-IDs werden dabei nicht ausgewählt. Das ist nötig, damit der
  normale Launcher neue Einreichungen nicht hinter gehaltene alte Restaufgaben
  stellt. Erst danach wird der optionale Patch angewendet.
- Erst nach bestätigter Sicherung wird bei `--patch` der beigefügte
  Embedder-Patch auf `model.py` und `training.py` angewendet. Dafür muss nicht
  auf das Ende der laufenden Trainings gewartet werden. Bereits laufende
  Python-Prozesse verwenden ihr geladenes Modell weiter. Das Script startet
  jetzt keine zusätzlichen Trainings.

Damit steht der konkrete Embedder-Patch nach diesem Aufruf im bisherigen
Arbeitsordner bereit. Ein fester Uhrzeittermin wird nicht über Slurm geplant;
die Sicherung und das Patchen laufen direkt beim Aufruf.

## Dazwischen: andere Jobs einreichen

Nach erfolgreichem Sichern und Patchen kannst du die gewünschten anderen
Konfigurationen über `submit_array.sh` einreichen. Der Launcher wartet noch
auf eventuell laufende alte Trainings, aber nicht auf die abgemeldeten alten
Restaufgaben. Der alte Neustart wird nicht automatisch ausgeführt.

## Später: exakt den alten Code weiterverwenden

Wenn du mit den bevorzugten anderen Trainings fertig bist, den am Ende der
Sicherung ausgegebenen Neustartbefehl ausführen. Er sieht so aus:

```bash
bash /data/projects/SFB_A03/jan/AT_TFBS/human301/big_ablation/results/Code_snapshots/<Sicherung>/neustart.sh
```

Optional kann `--account NAME` angehängt werden. Auf dem Login-Knoten in
`at_env` starten. Der Befehl prüft die Queue erneut und verweigert den Neustart,
solange noch Trainings laufen. So werden keine laufenden Ergebnisordner
umgeordnet und die gemeinsame Grenze von acht Trainings bleibt gewahrt.

Der Neustart prüft das Archiv, entpackt die Originaldateien in einen
separaten Nachbarordner `big_ablation_frozen_<Sicherung>` und kontrolliert
die unveränderte Framework-Kennung sowie die zusätzlichen externen Dateien.
Die gefrorene Umgebung schreibt über eine Verknüpfung weiterhin in die
bisherigen `results/`-Ordner. Eingabedaten und Caches werden nicht dupliziert.
Relative Pfade auf Nachbarordner, etwa PWM-Daten, bleiben erhalten.

Falls noch wartende Originaltasks vorhanden sind, werden ausschließlich diese
mit einem ausdrücklichen `PENDING`-Filter abgemeldet. Laufende Jobs werden
nicht abgebrochen. Der bisherige native Launcher reicht aus dem gesicherten
Aufgabenplan nur die fehlenden oder unvollständigen TF/Assay/Seed-Läufe neu
ein, maximal acht gleichzeitig. Abgeschlossene Läufe bleiben bestehen;
unvollständige Versuche werden nach dem vorhandenen Restart-Verfahren
archiviert. Die CSV-Zusammenfassungen laufen wie bisher pro Konfiguration.

Für die alten Konfigurationen das ausgegebene `neustart.sh` verwenden, damit
sie ihren gesicherten Code verwenden und nicht den inzwischen geänderten
Arbeitsordner. Es gibt keine Ausnahme von der Versionsprüfung.

## Geprüft

Die Slurm-Steuerung wurde lokal simuliert. Geprüft wurden: laufende Jobs
bleiben aktiv, Pending-Tasks und Sammler werden nach der Sicherung abgemeldet, Sicherungen liegen
bei den Konfigurationen, falscher Originalcode und veränderte Archive werden
abgewiesen, der Neustart verwendet trotz späterer Änderungen am Original und
PWM-Helfer den alten Code, abgeschlossene Läufe bleiben erhalten, nur die
ursprünglich geplanten Restläufe werden eingereicht und `%8` bleibt bestehen.
Es wurden von dieser Chat-Sitzung keine echten Clusterjobs verändert.
