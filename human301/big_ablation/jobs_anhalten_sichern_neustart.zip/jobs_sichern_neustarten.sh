#!/usr/bin/env bash
set -euo pipefail
HUM301_FREEZE_SCRIPT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/$(basename -- "${BASH_SOURCE[0]}")"
exec "${ABLATION_PYTHON:-python3}" - "$HUM301_FREEZE_SCRIPT" "$@" <<'HUM301_FROZEN_RESTART'
import argparse
import csv
from datetime import datetime
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import shutil
import subprocess
import sys
import zipfile

controller = Path(sys.argv[1]).resolve()
parser = argparse.ArgumentParser()
sub = parser.add_subparsers(dest='command', required=True)
save_parser = sub.add_parser('sichern')
save_parser.add_argument('--arrays', nargs='+', default=[])
save_parser.add_argument('--patch', type=Path)
restart_parser = sub.add_parser('neustart')
restart_parser.add_argument('manifest', type=Path)
restart_parser.add_argument('--account')
args = parser.parse_args(sys.argv[2:])
env = {key: value for key, value in os.environ.items()
       if not key.startswith('SBATCH_') and key not in {'SLURM_CLUSTERS', 'SLURM_FEDERATION', 'ABLATION_ALLOW_CODE_VERSION_MISMATCH'}}
env.update(LC_ALL='C', ABLATION_PYTHON=sys.executable)

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def run(command, cwd, *, check=True, capture=True):
    result = subprocess.run(command, cwd=cwd, env=env, text=True,
                            capture_output=capture, timeout=180)
    if check and result.returncode:
        raise RuntimeError(f'{command[0]} fehlgeschlagen: '
                           + ((result.stderr or result.stdout or '').strip()))
    return result

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), default=str).encode()).hexdigest()

def python_bytes(root):
    return {str(path.relative_to(root)): path.read_bytes()
            for path in sorted(root.rglob('*.py'))
            if 'results' not in path.relative_to(root).parts and '__pycache__' not in path.parts}

def code_hash(files):
    result = hashlib.sha256()
    # Match sorted(Path(...)) in the original package_hash, including a.py
    # versus a/module.py (path-component order differs from string order).
    for name in sorted(files, key=lambda value: Path(value).parts):
        result.update(name.encode())
        result.update(files[name])
    return result.hexdigest()

def queue(cwd):
    rows = []
    output = run(['squeue', '--me', '--array', '--noheader', '--format=%i|%j|%T|%Z|%r'], cwd).stdout
    for line in output.splitlines():
        fields = [field.strip() for field in line.split('|', 4)]
        if len(fields) != 5:
            continue
        job, name, state, directory, reason = fields
        parent = job.split('_', 1)[0]
        require(parent.isdigit(), 'Unbekanntes Job-ID-Format: ' + job)
        rows.append(dict(job=job, parent=parent, name=name, state=state,
                         directory=str(Path(directory).resolve()) if directory else '', reason=reason))
    return rows

def training_job(name):
    return name.startswith(('h301_array_', 'hum301_array')) or re.match(r'A\d+_', name)

def selected_rows(rows, root):
    return [row for row in rows if row['directory'] == str(root)]

def hold(identifiers, root):
    if identifiers:
        result = run(['scontrol', 'hold', *sorted(identifiers, key=int)], root, check=False)
        after = queue(root)
        bad = [row['job'] for row in after if row['parent'] in identifiers
               and row['state'] == 'PENDING' and 'Held' not in row['reason']]
        require(not bad, 'Nicht alle wartenden Tasks sind gehalten: ' + ', '.join(bad)
                + '\n' + (result.stderr or ''))
        return after
    return queue(root)

def remove_pending(identifiers, root):
    pending = sorted({row['job'] for row in queue(root)
                      if row['parent'] in identifiers and row['state'] == 'PENDING'})
    require(all(re.fullmatch(r'[0-9]+(?:_[0-9]+)?', job) for job in pending),
            'Pending-Tasks nicht einzeln aufgelöst; zur Sicherheit keine Abmeldung.')
    if pending:
        # Explicit task IDs and a state filter: no RUNNING task is targeted.
        run(['scancel', '--quiet', '--state=PENDING', *pending], root)
    remaining = [row['job'] for row in queue(root)
                 if row['parent'] in identifiers and row['state'] == 'PENDING']
    require(not remaining, 'Wartende alte Tasks noch vorhanden: ' + ', '.join(remaining))
    return pending

def check_run_versions(root, configs, expected):
    for name in configs:
        experiment = root / 'results' / name
        versions = experiment / 'versions.txt'
        if versions.exists():
            hashes = re.findall(r'^code_sha256:\s*(\S+)', versions.read_text(), re.M)
            require(not hashes or hashes[-1] == expected,
                    f'{name}: vorhandene Versionskennung passt nicht zum aktuellen Dateisatz. '
                    'Keine falsche Originalversion sichern; frühere Dateien müssen erst rekonstruiert werden.')
        for path in (experiment / 'runs').glob('**/run.json'):
            meta = json.loads(path.read_text())
            if meta.get('status') in {'running', 'completed'} and meta.get('code_hash'):
                require(meta['code_hash'] == expected,
                        f'{path}: Lauf und aktueller Python-Code haben verschiedene Kennungen. '
                        'Die Jobs bleiben gehalten; dieser Code wird nicht als Original bestätigt.')

def plan_groups(root, arrays):
    groups = []
    for array in sorted(arrays, key=int):
        candidates = []
        for path in (root / 'plans').glob('*/submission.json'):
            try:
                state = json.loads(path.read_text())
            except (OSError, ValueError):
                continue
            if str(state.get('array_id')) == array:
                candidates.append((path, state))
        require(len(candidates) == 1, f'Genau ein Einreichungsplan für Array {array} nötig; gefunden: {len(candidates)}.')
        path, state = candidates[0]
        plan = Path(state.get('plan', path.parent / 'tasks.csv'))
        require(plan.is_file(), f'Aufgabenplan fehlt: {plan}')
        with plan.open(newline='') as handle:
            reader = csv.DictReader(handle)
            fields = list(reader.fieldnames or [])
            rows = list(reader)
        require(rows and {'config_path', 'config_hash', 'tf', 'train_assay', 'seed',
                          'training_scope', 'cache_paths_json'} <= set(fields), f'Ungültiger Aufgabenplan: {plan}')
        groups.append(dict(array=array, configs=state.get('configs', []),
                           state_path=str(path), plan=str(plan), fields=fields, rows=rows,
                           collectors=state.get('collectors', {})))
    return groups

def freeze_external(root, configurations):
    # Custom PWM factories can live beside big_ablation and are outside the
    # framework's code_hash. Freeze their Python files separately as well.
    factories = []
    def visit(value):
        if isinstance(value, dict):
            if isinstance(value.get('factory'), str):
                factories.append(value['factory'].split(':', 1)[0])
            for child in value.values(): visit(child)
        elif isinstance(value, list):
            for child in value: visit(child)
    for config in configurations.values(): visit(config)
    search = [root] + [Path(p).expanduser().resolve() for p in env.get('PYTHONPATH', '').split(os.pathsep) if p]
    search.append(root.parent / 'pwm_extensions')
    folders = []
    for module in sorted(set(factories)):
        if module in {'model', 'data', 'training', 'run_experiment'} or module.startswith('ablation.'):
            continue
        found = next((folder for folder in search
                      if (folder.joinpath(*module.split('.')).with_suffix('.py')).is_file()
                      or (folder.joinpath(*module.split('.')) / '__init__.py').is_file()), None)
        require(found is not None, f'Externe Factory {module} nicht gefunden. PYTHONPATH wie beim ursprünglichen Submit setzen.')
        if found == root or found.is_relative_to(root):
            continue
        if found not in folders: folders.append(found)
    extra, paths = {}, []
    for index, folder in enumerate(folders):
        key = f'{index:02d}_{folder.name}'
        paths.append(key)
        for path in sorted(folder.rglob('*.py')):
            if '__pycache__' not in path.parts:
                extra[key + '/' + str(path.relative_to(folder))] = path.read_bytes()
    return extra, paths

def save():
    root = Path.cwd().resolve()
    require(all((root / name).is_file() for name in ('model.py', 'training.py', 'data.py', 'run_experiment.py',
                                                      'submit_array.sh', 'train_array.sbatch', 'collect_config.sbatch',
                                                      'configs/caches.csv')),
            'Im bisherigen big_ablation-Verzeichnis ausführen.')
    require(all(shutil.which(name) for name in ('squeue', 'scontrol')), 'squeue und scontrol fehlen.')
    before = selected_rows(queue(root), root)
    discovered = {row['parent'] for row in before if training_job(row['name'])}
    arrays = set(args.arrays) if args.arrays else discovered
    require(arrays and all(value.isdigit() for value in arrays), 'Keine Trainingsarrays gefunden; bei Bedarf --arrays JOBID ... angeben.')
    require(not (discovered - arrays), 'Weitere Arrays aus diesem Verzeichnis könnten neuen Code laden. Auch anhalten: ' + ', '.join(sorted(discovered - arrays)))
    groups = plan_groups(root, arrays)
    held = {row['parent'] for row in before if row['parent'] in arrays
            or row['name'].startswith('h301_collect_') or row['name'] == 'h301_depth_patch'}
    held.update(str(value) for group in groups for value in group['collectors'].values()
                if str(value) in {row['parent'] for row in before})
    after = hold(held, root)
    running = [row['job'] for row in after if row['parent'] in arrays and row['state'] != 'PENDING']
    print('Neue Starts gehalten. Weiterlaufende Tasks: ' + (', '.join(running) or 'keine'), flush=True)

    files = python_bytes(root)
    require(files, 'Keine Python-Dateien zum Sichern gefunden.')
    expected = code_hash(files)
    configurations, task_rows, fields = {}, [], []
    identities = set()
    for group in groups:
        for field in group['fields']:
            if field not in fields: fields.append(field)
        for row in group['rows']:
            name = Path(row['config_path']).stem
            candidates = [Path(row['config_path']), root / 'results' / name / 'config.json']
            matching = []
            for path in candidates:
                if path.is_file():
                    config = json.loads(path.read_text())
                    if digest(config) == row['config_hash']: matching.append(config)
            require(matching, f'Keine unveränderte Konfiguration für {name} und den ursprünglichen Plan gefunden.')
            require(name not in configurations or configurations[name] == matching[0], f'Mehrere Versionen von {name} in den Plänen.')
            configurations[name] = matching[0]
            key = (name, row['tf'], row['train_assay'], int(row['seed']))
            if key not in identities:
                identities.add(key)
                task_rows.append(row)
    check_run_versions(root, configurations, expected)
    extra, external_paths = freeze_external(root, configurations)
    payload = {'project/' + name: value for name, value in files.items()}
    for pattern in ('*.sh', '*.sbatch'):
        for path in root.glob(pattern): payload['project/' + path.name] = path.read_bytes()
    for path in (root / 'configs').rglob('*'):
        if path.is_file() and path.suffix in {'.json','.csv','.tsv','.txt','.pwm','.pfm','.meme','.yaml','.yml','.md'}:
            payload['project/' + str(path.relative_to(root))] = path.read_bytes()
    for name, config in configurations.items():
        payload['project/configs/' + name + '.json'] = (json.dumps(config, indent=2) + '\n').encode()
    payload.update({'external/' + name: value for name, value in extra.items()})
    require(code_hash(python_bytes(root)) == expected, 'Code wurde während der Sicherung geändert. Nicht patchen; Sicherung wiederholen.')

    stamp = datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + expected[:12]
    destination = root / 'results' / 'Code_snapshots' / stamp
    destination.mkdir(parents=True)
    archive = destination / 'original_code.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as target:
        for name, content in sorted(payload.items()): target.writestr(name, content)
    require(zipfile.ZipFile(archive).testzip() is None, 'Archivprüfung fehlgeschlagen.')
    for name in configurations:
        target = root / 'results' / name / ('code_vor_patch_' + stamp + '.zip')
        target.parent.mkdir(parents=True, exist_ok=True)
        try: os.link(archive, target)
        except OSError: shutil.copyfile(archive, target)
    saved_controller = destination / 'steuerung.sh'
    shutil.copyfile(controller, saved_controller)
    manifest = dict(schema=1, root=str(root), source_hash=expected,
                    archive=str(archive), archive_hash=hashlib.sha256(archive.read_bytes()).hexdigest(),
                    configs=list(configurations), arrays=sorted(arrays, key=int), held_jobs=sorted(held, key=int),
                    external_paths=external_paths, external_hashes={name:hashlib.sha256(value).hexdigest() for name,value in extra.items()},
                    fields=fields, rows=task_rows, running_at_snapshot=running)
    manifest_path = destination / 'manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    restart = destination / 'neustart.sh'
    restart.write_text('#!/usr/bin/env bash\nset -euo pipefail\nexec bash ' + shlex.quote(str(saved_controller))
                       + ' neustart ' + shlex.quote(str(manifest_path)) + ' "$@"\n')
    print(f'Gesichert und mit laufenden Ergebnissen abgeglichen: {expected}', flush=True)
    print('Codearchiv liegt in jedem betroffenen results/<CONFIG>-Ordner.', flush=True)
    print('Späterer Neustart: bash ' + shlex.quote(str(restart)), flush=True)
    removed = remove_pending(held, root)
    manifest['removed_pending_jobs'] = removed
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'{len(removed)} wartende alte Tasks/Sammler aus der Queue genommen; laufende Tasks bleiben aktiv.', flush=True)
    if args.patch:
        patch = args.patch.expanduser().resolve()
        command = ['patch', '--batch', '--forward', '--fuzz=0', '--no-backup-if-mismatch', '-p1', '-i', str(patch)]
        require(shutil.which('patch') and patch.is_file(), 'Patch-Datei oder Programm patch fehlt; Originalcode ist gesichert.')
        run([*command, '--dry-run'], root)
        require(code_hash(python_bytes(root)) == expected, 'Code hat sich seit der Sicherung geändert; Patch nicht angewendet.')
        run(command, root, capture=False)
        print('Patch im bisherigen Arbeitsordner angewendet. Laufende Prozesse wurden nicht unterbrochen.', flush=True)
    print('Keine laufenden Jobs abgebrochen; keine ArrayTaskThrottle geändert.', flush=True)

def restart():
    state = json.loads(args.manifest.expanduser().resolve().read_text())
    root = Path(state['root']).resolve()
    require(all(shutil.which(name) for name in ('squeue', 'scontrol', 'scancel', 'sbatch')), 'Slurm-Befehle fehlen.')
    hold(set(state['held_jobs']), root)
    rows = queue(root)
    active = [row['job'] for row in rows if (training_job(row['name']) or row['parent'] in state['held_jobs'])
              and row['state'] != 'PENDING']
    require(not active, 'Noch laufende Trainings oder Sammeljobs werden nicht unterbrochen. Erst danach neu starten: ' + ', '.join(active))
    others = [row['parent'] for row in rows if training_job(row['name']) and row['parent'] not in state['arrays']]
    require(not others, 'Andere Trainingsarrays sind bereits eingereiht. Für die gemeinsame Acht-Job-Grenze zuerst deren Reihenfolge klären: ' + ', '.join(sorted(set(others))))
    archive = Path(state['archive'])
    require(hashlib.sha256(archive.read_bytes()).hexdigest() == state['archive_hash'], 'Gesichertes Archiv wurde verändert.')
    # Sibling directories preserve relative paths such as ../pwm_channels and
    # avoid a recursive results symlink inside results/<CONFIG>/.
    token = Path(state['archive']).parent.name
    frozen = root.with_name(root.name + '_frozen_' + token)
    external = root.with_name(root.name + '_frozen_external_' + token)
    frozen.mkdir(exist_ok=True)
    external.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as source:
        for name in source.namelist():
            relative = PurePosixPath(name)
            require(not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] in {'project','external'}, 'Ungültiger Archivpfad.')
            base = frozen if relative.parts[0] == 'project' else external
            target = base.joinpath(*relative.parts[1:])
            content = source.read(name)
            if target.exists(): require(target.read_bytes() == content, f'Gefrorene Datei wurde verändert: {target}')
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
    require(code_hash(python_bytes(frozen)) == state['source_hash'], 'Gefrorener Code hat nicht die ursprüngliche Kennung.')
    for name, expected in state.get('external_hashes', {}).items():
        require(hashlib.sha256((external / name).read_bytes()).hexdigest() == expected, 'Externe Factory wurde verändert: ' + name)
    check_run_versions(root, state['configs'], state['source_hash'])
    results = frozen / 'results'
    if not results.exists(): results.symlink_to(root / 'results', target_is_directory=True)
    require(results.is_symlink() and results.resolve() == (root / 'results').resolve(), 'Falscher Ergebnisordner in der gefrorenen Umgebung.')
    for directory in root.iterdir():
        if directory.is_dir() and directory.name not in {'results','plans','configs','__pycache__'} and not (frozen / directory.name).exists():
            (frozen / directory.name).symlink_to(directory, target_is_directory=True)
    (frozen / 'plans').mkdir(exist_ok=True)
    with (frozen / 'restart_tasks.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=state['fields'])
        writer.writeheader()
        for original in state['rows']:
            row = dict(original)
            row['config_path'] = str(frozen / 'configs' / (Path(row['config_path']).stem + '.json'))
            writer.writerow(row)
    launcher = (frozen / 'submit_array.sh').read_text()
    old_plan = "        run([sys.executable, str(root / 'run_experiment.py'), 'plan', '--config', *configs,\n             '--manifest', str(manifest), '--output', str(plan)], env)"
    require(launcher.count(old_plan) == 1, 'Gesicherter Launcher ist nicht die erwartete native Array-Fassung. Keine Jobs beendet oder eingereicht.')
    launcher = launcher.replace(old_plan, "        shutil.copyfile(root / 'restart_tasks.csv', plan)", 1)
    (frozen / 'submit_saved_tasks.sh').write_text(launcher)
    require(code_hash(python_bytes(frozen)) == state['source_hash'], 'Code-Hash hat sich beim Vorbereiten verändert.')
    # At this point all selected jobs are pending/held or already finished.
    # The explicit PENDING filter additionally protects against running jobs.
    remove_pending(set(state['held_jobs']), root)
    require(not any(row['parent'] in state['held_jobs'] for row in queue(root)), 'Alte Jobs noch in der Queue; später erneut aufrufen.')
    paths = [str(external / name) for name in state.get('external_paths', [])]
    if env.get('PYTHONPATH'): paths.append(env['PYTHONPATH'])
    env['PYTHONPATH'] = os.pathsep.join(paths)
    command = ['bash', str(frozen / 'submit_saved_tasks.sh'), '--restart', *state['configs']]
    if args.account:
        require(re.fullmatch(r'[A-Za-z0-9_.-]+', args.account), 'Ungültiger Accountname.')
        command.append('--account=' + args.account)
    print(f'Neustart ausschließlich aus {frozen}; Code-Hash {state["source_hash"]}.', flush=True)
    run(command, frozen, capture=False)
    print('Abgeschlossene Läufe übernommen; fehlende/unvollständige Läufe mit altem Code eingereiht. Maximal 8 gleichzeitig.', flush=True)

try:
    require(not os.environ.get('SLURM_JOB_ID'), 'Auf dem Login-Knoten ausführen.')
    if args.command == 'sichern': save()
    else: restart()
except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
    print('Abgebrochen: ' + str(error), file=sys.stderr)
    raise SystemExit(1)
HUM301_FROZEN_RESTART
