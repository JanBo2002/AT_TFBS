"""Funktionstests der Block-B-Optionen (Decoder aus, GroupNorm, SiLU, Pooling-Varianten, SE, eine Pooling-Stufe, Stochastic Depth)."""
import argparse, importlib.util, sys, math
from pathlib import Path
import torch
import torch.nn.functional as F

_a = argparse.ArgumentParser(); _a.add_argument('--new', required=True, help='Ordner mit den neuen Dateien (model.py, training.py)')
_args = _a.parse_args()
NEW = Path(_args.new).resolve()
sys.path.insert(0, str(NEW))
def load(path, alias):
    spec = importlib.util.spec_from_file_location(alias, path); m = importlib.util.module_from_spec(spec)
    sys.modules[alias] = m; spec.loader.exec_module(m); return m
data = load(NEW / 'data.py', 'data'); model = load(NEW / 'model.py', 'model'); training = load(NEW / 'training.py', 'training')

failures = []
def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (f" — {detail}" if detail else ""))
    if not ok: failures.append(name)

def onehot(batch, length, seed=0):
    g = torch.Generator().manual_seed(seed)
    return F.one_hot(torch.randint(0, 4, (batch, length), generator=g), 4).permute(0, 2, 1).float()
x = onehot(6, 256); centers = torch.full((6,), 128, dtype=torch.long)
def build(**kw):
    torch.manual_seed(1); return model.HumanTFBindingModel(model.ModelConfig(**kw))
def params(m): return sum(p.numel() for p in m.parameters())
def run_both(m):
    m.train(); torch.manual_seed(2); tr = m(x, centers); loss = tr["classification_logit"].sum(); loss.backward()
    ok = all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
    m.eval(); ev = m(x, centers)
    return tr, ev, ok
base = build(); base_n = params(base)

# ------------------------------------------------ B01 Decoder aus
m = build(decoder=False); tr, ev, ok = run_both(m)
check("B01: Modell ohne up1/up2/up3", not any(k.startswith(("up1", "up2", "up3")) for k in m.state_dict()))
check("B01: Parameter deutlich weniger", params(m) < base_n, f"{params(m):,} vs {base_n:,} ({100*(1-params(m)/base_n):.1f} % weniger)")
check("B01: Logit [B], Track 64 Positionen, Regressionsspur 256", tr["classification_logit"].shape == (6,) and tr["classification_track"].shape == (6, 64) and tr["regression_track"].shape == (6, 256))
check("B01: Vorwärts/Rückwärts endlich", ok and torch.isfinite(ev["classification_logit"]).all())
# Center-Readout: Position 128 -> Bottleneck-Index 32; RC-Center 127 -> 31 (gleiche Basen)
m.eval()
with torch.no_grad():
    logit_f = m(x, centers)["classification_logit"]
    track = m(x, centers)["classification_track"]
check("B01: Center-Readout nimmt Bottleneck-Index 32", torch.allclose(logit_f, track[:, 32]))
xr = x[:, [3, 2, 1, 0], :].flip(-1)
with torch.no_grad():
    track_r = m(xr, 255 - centers)["classification_track"]; logit_r = m(xr, 255 - centers)["classification_logit"]
check("B01: RC-Center-Readout nimmt Index 31", torch.allclose(logit_r, track_r[:, 31]))
try:
    model.HumanTFBindingModel(model.ModelConfig(decoder=False), pwm_target=([[ [0.1,0.2,0.3,0.4] ]*8], {"schema_version": "2.0"}, 1.0)); check("B01: PWM-Hilfsziel ohne Decoder abgelehnt", False)
except ValueError: check("B01: PWM-Hilfsziel ohne Decoder abgelehnt", True)

# ------------------------------------------------ B03 GroupNorm
m = build(normalization="group", norm_groups=8); tr, ev, ok = run_both(m)
norms = [mod for mod in m.modules() if isinstance(mod, torch.nn.GroupNorm)]
rms = [mod for mod in m.modules() if isinstance(mod, model.RMSBatchNorm1d)]
check("B03: alle ConvBlock-Normen sind GroupNorm, keine RMSBatchNorm mehr", len(norms) > 0 and len(rms) == 0, f"{len(norms)} GroupNorm")
check("B03: keine running-Statistik im state_dict", not any("running" in k for k in m.state_dict()))
# Per-Sequenz: Ausgabe einer Probe hängt nicht von den anderen Proben im Batch ab (train-Modus)
m.train()
with torch.no_grad():
    torch.manual_seed(3); a = m(x[:2], centers[:2])["classification_logit"]
    torch.manual_seed(3); b = m(x[:1], centers[:1])["classification_logit"]
# Dropout-Masken unterscheiden sich bei anderer Batchgröße -> eval-Modus für den Batch-Unabhängigkeitstest
m.eval()
with torch.no_grad():
    a = m(x[:2], centers[:2])["classification_logit"]; b = m(x[:1], centers[:1])["classification_logit"]
    base.eval(); torch.manual_seed(0)
check("B03: Ausgabe batch-unabhängig (eval)", torch.allclose(a[:1], b, atol=1e-5))
try:
    build(normalization="group", norm_groups=7); check("B03: nicht teilende Gruppenzahl abgelehnt", False)
except ValueError as e: check("B03: nicht teilende Gruppenzahl abgelehnt", True, str(e)[:60])
check("B03: Vorwärts/Rückwärts endlich", ok)

# ------------------------------------------------ B04/B05 Aktivierungen
for name in ("gelu", "silu"):
    m = build(activation=name); tr, ev, ok = run_both(m)
    kinds = {type(mod).__name__ for mod in m.modules() if isinstance(mod, (torch.nn.ReLU, torch.nn.GELU, torch.nn.SiLU))}
    check(f"B04/05: Aktivierung {name} überall, kein ReLU", kinds == {"GELU" if name == "gelu" else "SiLU"}, str(kinds))
    check(f"B04/05: {name} Vorwärts/Rückwärts endlich", ok)

# ------------------------------------------------ B06 AvgPool, B07 Attention-Pooling
m = build(pooling="avg"); tr, ev, ok = run_both(m)
check("B06: AvgPool1d aktiv", isinstance(m.pool, torch.nn.AvgPool1d) and ok)
m = build(pooling="attention"); tr, ev, ok = run_both(m)
check("B07: zwei Attention-Pools (c0, c1)", isinstance(m.pool, torch.nn.ModuleList) and len(m.pool) == 2 and ok)
pool = model.AttentionPool1d(8)
t = torch.randn(2, 8, 10)
out = pool(t)
# Bei Initialisierung (Logits = 2*Identität) ist der Pool ein weiches Maximum: zwischen Mittel und Max
lo = t.reshape(2, 8, 5, 2).mean(-1); hi = t.reshape(2, 8, 5, 2).amax(-1)
check("B07: Attention-Pool initial zwischen Mittel und Maximum", bool(((out >= lo - 1e-6) & (out <= hi + 1e-6)).all()) and out.shape == (2, 8, 5))
check("B07: Attention-Pool-Parameter vorhanden", params(m) > base_n, f"+{params(m)-base_n:,} Parameter")

# ------------------------------------------------ B08 SE-Block
m = build(se_blocks=True, se_reduction=4, se_pool="max"); tr, ev, ok = run_both(m)
ses = [mod for mod in m.modules() if isinstance(mod, model.SqueezeExcite)]
check("B08: 6 SE-Blöcke (3 Encoder, 3 Decoder)", len(ses) == 6 and ok, f"+{params(m)-base_n:,} Parameter")
se = model.SqueezeExcite(16, 4, "max"); t = torch.randn(3, 16, 20); g = se(t) / t
check("B08: Gate je Kanal und Sequenz, in (0,1), positionsunabhängig", bool(((g > 0) & (g < 1)).all()) and torch.allclose(g[:, :, 0], g[:, :, 5]))
m2 = build(se_blocks=True, decoder=False)
check("B08+B01: ohne Decoder nur 3 SE-Blöcke", len([mod for mod in m2.modules() if isinstance(mod, model.SqueezeExcite)]) == 3)

# ------------------------------------------------ B09 eine Pooling-Stufe
m = build(pooling_stages=1, bottleneck_length=128); tr, ev, ok = run_both(m)
check("B09: Positionseinbettung 128 Tokens, up2 ohne Upsampling", m.position_embedding.shape == (1, 128, 128) and m.up2.upsample is False and m.up3.upsample is True)
check("B09: Ausgabespuren 256 lang, Logit endlich", tr["classification_track"].shape == (6, 256) and ok)
try:
    build(pooling_stages=1); check("B09: falsche bottleneck_length abgelehnt", False)
except ValueError: check("B09: falsche bottleneck_length abgelehnt", True)
m = build(pooling_stages=1, bottleneck_length=128, decoder=False); tr, ev, ok = run_both(m)
check("B09+B01: Readout-Stride 2, Track 128", m.readout_stride == 2 and tr["classification_track"].shape == (6, 128) and ok)
m = build(pooling_stages=1, bottleneck_length=128, pooling="attention")
check("B09+B07: nur ein Attention-Pool", len(m.pool) == 1)

# ------------------------------------------------ B10/B11 Encoder-Breiten
for enc in ((64, 64, 64), (96, 128, 192)):
    m = build(encoder_channels=enc); tr, ev, ok = run_both(m)
    check(f"B10/11: Encoder {enc} lauffähig", ok, f"{params(m):,} Parameter")

# ------------------------------------------------ B12 Stochastic Depth
m = build(stochastic_depth=0.1)
drops = [mod for mod in m.modules() if isinstance(mod, model.DropPath) and mod.rate > 0]
check("B12: DropPath in Embedder, 3 Down-, 3 Up-, 5 Bottleneck-Blöcken", len(drops) == 12, f"{len(drops)}")
check("B12: keine zusätzlichen Parameter", params(m) == base_n)
m.train()
with torch.no_grad():
    torch.manual_seed(5); o1 = m(x, centers)["classification_logit"]
    torch.manual_seed(6); o2 = m(x, centers)["classification_logit"]
check("B12: Training stochastisch", not torch.allclose(o1, o2))
m.eval()
with torch.no_grad():
    e1 = m(x, centers)["classification_logit"]; e2 = m(x, centers)["classification_logit"]
check("B12: Evaluation deterministisch", torch.equal(e1, e2))
dp = model.DropPath(0.5); dp.train(); t = torch.ones(1000, 3, 4); torch.manual_seed(0); out = dp(t)
kept = (out[:, 0, 0] > 0).float().mean().item()
check("B12: Erwartungswert erhalten (Skalierung 1/(1-p))", abs(kept - 0.5) < 0.06 and torch.allclose(out[out > 0], torch.tensor(2.0)), f"kept {kept:.2f}")
dp0 = model.DropPath(0.0); dp0.train(); state = torch.get_rng_state(); dp0(t); check("B12: Rate 0 verbraucht keine Zufallszahlen", torch.equal(state, torch.get_rng_state()))
try:
    model.DropPath(1.0); check("B12: Rate 1.0 abgelehnt", False)
except ValueError: check("B12: Rate 1.0 abgelehnt", True)

# Regel: nur gleich breite Residualzweige werden fallen gelassen
m = build(stochastic_depth=0.1)
check("B12: kanalverändernde Zweige nie gedroppt (Basis 64->80->96->128)",
      not m.down1.drop_first and not m.down2.drop_first and not m.down3.drop_first
      and not m.up1.drop_reduce and not m.up2.drop_reduce and not m.up3.drop_reduce)
m10 = build(stochastic_depth=0.1, encoder_channels=(64, 64, 64))
check("B12: bei gleicher Breite (64/64/64) auch erster Zweig droppbar", m10.down1.drop_first and m10.down2.drop_first and m10.up1.drop_reduce)
blk = model.DownresBlock(8, 16, drop_path=0.5); blk.train()
blk.drop_path.forward = lambda t: torch.zeros_like(t)   # erzwingt "immer fallen lassen"
t = torch.randn(3, 8, 20)
with torch.no_grad():
    expected = blk.first(t) + model.pad_or_crop_channels(t, 16)
    got = blk(t)
check("B12: DownresBlock 8->16 behält ersten Zweig, droppt nur den zweiten", torch.allclose(got, expected, atol=1e-6))
blk = model.DownresBlock(8, 8, drop_path=0.5); blk.train(); blk.drop_path.forward = lambda t: torch.zeros_like(t)
with torch.no_grad():
    got = blk(t)
check("B12: DownresBlock 8->8 fällt komplett auf die Identität zurück", torch.allclose(got, t))

# ------------------------------------------------ ModelConfig aus Trainingsargumenten
args = training.training_namespace()
for key, value in dict(decoder=False, normalization="group", pooling="attention", pooling_stages=1, se_blocks=True, stochastic_depth=0.1, activation="silu").items():
    setattr(args, key, value)
cfg = training.model_config_from_args(args, 256)
check("model_config_from_args: Felder übernommen, bottleneck 128 bei einer Stufe",
      cfg.decoder is False and cfg.normalization == "group" and cfg.pooling == "attention" and cfg.pooling_stages == 1 and cfg.bottleneck_length == 128 and cfg.se_blocks and cfg.stochastic_depth == 0.1 and cfg.activation == "silu")
cfg0 = training.model_config_from_args(training.training_namespace(), 256)
check("model_config_from_args: Standard = ModelConfig-Standard", cfg0 == model.ModelConfig(sequence_length=256, bottleneck_length=64, motif_kernels=(9, 12), encoder_channels=(80, 96, 128), channel_dropout=0.0), str(cfg0)[:0])

print("\nFEHLER:", failures if failures else "keine")
sys.exit(1 if failures else 0)
