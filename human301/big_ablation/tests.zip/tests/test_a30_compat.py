"""A30–A35-Optionen: Block-B-Code gegen A30-Code bit-gleich (Parameter, Vorwärts, Gradienten, Hilfsverlust)."""
import argparse, importlib.util, sys, types
from pathlib import Path
import torch
import torch.nn.functional as F

_a = argparse.ArgumentParser()
_a.add_argument('--a30', required=True, help='Ordner mit model.py des A30-Stands')
_a.add_argument('--new', required=True, help='Ordner mit model.py des Block-B-Stands')
_a.add_argument('--pwm-root', required=True, help='synthetische PWM-Wurzel (make_synthetic_project.py)')
_args = _a.parse_args()
sys.path.insert(0, str(Path(_args.new).resolve()))

def load(path, alias):
    spec = importlib.util.spec_from_file_location(alias, path); m = importlib.util.module_from_spec(spec)
    sys.modules[alias] = m; spec.loader.exec_module(m); return m

load(Path(_args.new) / 'data.py', 'data')
old = load(Path(_args.a30) / 'model.py', 'model_a30')
new = load(Path(_args.new) / 'model.py', 'model')
failures = []
def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (f" — {detail}" if detail else ""))
    if not ok: failures.append(name)

x = F.one_hot(torch.randint(0, 4, (4, 256), generator=torch.Generator().manual_seed(0)), 4).permute(0, 2, 1).float()
c = torch.full((4,), 128, dtype=torch.long)

def compare(label, make_old, make_new):
    torch.manual_seed(1); mo = make_old(); torch.manual_seed(1); mn = make_new()
    so, sn = mo.state_dict(), mn.state_dict()
    def same(a, b):
        return torch.equal(a, b) if isinstance(a, torch.Tensor) and isinstance(b, torch.Tensor) else a == b
    check(f"{label}: state_dict identisch", list(so) == list(sn) and all(same(so[k], sn[k]) for k in so), f"{len(so)} Einträge")
    for mode in ("train", "eval"):
        getattr(mo, mode)(); getattr(mn, mode)()
        torch.manual_seed(2); oo = mo(x, c); torch.manual_seed(2); on = mn(x, c)
        check(f"{label}: forward bit-gleich ({mode})", set(oo) == set(on) and all(torch.equal(oo[k], on[k]) for k in oo))
    mo.train(); mn.train()
    torch.manual_seed(3); lo = mo(x, c); torch.manual_seed(3); ln = mn(x, c)
    (lo["classification_logit"].sum() + lo.get("auxiliary_loss", 0)).backward()
    (ln["classification_logit"].sum() + ln.get("auxiliary_loss", 0)).backward()
    same = all((a.grad is None and b.grad is None) or (a.grad is not None and b.grad is not None and torch.equal(a.grad, b.grad))
               for a, b in zip(mo.parameters(), mn.parameters()))
    check(f"{label}: Gradienten bit-gleich", same)

for label, kw in {"A30 exp": dict(motif_activation="exp"), "A31 RC-Sharing": dict(motif_rc_sharing=True),
                  "A05 Kernel 7": dict(motif_kernels=(7,)), "A26 Tiefe 2": dict(embed_channels=32, embedder_residual_blocks=2)}.items():
    compare(label, lambda: old.HumanTFBindingModel(old.ModelConfig(**kw)), lambda: new.HumanTFBindingModel(new.ModelConfig(**kw)))

def ctx():
    return types.SimpleNamespace(tf="FAKE", train_assay="CHIP", config={}, artifacts={}, recorder=None, run_dir=None)
compare("A32 PWM-Hilfsziel",
        lambda: old.maa_pwm_target(ctx(), pwm_root=_args.pwm_root, pwm_count=3, pwm_target_weight=1.0),
        lambda: new.maa_pwm_target(ctx(), pwm_root=_args.pwm_root, pwm_count=3, pwm_target_weight=1.0))
compare("A15 PWM-Kanäle",
        lambda: old.maa_pwm(ctx(), pwm_root=_args.pwm_root, pwm_count=3),
        lambda: new.maa_pwm(ctx(), pwm_root=_args.pwm_root, pwm_count=3))

print("\nFEHLER:", failures if failures else "keine")
sys.exit(1 if failures else 0)
