"""Zertifizierte Gleichwertigkeit von Code-Ständen: Hash-Rekonstruktion, versions.txt und Gegenproben.

    python test_certified_code.py --package /pfad/zu/blockb_update --a30 <Ordner A30> --orig <Ordner Original> --middle <Ordner Middle>

Baut in temporären Ordnern Projektbäume in verschiedenen Ständen (Original/Middle, A30, jede
Zwischenstufe einer laufenden Installation, Block B) und prüft, dass training.py, run_experiment.py
und der Installer dieselben zertifizierten Hashes berechnen.
"""
import argparse, hashlib, importlib.util, itertools, json, os, shutil, sys, tempfile, zipfile
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--package", required=True, type=Path)
parser.add_argument("--a30", required=True, type=Path)
parser.add_argument("--orig", required=True, type=Path)
parser.add_argument("--middle", required=True, type=Path)
args = parser.parse_args()
PKG = args.package.resolve()
PROGRAM = ("run_experiment.py", "model.py", "data.py", "training.py")
NEW = {n: (PKG / "files" / (n + ".blockb")).read_bytes() for n in PROGRAM}
A30 = {"model.py": (args.a30 / "model.py").read_bytes(), "data.py": (args.a30 / "data.py").read_bytes(),
       "training.py": (args.a30 / "training.py").read_bytes(), "run_experiment.py": (args.middle / "run_experiment.py").read_bytes()}
MIDDLE = {"model.py": (args.orig / "model.py").read_bytes(), "data.py": (args.orig / "data.py").read_bytes(),
          "training.py": (args.middle / "training.py").read_bytes(), "run_experiment.py": (args.middle / "run_experiment.py").read_bytes()}
EXTRA = b'"""Stand-in for another project module, e.g. mex_pwm_model.py."""\nfrom model import HumanTFBindingModel\n'

failures = []
def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (f" — {detail}" if detail else ""))
    if not ok: failures.append(name)

def package_hash(root):
    result = hashlib.sha256()
    for path in sorted(root.rglob("*.py")):
        if "results" in path.relative_to(root).parts or "__pycache__" in path.parts:
            continue
        result.update(str(path.relative_to(root)).encode()); result.update(path.read_bytes())
    return result.hexdigest()

def tree(root, files, certified=False):
    root.mkdir(parents=True, exist_ok=True)
    for name, data in files.items():
        (root / name).write_bytes(data)
    (root / "mex_pwm_model.py").write_bytes(EXTRA)
    (root / "results" / "X").mkdir(parents=True, exist_ok=True)
    (root / "results" / "X" / "ignored.py").write_text("# results are not hashed\n")
    if certified:
        shutil.copytree(PKG / "certified_code", root / "certified_code", dirs_exist_ok=True)
    return root

def extract_function(source, name):
    """Load certified_code_hashes() from a program file without importing torch."""
    text = source.decode()
    start = text.index("CERTIFIED_CODE_DIR = ")
    end = text.index("\n\n\ndef ", text.index("def certified_code_hashes"))
    namespace = {"Path": Path, "hashlib": hashlib, "json": json}
    exec(text[start:end], namespace)
    return namespace[name]

train_impl = extract_function(NEW["training.py"], "certified_code_hashes")
runexp_impl = extract_function(NEW["run_experiment.py"], "certified_code_hashes")
with zipfile.ZipFile(PKG / "install_block_b_update.pyz") as archive:
    installer_source = archive.read("__main__.py").decode()
installer = {}
exec(compile(installer_source.replace('if __name__ == "__main__":\n    main()', ""), "installer", "exec"), installer)

with tempfile.TemporaryDirectory() as temporary:
    base = Path(temporary)
    h_a30 = package_hash(tree(base / "a30", A30))
    h_middle = package_hash(tree(base / "middle", MIDDLE))
    final = tree(base / "final", NEW, certified=True)
    h_final = package_hash(final)
    sets = {"training.py": train_impl(final), "run_experiment.py": runexp_impl(final),
            "Installer": installer["certified_hashes"](installer["hashed_files"](final), final / "certified_code")}
    check("drei Implementierungen liefern dieselbe Menge", sets["training.py"] == sets["run_experiment.py"] == sets["Installer"],
          f"{len(sets['training.py'])} Hashes")
    certified = sets["training.py"]
    check("aktueller Code-Hash enthalten", h_final in certified)
    check("A30-Stand zertifiziert (laufendes A30-Array)", h_a30 in certified)
    check("Middle-/Original-Stand zertifiziert", h_middle in certified)
    # Jede Zwischenstufe der Installation (Reihenfolge des Installers und beliebige andere)
    states = 0; missing = []
    for mask in itertools.product((False, True), repeat=len(PROGRAM)):
        files = {n: (NEW[n] if use_new else A30[n]) for n, use_new in zip(PROGRAM, mask)}
        h = package_hash(tree(base / f"mix{states}", files))
        states += 1
        if h not in certified: missing.append(mask)
    check("alle 16 Zwischenstufen A30 → Block B zertifiziert", not missing, f"{states} Stufen")
    # Gegenproben
    other = tree(base / "other", dict(A30)); (other / "mex_pwm_model.py").write_bytes(EXTRA + b"# changed\n")
    check("Änderung an einem anderen Modul wird nicht zertifiziert", package_hash(other) not in certified)
    extra_file = tree(base / "extra", dict(A30)); (extra_file / "helper.py").write_text("x = 1\n")
    check("zusätzliche .py-Datei wird nicht zertifiziert", package_hash(extra_file) not in certified)
    edited = tree(base / "edited", dict(NEW), certified=True)
    (edited / "model.py").write_bytes(NEW["model.py"] + b"\n# local edit\n")
    check("lokal veränderte model.py: Manifest greift nicht mehr für diese Datei", h_a30 not in train_impl(edited))
    check("ohne certified_code/ nur der aktuelle Hash", train_impl(tree(base / "plain", dict(NEW))) == {package_hash(base / "plain")})

    # write_versions aus run_experiment.py (ohne torch: Funktion samt Abhängigkeiten herauslösen)
    text = NEW["run_experiment.py"].decode()
    block = text[text.index("CERTIFIED_CODE_DIR = "):text.index("\n\n\n# Command-line interface")]
    namespace = {"Path": Path, "hashlib": hashlib, "json": json, "re": __import__("re"), "os": os, "sys": sys, "ROOT": final}
    exec(block, namespace)
    write_versions = namespace["write_versions"]
    experiment = final / "results" / "A30_exp"; experiment.mkdir(parents=True)
    a30_versions = (f"code_sha256: {h_a30}\nrun_experiment.py: 5.5.0-middle-task-profile\nmodel.py: 5.6.0\n"
                    "data.py: 5.5.0\ntraining.py: 5.7.0\n")
    (experiment / "versions.txt").write_text(a30_versions)
    os.environ.pop("ABLATION_ALLOW_CODE_VERSION_MISMATCH", None)
    write_versions(experiment, h_final)
    text1 = (experiment / "versions.txt").read_text()
    check("write_versions: A30-Experiment läuft mit Block B weiter, Vermerk in versions.txt",
          text1.startswith(a30_versions) and "Certified equivalent code version" in text1 and text1.count("code_sha256") == 2)
    write_versions(experiment, h_final)
    check("write_versions: zweiter Task ändert nichts", (experiment / "versions.txt").read_text() == text1)
    foreign = final / "results" / "Foreign"; foreign.mkdir()
    (foreign / "versions.txt").write_text(f"code_sha256: {'0' * 64}\nmodel.py: x\n")
    try:
        write_versions(foreign, h_final); check("write_versions: fremder Code-Stand wird abgelehnt", False)
    except ValueError as error:
        check("write_versions: fremder Code-Stand wird abgelehnt", "another code version" in str(error))
    os.environ["ABLATION_ALLOW_CODE_VERSION_MISMATCH"] = "1"
    write_versions(foreign, h_final)
    check("write_versions: Umgebungsvariable wirkt wie bisher", "Certified" not in (foreign / "versions.txt").read_text()
          and (foreign / "versions.txt").read_text().count("code_sha256") == 2)
    os.environ.pop("ABLATION_ALLOW_CODE_VERSION_MISMATCH")
    check("Installer liest den letzten Code-Hash aus versions.txt", installer["recorded_code_hash"](experiment / "versions.txt") == h_final)
    for assay, value in (("CHIP", h_a30), ("GHTS", h_final)):
        run = experiment / "runs" / "FAKE" / f"train_{assay}" / "seed_13"
        run.mkdir(parents=True)
        (run / "run.json").write_text(json.dumps({"code_hash": value, "status": "completed"}))
    last, recorded = installer["experiment_code_hashes"](experiment)
    check("Installer erfasst alle vermerkten Code-Hashes (versions.txt und run.json)",
          last == h_final and recorded == {h_a30, h_final} and recorded <= certified)
    odd = experiment / "runs" / "FAKE" / "train_CHIP" / "seed_14"
    odd.mkdir(parents=True)
    (odd / "run.json").write_text(json.dumps({"code_hash": "1" * 64, "status": "completed"}))
    last, recorded = installer["experiment_code_hashes"](experiment)
    check("Installer erkennt einen nicht zertifizierten Hash in run.json (Sammeln bräche ab)",
          last in certified and not recorded <= certified)

print("\nFEHLER:", failures if failures else "keine")
sys.exit(1 if failures else 0)
