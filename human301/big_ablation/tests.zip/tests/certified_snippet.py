# Certified equivalent code versions
# ----------------------------------
# certified_code/*.json lists program files whose current version may stand in
# for earlier versions (stored in certified_code/ without a .py suffix, so they do
# not enter the code hash). Each manifest is written by an update whose tests
# showed bit-identical computations for every configuration that ran under the
# earlier versions. A run recorded under one of these hashes differs from the
# current code only by such certified file versions; all other files are equal.

CERTIFIED_CODE_DIR = "certified_code"


def certified_code_hashes(root):
    """All code hashes that the manifests certify as equivalent to the current code."""
    import itertools
    root = Path(root)
    files = []
    for path in sorted(root.rglob("*.py")):
        if "results" in path.relative_to(root).parts or "__pycache__" in path.parts:
            continue
        files.append((str(path.relative_to(root)), path.read_bytes()))
    contents = dict(files)

    def digest(replacements):
        # Exactly package_hash(), with selected file contents replaced.
        result = hashlib.sha256()
        for name, data in files:
            result.update(name.encode())
            result.update(replacements.get(name, data))
        return result.hexdigest()

    hashes = {digest({})}
    directory = root / CERTIFIED_CODE_DIR
    for manifest_path in sorted(directory.glob("*.json")) if directory.is_dir() else []:
        try:
            manifest = json.loads(manifest_path.read_text())
            options = []
            for name, spec in sorted(manifest["files"].items()):
                if name not in contents or hashlib.sha256(contents[name]).hexdigest() != spec["sha256"]:
                    continue  # the file is not (or no longer) the certified version
                variants = [contents[name]]
                for earlier in spec.get("equivalent", []):
                    data = (directory / earlier["ref"]).read_bytes()
                    if hashlib.sha256(data).hexdigest() == earlier["sha256"]:
                        variants.append(data)
                options.append((name, variants))
        except (OSError, ValueError, KeyError, TypeError):
            continue
        for combination in itertools.product(*[variants for _, variants in options]):
            hashes.add(digest({name: data for (name, _), data in zip(options, combination)}))
    return hashes
