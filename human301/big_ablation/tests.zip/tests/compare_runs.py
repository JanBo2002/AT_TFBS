"""Vergleicht zwei Läufe bitweise: Checkpoint-Gewichte, Metadaten, Validierungs- und Testvorhersagen, Lernverlauf.

    python compare_runs.py <results/CONFIG/runs/TF des einen Projekts> <dasselbe im anderen Projekt>

Funktioniert für trainierte Läufe und für Läufe, die einen Checkpoint wiederverwenden (reuse_checkpoint, z. B. TTA).
Absolute Projektpfade (etwa pwm_root im PWM-Zusatzzustand) werden vor dem Vergleich angeglichen, weil die beiden
Vergleichsprojekte in verschiedenen Ordnern liegen.
"""
import json, sys
from pathlib import Path
import torch

a, b = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
root_a, root_b = str(a.parents[3]), str(b.parents[3])
TIMING = ("time", "seconds", "_s", "elapsed", "wall", "started", "finished", "duration")


def normalise(value, root):
    if isinstance(value, str):
        return value.replace(root, "<PROJEKT>")
    if isinstance(value, dict):
        return {k: normalise(v, root) for k, v in value.items() if not any(t in k.lower() for t in TIMING)}
    if isinstance(value, (list, tuple)):
        return [normalise(v, root) for v in value]
    return value


def same_file(x, y):
    if x.exists() != y.exists():
        return False
    return not x.exists() or x.read_bytes() == y.read_bytes()


ok = True
for assay in ("CHIP", "GHTS"):
    ra, rb = a / f"train_{assay}" / "seed_13", b / f"train_{assay}" / "seed_13"
    results = {}
    ca = torch.load(ra / "training/model_for_prediction.pt", map_location="cpu", weights_only=True)
    cb = torch.load(rb / "training/model_for_prediction.pt", map_location="cpu", weights_only=True)
    sa, sb = ca["model_state"], cb["model_state"]
    results["Gewichte"] = list(sa) == list(sb) and all(
        torch.equal(sa[k], sb[k]) if isinstance(sa[k], torch.Tensor) else normalise(sa[k], root_a) == normalise(sb[k], root_b)
        for k in sa)
    results["Checkpoint-Metadaten"] = all(ca.get(k) == cb.get(k) for k in ("epoch", "validation_score", "classification_threshold"))
    results["Validierungsvorhersagen"] = same_file(ra / "training/validation_predictions.tsv", rb / "training/validation_predictions.tsv")
    va, vb = ra / "training/validation_metrics.json", rb / "training/validation_metrics.json"
    results["Validierungsmetriken"] = va.exists() == vb.exists() and (not va.exists() or json.loads(va.read_text()) == json.loads(vb.read_text()))
    results["Testvorhersagen"] = all(
        (ra / f"evaluations/standard/{t}/predictions.tsv").read_bytes() == (rb / f"evaluations/standard/{t}/predictions.tsv").read_bytes()
        for t in ("CHIP", "GHTS"))
    ha, hb = ra / "training/history.json", rb / "training/history.json"
    if ha.exists() or hb.exists():
        def history(path):
            return [{k: r[k] for k in ("train", "val", "learning_rate_used")} for r in json.loads(path.read_text())]
        results["Lernverlauf"] = ha.exists() and hb.exists() and history(ha) == history(hb)
    print(f"  train_{assay}: " + ", ".join(f"{k} {v}" for k, v in results.items()))
    ok &= all(results.values())
print("BIT-GLEICH" if ok else "ABWEICHUNG")
sys.exit(0 if ok else 1)
