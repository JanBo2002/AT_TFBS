"""Baut für jede angegebene Config das Modell (Predictor) und hält Gewichte und Ausgaben als Prüfsummen fest.

Wird vom Installer zweimal aufgerufen – einmal mit den bisherigen, einmal mit den neuen
Programmdateien (jeweils als Kopie in einem eigenen Ordner, der auch alle übrigen
Projektmodule wie mex_pwm_model.py enthält). Arbeitsverzeichnis ist der Projektordner,
damit relative PWM-Pfade wie bei den Jobs aufgelöst werden. Schreibt nichts außer --out.

    python compare_predictors.py --root /pfad/zu/big_ablation --out ergebnis.json configs/*.json
"""
import argparse
import csv
import hashlib
import json
import sys
import types
from pathlib import Path

PRIORITY = {"long": "training_priority.csv", "middle": "training_priority_middle.csv", "short": "training_priority_short.csv"}


def pick_tf(config, root):
    if config.get("tfs"):
        return config["tfs"][0]
    path = root / "configs" / PRIORITY.get(config.get("task_profile", "long"), "training_priority.csv")
    with path.open(newline="") as handle:
        return next(csv.DictReader(handle))["tf"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("configs", nargs="+", type=Path)
    args = parser.parse_args()
    import numpy as np
    import torch
    torch.set_num_threads(1)
    import training

    def digest_tensors(items):
        digest = hashlib.sha256()
        for key, value in items:
            digest.update(str(key).encode())
            if isinstance(value, torch.Tensor):
                digest.update(np.ascontiguousarray(value.detach().to(torch.float32).cpu().numpy()).tobytes())
            else:
                digest.update(json.dumps(value, sort_keys=True, default=str).encode())
        return digest.hexdigest()

    results = {}
    for path in args.configs:
        try:
            config = json.loads(path.read_text())
            name = config["name"]
        except Exception as error:  # noqa: BLE001 - report, do not stop
            results[str(path)] = {"status": "error", "error": f"Config unlesbar: {error}"}
            continue
        try:
            tf = pick_tf(config, args.root)
            context = types.SimpleNamespace(
                config=config, config_path=path, root=args.root, run_dir=None, tf=tf,
                train_assay=config["train_assays"][0], seed=13, cache_paths={}, paths={}, recorder=None,
                device="cpu", workers=0, tf_ids=(tf,), artifacts={})
            torch.manual_seed(1234)
            model = training.invoke(config["predictor"], context)
            length = model.config.sequence_length
            generator = torch.Generator().manual_seed(7)
            x = torch.nn.functional.one_hot(torch.randint(0, 4, (2, length), generator=generator), 4).permute(0, 2, 1).float()
            centers = torch.full((2,), length // 2, dtype=torch.long)
            state = digest_tensors(model.state_dict().items())
            outputs = {}
            model.eval()
            with torch.no_grad():
                result = model(x, centers)
            outputs["eval"] = digest_tensors(sorted(result.items()))
            model.train()
            torch.manual_seed(99)
            with torch.no_grad():
                result = model(x, centers)
            outputs["train"] = digest_tensors(sorted(result.items()))
            results[name] = {"status": "ok", "tf": tf, "factory": config["predictor"]["factory"],
                             "parameters": int(sum(p.numel() for p in model.parameters())),
                             "state": state, "outputs": outputs}
        except Exception as error:  # noqa: BLE001
            results[name] = {"status": "error", "factory": config.get("predictor", {}).get("factory"),
                             "error": f"{type(error).__name__}: {error}"[:600]}
    args.out.write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    sys.exit(main())
