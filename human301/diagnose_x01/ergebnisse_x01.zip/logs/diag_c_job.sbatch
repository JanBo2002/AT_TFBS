#!/usr/bin/env bash
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=24:00:00
#SBATCH --gres=gpu:1
#SBATCH --no-requeue
# Rumpf des GPU-Jobs für Diagnose C. vorziehen.sh setzt die #SBATCH-Zeilen von big_ablation/train_array.sbatch
# davor (gleiche Ressourcen wie die Trainingsaufgaben) und reicht ihn ein.
set -euo pipefail
cd "$DIAG_ORDNER"
PY="${CONDA_PREFIX:+$CONDA_PREFIX/bin/python}"
PY="${PY:-$(command -v python3)}"
echo "Diagnose C als $(id -un) auf $(hostname) mit $PY, Job $SLURM_JOB_ID"
"$PY" -c "import torch; print('torch', torch.__version__, '- GPU verfügbar:', torch.cuda.is_available())"
"$PY" diag_c_trainingsfit.py inferenz
"$PY" diag_c_trainingsfit.py auswertung
