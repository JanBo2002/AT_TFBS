#!/usr/bin/env python3
"""Probelauf für N2/N3 auf einer GPU (über n2_einreichen.sh --probelauf als Slurm-Job; schreibt nichts in results/).

Rechnet mit dem installierten Code je eine Trainingsepoche:
  N2 und N3 auf dem größten Middle-Paar (erstes der Prioritätsliste): Zeit je Epoche (Training, Validierung),
  N3 auf dem Paar mit der größten Batch (bis ~1.620): Spitzenwert des GPU-Speichers.
Daraus die Hochrechnung je Config über alle 42 Paare (Epochenzahl wie 01, Obergrenze 100) in Platz-Stunden
und Wandzeit bei 8 Plätzen. Ergebnis: Log des Jobs und n1_auswertung/logs/n2_probe.json.
"""
import argparse
import copy
import gc
import heapq
import json
import sys
import tempfile
import time
from pathlib import Path

H301 = Path(__file__).resolve().parent.parent
BA = H301 / "big_ablation"
sys.path.insert(0, str(BA))
import numpy as np  # noqa: E402
import torch  # noqa: E402

import data as D  # noqa: E402
import training as T  # noqa: E402

CONFIGS = {"N2": "N2_01_all_random_middle", "N3": "N3_01_all_negatives_middle"}
SLOTS = 8


def namespace(config, cache_path, output_dir, workers, device):
    """Trainingsargumente wie baseline() sie für einen Lauf bildet, aber mit genau einer Epoche."""
    args = T.training_namespace()
    params = copy.deepcopy(config["fitting"]["params"])
    negatives_per_epoch = params.pop("negatives_per_epoch")
    positives_per_batch = params.pop("positives_per_batch")
    for key, value in params.items():
        setattr(args, key, value)
    args.negatives_per_epoch, args.positives_per_batch = negatives_per_epoch, positives_per_batch
    model_params = config["predictor"]["params"]
    known = {f.name for f in T.fields(T.ModelConfig)}
    translations = {"transformer_heads": "heads", "transformer_ffn": "ffn_channels", "sequence_length": "input_length"}
    for key, value in model_params.items():
        if key in known:
            setattr(args, translations.get(key, key), value)
    args.motif_kernels = tuple(model_params.get("motif_kernels", (9, 12)))
    args.allow_negative_regression_output = not model_params.get("regression_nonnegative", True)
    args.cache_path, args.output_dir = Path(cache_path), Path(output_dir)
    args.seed, args.device, args.skip_test = 13, device, True
    args.epochs, args.min_checkpoint_epoch = 1, 1
    if workers is not None:
        args.num_workers = workers
    return args


def run_row(path):
    try:
        for line in Path(path).read_text().splitlines():
            row = json.loads(line)
            if row.get("row_type") == "run":
                return row
    except (OSError, ValueError):
        pass
    return {}


def probe(label, config, cache_path, workers, device):
    gc.collect()
    if device == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
    with tempfile.TemporaryDirectory(prefix="n2_probe_") as folder:
        args = namespace(config, cache_path, Path(folder) / "training", workers, device)
        started = time.perf_counter()
        T.train_command(args)
        wall = time.perf_counter() - started
        history = json.loads((Path(folder) / "training" / "history.json").read_text())
        sampling = json.loads((Path(folder) / "training" / "sampling.json").read_text())
    epoch = history[-1]
    cuda = device == "cuda"
    result = {"label": label, "cache": str(cache_path), "wall_s": wall, "epoch_s": epoch["elapsed_seconds"],
              "train_s": epoch["train_seconds"], "validation_s": epoch["validation_seconds"],
              "peak_allocated_gb": torch.cuda.max_memory_allocated() / 1e9 if cuda else 0.0,
              "peak_reserved_gb": torch.cuda.max_memory_reserved() / 1e9 if cuda else 0.0,
              "batch_size_max": sampling["batch_size_max"], "batch_size_mean": sampling["batch_size_mean"],
              "steps_per_epoch": sampling["steps_per_epoch"], "samples_per_epoch": sampling["samples_per_training_epoch"]}
    print(f"  {label}: Epoche {result['epoch_s'] / 60:.1f} min (Training {result['train_s'] / 60:.1f} min, Validierung "
          f"{result['validation_s'] / 60:.1f} min), Batch bis {result['batch_size_max']:,}, "
          f"GPU-Speicher {result['peak_allocated_gb']:.1f} GB (reserviert {result['peak_reserved_gb']:.1f} GB)",
          flush=True)
    return result


def counts(path, typed):
    arrays = D._cache_arrays(Path(path), ("labels", "split") + (("neg_type",) if typed else ()))
    labels, split = arrays["labels"], arrays["split"]
    train = split == 0
    return {"train_positive": int(np.sum(train & (labels == 1))), "train_negative": int(np.sum(train & (labels == 0))),
            "validation": int(np.sum(split == 1))}


def wall_hours(durations):
    free = [0.0] * SLOTS
    end = 0.0
    for duration in durations:                      # Planreihenfolge = Prioritätsliste (lange Läufe zuerst)
        start = heapq.heappop(free)
        heapq.heappush(free, start + duration)
        end = max(end, start + duration)
    return end / 3600


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", default=str(H301 / "n1_auswertung" / "logs" / "n2_probe.json"))
    parser.add_argument("--device", default="cuda", help=argparse.SUPPRESS)      # cpu nur für Tests
    args = parser.parse_args()
    device = args.device
    if device == "cuda" and not torch.cuda.is_available():
        raise SystemExit("Keine GPU sichtbar: der Probelauf muss auf einem GPU-Knoten laufen (n2_einreichen.sh --probelauf).")
    if device == "cuda":
        gpu = torch.cuda.get_device_properties(0)
        gpu_name, gpu_gb = gpu.name, gpu.total_memory / 1e9
    else:
        gpu_name, gpu_gb = "keine (CPU-Test)", 0.0
    print(f"GPU: {gpu_name}, {gpu_gb:.1f} GB", flush=True)
    configs = {key: json.loads((BA / "configs" / f"{name}.json").read_text()) for key, name in CONFIGS.items()}
    rows = D._negative_rows(BA / "configs" / "caches.csv", None, BA / "configs" / "training_priority_middle.csv")
    pairs = []
    for row in rows:
        typed = D.negative_cache_path(row["cache"], "ras")
        pairs.append({"tf": row["tf"], "assay": row["assay"], "cache": str(row["cache"]), "typed": str(typed),
                      "N2": counts(row["cache"], False), "N3": counts(typed, True),
                      "01": run_row(BA / "results/01_basic_0p1cdo/runs" / row["tf"] / f"train_{row['assay']}"
                                    / "seed_13" / "records.jsonl"),
                      "N1E": run_row(BA / "results/N1E_01_eval_aliens_shades_middle/runs" / row["tf"]
                                     / f"train_{row['assay']}" / "seed_13" / "records.jsonl")})
    big = pairs[0]
    widest = max(pairs, key=lambda p: p["N3"]["train_negative"] / p["N3"]["train_positive"])
    workers = big["01"].get("num_workers")
    print(f"Probe auf {big['tf']}/{big['assay']} (größtes Paar), Speicher zusätzlich auf {widest['tf']}/"
          f"{widest['assay']} (größte Batch); Datenlader-Prozesse wie 01: {workers}", flush=True)
    measured = {"N2": probe("N2", configs["N2"], big["cache"], workers, device),
                "N3": probe("N3", configs["N3"], big["typed"], workers, device)}
    memory = probe("N3 größte Batch", configs["N3"], widest["typed"], workers, device)
    report = {"gpu": gpu_name, "gpu_memory_gb": gpu_gb, "probe_pair": f"{big['tf']}/{big['assay']}",
              "memory_pair": f"{widest['tf']}/{widest['assay']}", "measured": measured, "memory": memory, "configs": {}}
    reference = big["01"]
    if reference.get("epoch_mean_s"):
        print(f"  01 (aus dem Lauf): Epoche {reference['epoch_mean_s'] / 60:.1f} min, {reference.get('epochs_run')} "
              f"Epochen, Lauf {reference.get('total_wall_s', 0) / 3600:.1f} h", flush=True)
    print(f"Hochrechnung über alle {len(pairs)} Paare (Epochen wie bei 01 / höchstens 100):", flush=True)
    for key in ("N2", "N3"):
        m, base = measured[key], big[key]
        per_train = m["train_s"] / (base["train_positive"] + base["train_negative"])
        per_val = m["validation_s"] / max(base["validation"], 1)
        setup = max(0.0, m["wall_s"] - m["epoch_s"])
        likely, upper = [], []
        for pair in pairs:
            c = pair[key]
            epoch = per_train * (c["train_positive"] + c["train_negative"]) + per_val * c["validation"]
            epochs = pair["01"].get("epochs_run") or 50
            test = pair["N1E"].get("total_wall_s") or 600.0
            likely.append(setup + epochs * epoch + test)
            upper.append(setup + 100 * epoch + test)
        report["configs"][key] = {"slot_hours": sum(likely) / 3600, "slot_hours_upper": sum(upper) / 3600,
                                  "wall_hours": wall_hours(likely), "wall_hours_upper": wall_hours(upper),
                                  "longest_hours": max(likely) / 3600, "longest_hours_upper": max(upper) / 3600}
        r = report["configs"][key]
        print(f"  {key}: {r['slot_hours']:.1f} / {r['slot_hours_upper']:.1f} Platz-Stunden; bei {SLOTS} Plätzen etwa "
              f"{r['wall_hours']:.1f} / {r['wall_hours_upper']:.1f} Stunden (längster Lauf {r['longest_hours']:.1f} / "
              f"{r['longest_hours_upper']:.1f} h)", flush=True)
    free = gpu_gb - memory["peak_reserved_gb"]
    print(f"Speicher: größte Batch {memory['batch_size_max']:,} braucht {memory['peak_reserved_gb']:.1f} GB von "
          f"{gpu_gb:.1f} GB -> {'passt' if free > 2 else 'KNAPP / ZU WENIG'}", flush=True)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(report, indent=1, default=str) + "\n")
    print(f"Details: {args.out}", flush=True)


if __name__ == "__main__":
    main()
