#!/usr/bin/env bash
# N2 und N3 (alle Negativen je Epoche) einreichen, in der Reihenfolge: R und K4/K5 -> N2 -> N3 -> Rest von A36.
#
#   bash n2_update/n2_einreichen.sh --probelauf      zuerst: GPU-Probelauf (Zeit je Epoche, Speicher, Hochrechnung)
#   bash n2_update/n2_einreichen.sh [--account=NAME] danach: N2 und N3 einreichen
#
# Auf dem Login-Knoten, in at_env, nach dem Installer. Auf dem Login-Knoten läuft nichts Schweres.
#   --probelauf  Ein GPU-Job (Ressourcen wie train_array.sbatch) rechnet je eine Epoche N2 und N3 auf dem größten
#                Middle-Paar und eine Epoche N3 mit der größten Batch; Ergebnis im Log und in
#                n2_auswertung/logs/n2_probe.json. Sonst wird nichts eingereicht.
#   Einreichen   1. Wartende Arrays dieses Projekts (R, K4/K5) warten nicht mehr auf A36, nur noch auf ihre
#                   bisherigen übrigen Vorgänger.
#                2. submit_array.sh reicht N2 ein, danach N3; beide warten auf alle übrigen Arrays dieses Projekts
#                   (außer A36), N3 also auch auf N2.
#                3. Die noch wartenden A36-Tasks warten auf das Ende von N3. Lässt Slurm das nicht zu, werden sie
#                   angehalten (scontrol hold) und das Script sagt, wann sie freizugeben sind.
#                4. Das Aufräumen wird neu eingeplant. Laufende Tasks laufen normal zu Ende.
set -euo pipefail
HIER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
H301="$(cd "$HIER/.." && pwd)"
BA="$H301/big_ablation"
LOGS="$H301/n2_auswertung/logs"
N2=N2_01_all_random_middle
N3=N3_01_all_negatives_middle
PROBELAUF=0
ACCOUNT=()
for arg in "$@"; do
    case "$arg" in
        --probelauf) PROBELAUF=1 ;;
        --account=?*) ACCOUNT=("$arg") ;;
        *) echo "Unbekannte Option: $arg (Aufruf: bash n2_einreichen.sh [--probelauf] [--account=NAME])" >&2; exit 2 ;;
    esac
done
PY="${CONDA_PREFIX:+$CONDA_PREFIX/bin/python}"
PY="${PY:-$(command -v python3)}"

echo "== Prüfen"
for exe in sbatch squeue scontrol scancel; do
    command -v "$exe" >/dev/null || { echo "Abgebrochen: $exe fehlt (Login-Knoten?)" >&2; exit 1; }
done
"$PY" -c "import torch, scipy, sklearn" 2>/dev/null \
    || { echo "Abgebrochen: $PY ohne torch/scipy/sklearn – zuerst at_env aktivieren." >&2; exit 1; }
for name in "$N2" "$N3"; do
    [ -f "$BA/configs/$name.json" ] || { echo "Abgebrochen: configs/$name.json fehlt – zuerst den Installer ausführen." >&2; exit 1; }
    if [ "$PROBELAUF" = 0 ] && [ -e "$BA/results/$name" ]; then
        echo "Abgebrochen: results/$name existiert schon (schon eingereicht?)." >&2; exit 1
    fi
done
grep -q "class AllNegativesEpochSampler" "$BA/data.py" \
    || { echo "Abgebrochen: data.py ohne AllNegativesEpochSampler – zuerst den Installer ausführen." >&2; exit 1; }
# die Caches mit Negativtypen (aus N1) müssen für alle Middle-Paare da sein: N3 trainiert darauf, N2 testet darauf
"$PY" - "$BA" <<'PYTHON' || { echo "Abgebrochen: Caches mit Negativtypen fehlen (siehe oben)." >&2; exit 1; }
import sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
sys.dont_write_bytecode = True
import data
ba = Path(sys.argv[1])
rows = data._negative_rows(ba / "configs/caches.csv", None, ba / "configs/training_priority_middle.csv")
missing = [f"{r['tf']}/{r['assay']}" for r in rows if not data.negative_cache_path(r["cache"], "ras").is_file()]
if missing:
    print("Ohne Cache mit Negativtypen: " + ", ".join(missing))
    sys.exit(1)
print(f"Caches mit Negativtypen: alle {len(rows)} Paare vorhanden")
PYTHON
NAMEN="$(squeue --me -h -o "%j")" || { echo "Abgebrochen: squeue nicht abfragbar." >&2; exit 1; }
mkdir -p "$LOGS"
BA_ECHT="$(cd "$BA" && pwd -P)"

if [ "$PROBELAUF" = 1 ]; then
    if grep -qx "h301_n2_probelauf" <<< "$NAMEN"; then
        echo "Abgebrochen: Der Probelauf steht schon in der Queue (squeue --me)." >&2; exit 1
    fi
    echo "== Probelauf einreichen (GPU wie train_array.sbatch)"
    DATEI="$LOGS/n2_probelauf.sbatch"
    {
        echo "#!/usr/bin/env bash"
        grep -E '^#SBATCH' "$BA/train_array.sbatch" | grep -v -E -- '--(job-name|output|error|array|open-mode)' || true
        echo "set -euo pipefail"
        echo "echo \"Probelauf N2/N3 als \$(id -un) auf \$(hostname), Job \$SLURM_JOB_ID, \$(date)\""
        printf '%q ' "$PY" "$HIER/n2_probe.py" --out "$LOGS/n2_probe.json"
        echo
        echo "echo \"Ende \$(date)\""
    } > "$DATEI"
    JOB="$(sbatch --parsable --no-requeue --job-name=h301_n2_probelauf --chdir="$BA" \
           --output="$LOGS/n2_probelauf_%j.out" --time=04:00:00 --export=ALL ${ACCOUNT[@]+"${ACCOUNT[@]}"} "$DATEI")" \
        || { echo "Abgebrochen: sbatch für den Probelauf gescheitert." >&2; exit 1; }
    JOB="${JOB%%;*}"
    echo "Probelauf $JOB eingereicht; er startet, sobald ein Platz frei ist (etwa 30–60 Minuten Laufzeit)."
    echo "Ansehen:  tail -f $LOGS/n2_probelauf_$JOB.out"
    exit 0
fi

# Jobs dieses Projekts: Arraynummer (%F) | Name | Zustand
projekt() {
    squeue --me -h -o "%F|%j|%T|%Z" | awk -F'|' -v ba="$BA_ECHT" \
        '$4 == ba && $2 ~ /^h301_(array|collect)_/ {print $1 "|" $2 "|" $3}' | sort -u
}
STAND="$(projekt)" || { echo "Abgebrochen: squeue nicht abfragbar." >&2; exit 1; }
A36="$(awk -F'|' '$2 ~ /^h301_(array|collect)_A36/ {print $1}' <<< "$STAND" | sort -un | tr '\n' ' ')"
A36_ARRAY="$(awk -F'|' '$2 ~ /^h301_array_A36/ {print $1}' <<< "$STAND" | sort -un | sed -n 1p)"
vorgaenger() {   # Arraynummer -> frühere Arrays/Sammeljobs dieses Projekts außer A36, als afterany-Liste
    local ziel="$1" liste
    liste="$(projekt | awk -F'|' -v z="$ziel" -v ohne=" $A36 " '$1 < z && index(ohne, " " $1 " ") == 0 {print $1}' \
             | sort -un | paste -sd: -)"
    [ -n "$liste" ] && echo "afterany:$liste" || echo ""
}
abhaengigkeit() {   # Job, neue Bedingung (leer = keine)
    if scontrol update JobId="$1" Dependency="$2"; then
        if [ -n "$2" ]; then echo "  $1: wartet auf ${2#afterany:}"; else echo "  $1: wartet auf nichts mehr"; fi
    else
        echo "WARNUNG: Wartebedingung von $1 nicht geändert – Ausgabe oben prüfen." >&2
        return 1
    fi
}

einreichen() {   # Config -> Arraynummer
    local ausgabe nummer
    ausgabe="$(cd "$BA" && bash submit_array.sh "$1" ${ACCOUNT[@]+"${ACCOUNT[@]}"} 2>&1)" || {
        echo "$ausgabe" >&2; echo "Abgebrochen: submit_array.sh $1 ist gescheitert." >&2; return 1; }
    echo "$ausgabe" >&2
    nummer="$(sed -n 's/^Jobarray \([0-9][0-9]*\):.*/\1/p' <<< "$ausgabe" | sed -n 1p)"
    [ -n "$nummer" ] || { echo "Abgebrochen: Nummer des Arrays von $1 nicht gefunden." >&2; return 1; }
    echo "$nummer"
}
echo "== N2 einreichen"
ARRAY_N2="$(einreichen "$N2")" || { echo "Nichts verändert." >&2; exit 1; }
echo "== N3 einreichen (nach N2)"
ARRAY_N3="$(einreichen "$N3")" || { echo "N2 ($ARRAY_N2) ist eingereicht, N3 nicht; die Queue ist sonst unverändert." \
                                     "Bitte melden." >&2; exit 1; }
SAMMLER_N3="$(projekt | awk -F'|' -v n="h301_collect_$N3" '$2 == n {print $1}' | sed -n 1p)"

echo "== N2 und N3 nicht hinter A36 (N3 wartet auch auf N2)"
abhaengigkeit "$ARRAY_N2" "$(vorgaenger "$ARRAY_N2")" || true
abhaengigkeit "$ARRAY_N3" "$(vorgaenger "$ARRAY_N3")" || true
echo "== R und K4/K5 nicht mehr hinter A36"
if [ -n "$A36" ]; then
    for job in $(awk -F'|' '$2 ~ /^h301_array_/ && $2 !~ /^h301_array_A36/ && $3 == "PENDING" {print $1}' <<< "$STAND" | sort -un); do
        wartend="$(squeue --me -h -t PENDING -o "%F|%E")" || wartend=""
        bisher="$(awk -F'|' -v j="$job" '$1 == j && !n {print $2; n = 1}' <<< "$wartend")"
        betrifft=0
        for a in $A36; do grep -q "$a" <<< "$bisher" && betrifft=1; done
        if [ "$betrifft" = 1 ]; then abhaengigkeit "$job" "$(vorgaenger "$job")" || true; fi
    done
else
    echo "  Kein A36 in der Queue."
fi


echo "== Rest von A36 hinter N3"
A36_WARTET=""
[ -n "$A36_ARRAY" ] && A36_WARTET="$(awk -F'|' -v a="$A36_ARRAY" '$1 == a && $3 == "PENDING"' <<< "$(projekt)")"
if [ -n "$A36_WARTET" ]; then
    NACH="afterany:$ARRAY_N3${SAMMLER_N3:+:$SAMMLER_N3}"
    scontrol update JobId="$A36_ARRAY" Dependency="$NACH" || true
    wartend="$(squeue --me -h -t PENDING -o "%F|%E")" || wartend=""
    jetzt="$(awk -F'|' -v j="$A36_ARRAY" '$1 == j {print $2}' <<< "$wartend")"
    if grep -q "$ARRAY_N3" <<< "$jetzt"; then
        echo "  $A36_ARRAY: die wartenden A36-Tasks starten nach N3 ($ARRAY_N3); laufende laufen zu Ende."
    else
        scontrol hold "$A36_ARRAY" && echo "  $A36_ARRAY: Slurm nimmt die Wartebedingung nicht an; die wartenden A36-Tasks" \
            "sind angehalten. Freigeben, sobald N3 läuft oder fertig ist:  scontrol release $A36_ARRAY" \
            || echo "WARNUNG: A36 ($A36_ARRAY) weder umgestellt noch angehalten – bitte melden." >&2
    fi
else
    echo "  Keine wartenden A36-Tasks."
fi

echo "== Aufräumen neu einplanen"
AUFRAEUMEN="$(squeue --me -h -o "%i|%j|%Z" | awk -F'|' -v ba="$BA_ECHT" '$2 == "h301_aufraeumen" && $3 == ba {print $1}')" \
    || AUFRAEUMEN=""
if [ -n "$AUFRAEUMEN" ]; then
    scancel $AUFRAEUMEN || true
    sleep 2
    (cd "$BA" && bash aufraeumen.sh --nach-jobs) || echo "WARNUNG: Aufräumen nicht neu eingeplant – später: bash aufraeumen.sh --nach-jobs" >&2
else
    echo "Kein Aufräumen eingeplant."
fi

echo "== Wartende Jobs (Reihenfolge über die Wartebedingungen)"
squeue --me -t PENDING -o "%.18i %.10Q %.20r %.45E %.55j"
echo "Auswertung, sobald Läufe fertig sind: python $HIER/n2_auswerten.py"
