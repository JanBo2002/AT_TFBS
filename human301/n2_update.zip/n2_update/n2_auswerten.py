"""Vergleich 01 (über N1E), N1, N2 und N3 auf demselben Testsatz, dazu die Sampling-Werte je Lauf.

    python n2_update/n2_auswerten.py [--big-ablation PFAD]

Liest die abgeschlossenen Läufe (auch während Arrays noch laufen) und schreibt nach n2_auswertung/ergebnisse/:
  n2_pro_lauf.csv   je Config, TF, Richtung, Seed und Auswertung: AUROC, AUPRC, n_pos, n_neg, Zufallsniveau
  n2_vergleich.csv  je TF, Richtung, Auswertung: AUPRC und AUROC von 01 (Seed 13 und Mittel der Seeds), N1, N2, N3
  n2_median.csv     Mediane je Richtung und Auswertung, Differenz zu 01 und Zahl der TFs, bei denen es besser ist
  n2_sampling.csv   je Lauf (01, N1, N2, N3): Positive, Negative je Typ, Verhältnis je Typ und gesamt, Batchgröße,
                    pos_weight, Schritte und Sequenzen je Epoche, Epochen, beste Epoche, Laufzeit
Auswertungen: gesamt (alle Negativen), nur_random (= bisheriger Testsatz), nur_aliens, nur_shades.
"""
import argparse
import csv
import json
import statistics
from pathlib import Path

CONFIGS = {"01": "N1E_01_eval_aliens_shades_middle", "N1": "N1_01_aliens_shades_middle",
           "N2": "N2_01_all_random_middle", "N3": "N3_01_all_negatives_middle"}
TRAINING = {"01": "01_basic_0p1cdo", "N1": CONFIGS["N1"], "N2": CONFIGS["N2"], "N3": CONFIGS["N3"]}
NEU = ("N1", "N2", "N3")
AUSWERTUNGEN = {"standard": "gesamt", "nur_random": "nur_random", "nur_aliens": "nur_aliens", "nur_shades": "nur_shades"}
KURZ = {"CHIP": "CHS", "GHTS": "GHTS"}
RICHTUNGEN = ["CHS→CHS", "GHTS→GHTS", "CHS→GHTS", "GHTS→CHS"]


def laeufe(ordner):
    """[(tf, train, seed, run_dir)] der abgeschlossenen Läufe einer Config."""
    result = []
    for run in sorted((ordner / "runs").glob("*/train_*/seed_*/run.json")) if (ordner / "runs").is_dir() else []:
        try:
            meta = json.loads(run.read_text())
        except (OSError, ValueError):
            continue
        if meta.get("status") == "completed":
            result.append((meta["tf"], meta["train_assay"], int(meta["seed"]), run.parent))
    return result


def lesen(ordner, config):
    zeilen = []
    for tf, train, seed, run in laeufe(ordner):
        for test in ("CHIP", "GHTS"):
            for kennung, name in AUSWERTUNGEN.items():
                try:
                    m = json.loads((run / "evaluations" / kennung / test / "metrics.json").read_text())["test_metrics"]
                except (OSError, ValueError, KeyError):
                    continue
                zeilen.append({"config": config, "tf": tf, "richtung": f"{KURZ[train]}→{KURZ[test]}", "seed": seed,
                               "auswertung": name, "auroc": m["auroc"], "auprc": m["auprc"],
                               "n_pos": m["positive_count"], "n_neg": m["negative_count"],
                               "zufallsniveau": m["pr_baseline"]})
    return zeilen


def run_zeile(run):
    try:
        for line in (run / "records.jsonl").read_text().splitlines():
            row = json.loads(line)
            if row.get("row_type") == "run":
                return row
    except (OSError, ValueError):
        pass
    return {}


def sampling(ordner, config):
    zeilen = []
    for tf, train, seed, run in laeufe(ordner):
        if seed != 13:
            continue
        try:
            counts = json.loads((run / "training" / "configuration.json").read_text())["class_counts"]
        except (OSError, ValueError, KeyError):
            counts = {}
        row = run_zeile(run)
        positive = counts.get("train_positive")
        by_type = counts.get("train_negative_by_type") or {"random": counts.get("train_negative")}
        mix = counts.get("negative_mix")
        if config == "01":                     # 10 random je Positivem und Epoche
            per_epoch = {"random": 10}
        elif mix:
            per_epoch = dict(mix)
        else:                                  # alle Negativen je Epoche
            per_epoch = {k: (v / positive if positive else None) for k, v in by_type.items()}
        zeile = {"config": config, "tf": tf, "train": KURZ[train], "train_positive": positive}
        for typ in ("random", "aliens", "shades"):
            zeile[f"train_{typ}"] = by_type.get(typ)
            zeile[f"je_positivem_{typ}"] = per_epoch.get(typ)
        zeile.update(je_positivem_gesamt=sum(v for v in per_epoch.values() if v is not None),
                     pos_weight=counts.get("pos_weight"),
                     batch_mittel=counts.get("batch_size_mean") or row.get("batch_size"),
                     batch_min=counts.get("batch_size_min") or row.get("batch_size"),
                     batch_max=counts.get("batch_size_max") or row.get("batch_size"),
                     schritte_je_epoche=counts.get("steps_per_epoch") or (-(-positive // 8) if positive else None),
                     sequenzen_je_epoche=counts.get("samples_per_training_epoch"),
                     epochen=row.get("epochs_run"), beste_epoche=row.get("best_epoch"),
                     epoche_s=row.get("epoch_mean_s"),
                     laufzeit_h=(row.get("total_wall_s") or 0) / 3600 or None)
        zeilen.append(zeile)
    return zeilen


def schreiben(pfad, zeilen, felder):
    with pfad.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=felder)
        writer.writeheader()
        for zeile in zeilen:
            writer.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v) for k, v in zeile.items()})


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    h301 = Path(__file__).resolve().parent.parent
    parser.add_argument("--big-ablation", type=Path, default=h301 / "big_ablation")
    args = parser.parse_args()
    results = args.big_ablation / "results"
    alle = {key: lesen(results / name, key) for key, name in CONFIGS.items()}
    ziel = h301 / "n2_auswertung" / "ergebnisse"
    ziel.mkdir(parents=True, exist_ok=True)
    felder = ["config", "tf", "richtung", "seed", "auswertung", "auroc", "auprc", "n_pos", "n_neg", "zufallsniveau"]
    schreiben(ziel / "n2_pro_lauf.csv", [z for zeilen in alle.values() for z in zeilen], felder)

    def tabelle(zeilen, seed=None):
        result = {}
        for z in zeilen:
            if seed is None or z["seed"] == seed:
                result.setdefault((z["tf"], z["richtung"], z["auswertung"]), []).append(z)
        return result
    seed13 = {key: tabelle(zeilen, 13) for key, zeilen in alle.items()}
    alt_alle = tabelle(alle["01"])
    schluessel = sorted(set().union(*(seed13[k] for k in seed13)), key=lambda k: (RICHTUNGEN.index(k[1]), k[2], k[0]))
    vergleich = []
    for key in schluessel:
        zeile = {"tf": key[0], "richtung": key[1], "auswertung": key[2]}
        erste = next(seed13[k][key][0] for k in ("N3", "N2", "N1", "01") if key in seed13[k])
        zeile.update(zufallsniveau=erste["zufallsniveau"], n_pos=erste["n_pos"], n_neg=erste["n_neg"])
        werte = [z["auprc"] for z in alt_alle.get(key, [])]
        mittel = statistics.fmean(werte) if werte else None
        zeile.update(auprc_01_seed13=seed13["01"][key][0]["auprc"] if key in seed13["01"] else None,
                     auprc_01_mittel=mittel, n_seeds_01=len(werte))
        for k in NEU:
            zeile[f"auprc_{k}"] = seed13[k][key][0]["auprc"] if key in seed13[k] else None
            zeile[f"delta_{k}_zu_01_mittel"] = (zeile[f"auprc_{k}"] - mittel
                                                if zeile[f"auprc_{k}"] is not None and mittel is not None else None)
        zeile["auroc_01_seed13"] = seed13["01"][key][0]["auroc"] if key in seed13["01"] else None
        for k in NEU:
            zeile[f"auroc_{k}"] = seed13[k][key][0]["auroc"] if key in seed13[k] else None
        vergleich.append(zeile)
    schreiben(ziel / "n2_vergleich.csv", vergleich, list(vergleich[0]) if vergleich else ["tf", "richtung", "auswertung"])

    median = []
    for richtung in RICHTUNGEN:
        for name in AUSWERTUNGEN.values():
            zeilen = [z for z in vergleich if z["richtung"] == richtung and z["auswertung"] == name]
            if not zeilen:
                continue
            m = {"richtung": richtung, "auswertung": name,
                 "median_zufallsniveau": statistics.median(z["zufallsniveau"] for z in zeilen)}
            mitte = [z["auprc_01_mittel"] for z in zeilen if z["auprc_01_mittel"] is not None]
            m["median_auprc_01"] = statistics.median(mitte) if mitte else None
            for k in NEU:
                werte = [z[f"auprc_{k}"] for z in zeilen if z[f"auprc_{k}"] is not None]
                deltas = [z[f"delta_{k}_zu_01_mittel"] for z in zeilen if z[f"delta_{k}_zu_01_mittel"] is not None]
                m[f"median_auprc_{k}"] = statistics.median(werte) if werte else None
                m[f"median_delta_{k}"] = statistics.median(deltas) if deltas else None
                m[f"{k}_besser"] = f"{sum(d > 0 for d in deltas)}/{len(deltas)}" if deltas else None
            median.append(m)
    schreiben(ziel / "n2_median.csv", median, list(median[0]) if median else ["richtung", "auswertung"])

    stichprobe = [z for key, name in TRAINING.items() for z in sampling(results / name, key)]
    schreiben(ziel / "n2_sampling.csv", stichprobe, list(stichprobe[0]) if stichprobe else ["config", "tf", "train"])

    def zahl(zeilen):
        return len({(z["tf"], z["richtung"].split("→")[0], z["seed"]) for z in zeilen})
    print("Abgeschlossene Läufe: " + ", ".join(f"{k} {zahl(alle[k])} (Ziel {126 if k == '01' else 42})" for k in alle))
    if median:
        print("\nMedian AUPRC je Richtung und Auswertung (01 = Mittel der drei Seeds; in Klammern Median der Differenz "
              "zu 01 und TFs besser):")
        for m in median:
            teile = [f"01 {m['median_auprc_01']:.4f}" if m["median_auprc_01"] is not None else "01 –"]
            for k in NEU:
                if m[f"median_auprc_{k}"] is not None:
                    teile.append(f"{k} {m[f'median_auprc_{k}']:.4f} ({m[f'median_delta_{k}']:+.4f}, {m[f'{k}_besser']})"
                                 if m[f"median_delta_{k}"] is not None else f"{k} {m[f'median_auprc_{k}']:.4f}")
            print(f"  {m['richtung']:<10} {m['auswertung']:<11} " + " | ".join(teile)
                  + f"  [Zufall {m['median_zufallsniveau']:.4f}]")
    print(f"\nTabellen: {ziel}")


if __name__ == "__main__":
    main()
