#!/usr/bin/env python3
"""Diagnose B: Korrigieren die Einzeländerungen verschiedene Fehler? (Ensemble-Test)

Ein Mittel aus mehreren Modellen ist fast immer besser als ein einzelnes, auch bei reinen Seed-Kopien. Deshalb wird
nur gegen ein Seed-Ensemble gleicher Größe gemessen. Je TF und Richtung (CC, GG, CG, GC):
  Ensemble          = Mittel der Perzentil-Ränge der Mitglieder, darauf die AUPRC.
  Ensemble-Gewinn   = AUPRC des Ensembles minus mittlere AUPRC seiner Mitglieder.
  Seed-Ensemble     = 01 mit Seed 13, 14 und 15.
  Änderungs-Ensembles = alle 84 Dreier aus den neun Einzeländerungen, Gewinn gemittelt.
  Komplementarität  = mittlerer Gewinn der Änderungs-Ensembles minus Gewinn des Seed-Ensembles.
Median über TFs, Wilcoxon gegen 0. Die Änderungen teilen Seed 13; das macht den Test vorsichtig: Ein positives
Ergebnis ist belastbar, ein Nullergebnis nur eingeschränkt.
Beschreibend: AUPRC des Ensembles aller neun gegen X01, gegen die beste Einzeländerung (pro Richtung fest: höchster
Median über TFs) und gegen 01 (Seed 13). Kein Maß für die Obergrenze des Modelltyps: ein Ensemble ist eine andere
Modellklasse.

Aufruf im Ordner diagnose_x01:  python diag_b_ensemble.py
"""
from __future__ import annotations

import itertools
import math
import sys

import diag_gemeinsam as g


def main() -> int:
    import numpy as np
    from sklearn.metrics import average_precision_score as ap

    modelle = g.modelle_ab()
    einzel = [g.kurz(e) for e in g.EINZEL]
    dreier = list(itertools.combinations(einzel, 3))
    tfs = g.middle_tfs()
    zeilen, dreier_zeilen, probleme = [], [], []
    abweichung = 0.0
    for tf in tfs:
        for richtung in g.RICHTUNGEN:
            labels, r, gespeichert, fehlt = g.lade_richtung(tf, richtung, modelle)
            noetig = ["01s13", "01s14", "01s15", *einzel]
            luecken = [k for k in noetig if k not in r]
            if labels is None or luecken:
                probleme.append(f"{tf}/{richtung}: fehlt " + ", ".join(f"{k} ({fehlt.get(k, 'nicht geladen')})"
                                                                        for k in luecken or noetig))
                continue
            einzel_ap = {k: float(ap(labels, v)) for k, v in r.items()}
            abweichung = max(abweichung, max((abs(einzel_ap[k] - gespeichert[k]) for k in r
                                              if math.isfinite(gespeichert[k])), default=0.0))

            def gewinn(mitglieder):
                ensemble = float(ap(labels, np.mean([r[m] for m in mitglieder], axis=0)))
                return ensemble - float(np.mean([einzel_ap[m] for m in mitglieder])), ensemble

            seed_gewinn, seed_ens = gewinn(("01s13", "01s14", "01s15"))
            gewinne = []
            for kombination in dreier:
                wert, ens = gewinn(kombination)
                gewinne.append(wert)
                dreier_zeilen.append({"tf": tf, "richtung": richtung, "dreier": "+".join(kombination),
                                      "gewinn": wert, "komplementaritaet": wert - seed_gewinn, "auprc_ensemble": ens})
            neun = float(ap(labels, np.mean([r[c] for c in einzel], axis=0)))
            zeilen.append({"tf": tf, "richtung": richtung, "n": int(labels.size), "n_pos": int(labels.sum()),
                           "auprc_01s13": einzel_ap["01s13"], "auprc_01s14": einzel_ap["01s14"],
                           "auprc_01s15": einzel_ap["01s15"], "auprc_X01": einzel_ap.get("X01", math.nan),
                           **{f"auprc_{c}": einzel_ap[c] for c in einzel},
                           "auprc_seed_ensemble": seed_ens, "gewinn_seed": seed_gewinn,
                           "gewinn_aenderungen": float(np.mean(gewinne)), "gewinn_aenderungen_min": float(min(gewinne)),
                           "gewinn_aenderungen_max": float(max(gewinne)),
                           "komplementaritaet": float(np.mean(gewinne)) - seed_gewinn, "auprc_ensemble_neun": neun})
        print(f"{tf}: fertig", flush=True)
    out = g.ERGEBNISSE
    g.schreibe_csv(out / "b_pro_tf.csv", zeilen)
    g.schreibe_csv(out / "b_pro_tf_dreier.csv", dreier_zeilen)

    vergleich, dreier_med = [], []
    text = ["Diagnose B: Korrigieren die Einzeländerungen verschiedene Fehler? (Ensemble-Test)",
            "Komplementarität = mittlerer Gewinn der 84 Dreier-Ensembles der Einzeländerungen minus Gewinn des",
            "Seed-Ensembles (01 mit Seed 13/14/15). Median über TFs; * p < 0,05, ~ p < 0,25 (Wilcoxon gegen 0, nur bei",
            "gleichem Vorzeichen von Mittel und Median). Die Änderungen teilen Seed 13: Ein positives Ergebnis ist",
            "belastbar, ein Nullergebnis nur eingeschränkt.", ""]
    for richtung in g.RICHTUNGEN:
        sel = [z for z in zeilen if z["richtung"] == richtung]
        if not sel:
            text.append(f"{richtung}: keine auswertbaren TFs")
            continue
        bester = max(einzel, key=lambda c: float(np.median([z[f"auprc_{c}"] for z in sel])))
        groessen = {
            "komplementaritaet": [z["komplementaritaet"] for z in sel],
            "gewinn_seed_ensemble": [z["gewinn_seed"] for z in sel],
            "gewinn_aenderungs_ensembles": [z["gewinn_aenderungen"] for z in sel],
            "ensemble_neun_minus_X01": [z["auprc_ensemble_neun"] - z["auprc_X01"] for z in sel],
            f"ensemble_neun_minus_bester_{bester}": [z["auprc_ensemble_neun"] - z[f"auprc_{bester}"] for z in sel],
            "ensemble_neun_minus_01": [z["auprc_ensemble_neun"] - z["auprc_01s13"] for z in sel],
            "X01_minus_01": [z["auprc_X01"] - z["auprc_01s13"] for z in sel],
        }
        stat = {}
        for name, werte in groessen.items():
            stat[name] = g.wilcoxon_zeile(werte)
            vergleich.append({"richtung": richtung, "groesse": name, **stat[name]})
        for kombination in dreier:
            name = "+".join(kombination)
            werte = [z["komplementaritaet"] for z in dreier_zeilen if z["richtung"] == richtung and z["dreier"] == name]
            dreier_med.append({"richtung": richtung, "dreier": name, **g.wilcoxon_zeile(werte)})

        def f(name):
            s = stat[name]
            return (f"Median {s['median']:+.4f} (Mittel {s['mittel']:+.4f}, besser/schlechter {s['besser']}/"
                    f"{s['schlechter']} von {s['n_tfs']}, p {s['p']:.3g} {s['marke']})").replace(" )", ")")

        k = stat["komplementaritaet"]
        lesart = ("die Änderungen korrigieren verschiedene Fehler" if k["median"] > 0 and k["marke"] == "*" else
                  "Hinweis auf verschiedene Fehler, nicht gesichert" if k["median"] > 0 and k["marke"] == "~" else
                  "kein Beleg für verschiedene Fehler (wegen des gemeinsamen Seeds nur eingeschränkt aussagekräftig)")
        text += [f"Richtung {richtung} ({len(sel)} TFs)",
                 f"  Komplementarität: {f('komplementaritaet')} -> {lesart}",
                 f"  Gewinn Seed-Ensemble {f('gewinn_seed_ensemble')}",
                 f"  Gewinn Änderungs-Ensembles {f('gewinn_aenderungs_ensembles')}",
                 f"  Beschreibend, Ensemble aller neun minus X01: {f('ensemble_neun_minus_X01')}",
                 f"  Ensemble aller neun minus beste Einzeländerung ({bester}): {f(f'ensemble_neun_minus_bester_{bester}')}",
                 f"  Ensemble aller neun minus 01: {f('ensemble_neun_minus_01')}; X01 minus 01: {f('X01_minus_01')}", ""]
    g.schreibe_csv(out / "b_vergleich.csv", vergleich)
    g.schreibe_csv(out / "b_dreier.csv", dreier_med)
    text.append(f"Kontrolle: Die aus predictions.tsv neu berechneten Einzel-AUPRCs weichen höchstens um {abweichung:.1e} "
                "von metrics.json ab (Rundung der gespeicherten Scores).")
    if probleme:
        text.append(f"Nicht ausgewertet ({len(probleme)} TF/Richtungen), z. B.: " + "; ".join(probleme[:5]))
    (out / "b_zusammenfassung.txt").write_text("\n".join(text) + "\n")
    print("\n".join(text))
    return 0


if __name__ == "__main__":
    sys.exit(main())
