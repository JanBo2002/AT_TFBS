#!/usr/bin/env bash
# Plant die Diagnosen A und B als CPU-Job ein. Er startet, sobald das Seed-Array (01_basic_0p1cdo_seed14/15) mit
# seinen Sammeljobs beendet ist, und bekommt dann den nächsten freien Platz vor den wartenden A36-Aufgaben.
#
#   bash diagnose_x01/ab_einplanen.sh [--account=NAME]      # auf dem Login-Knoten, in at_env, nach vorziehen.sh
#
# Ergebnisse danach in diagnose_x01/ergebnisse/ (a_*.csv, a_zusammenfassung.txt, b_*.csv, b_zusammenfassung.txt).
set -euo pipefail
HIER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BA="$(cd "$HIER/../big_ablation" && pwd)"
ACCOUNT=()
for arg in "$@"; do
    case "$arg" in
        --account=?*) ACCOUNT=("$arg") ;;
        *) echo "Unbekannte Option: $arg (Aufruf: bash ab_einplanen.sh [--account=NAME])" >&2; exit 2 ;;
    esac
done
for exe in sbatch squeue; do
    command -v "$exe" >/dev/null || { echo "Abgebrochen: $exe fehlt (Login-Knoten?)" >&2; exit 1; }
done
python3 -c "import numpy, scipy, sklearn" 2>/dev/null \
    || { echo "Abgebrochen: python3 ohne numpy/scipy/sklearn – zuerst at_env aktivieren." >&2; exit 1; }
if squeue --me -h -o "%j" | grep -x "h301_diag_ab" >/dev/null; then
    echo "Abgebrochen: Ein Job h301_diag_ab steht schon in der Queue." >&2; exit 1
fi

# Seed-Array und seine Sammeljobs in der Queue suchen
jobs="$(squeue --me -h -o "%F|%j|%P" | awk -F'|' \
    '$2 ~ /^h301_array_01_basic_0p1cdo_seed1[45]/ || $2 ~ /^h301_collect_01_basic_0p1cdo_seed1[45]$/' | sort -u)"
WARTE="$(echo "$jobs" | awk -F'|' 'NF {print $1}' | sort -un | paste -sd: -)"
PARTITION="$(echo "$jobs" | awk -F'|' '$2 ~ /^h301_collect_/ {print $3; exit}')"
if [ -z "$WARTE" ]; then
    for seed in 14 15; do
        [ -d "$BA/results/01_basic_0p1cdo_seed$seed/runs" ] || {
            echo "Abgebrochen: Das Seed-Array steht nicht in der Queue und results/01_basic_0p1cdo_seed$seed fehlt." \
                 "Zuerst bash diagnose_x01/vorziehen.sh ausführen." >&2; exit 1; }
    done
    echo "Seed-Läufe sind schon fertig: A und B starten ohne Wartebedingung."
fi

mkdir -p "$HIER/logs"
OPTIONEN=(--parsable --no-requeue --job-name=h301_diag_ab --chdir="$HIER" --output="$HIER/logs/diag_ab_%j.out"
          --time=06:00:00 --ntasks=1 --cpus-per-task=4 --mem=16G --export=ALL,DIAG_ORDNER="$HIER")
[ -n "$PARTITION" ] && OPTIONEN+=(--partition="$PARTITION")
[ -n "$WARTE" ] && OPTIONEN+=(--dependency=afterany:"$WARTE")
JOB="$(sbatch "${OPTIONEN[@]}" ${ACCOUNT[@]+"${ACCOUNT[@]}"} "$HIER/diag_ab_job.sh")"
JOB="${JOB%%;*}"
echo "Diagnosen A und B: Job $JOB" ${WARTE:+"(startet nach dem Ende von ${WARTE//:/, })"}
echo "Log: $HIER/logs/diag_ab_$JOB.out; Ergebnisse: $HIER/ergebnisse/"
