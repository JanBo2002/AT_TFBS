#!/usr/bin/env python3
"""Diagnose C: Ist X01 überregularisiert?

Die geloggte train_auprc taugt dafür nicht: Sie entsteht im Trainingsmodus (Dropout, Kanal-Dropout,
Stochastic Depth aktiv, zufällige Ausschnitte und Strangwechsel) und wird über alle Vorhersagen der Epoche
gepoolt, während sich die Gewichte ändern. Diese Analyse misst stattdessen den besten Checkpoint jedes
Laufs im Eval-Modus auf einem festen Teil der Trainingsdaten:
  - alle Trainings-Positiven, höchstens 5.000 je TF und Assay,
  - dazu Negative aus dem Trainings-Pool im Verhältnis der Validierung (Negative/Positive in split 1),
  - Auswahl mit festem Seed, für alle Modelle identisch,
  - Ausschnitte und Mittelung wie in der Validierung des Laufs (aus dem Checkpoint, hier multi mit
    beiden Strängen), derselbe Code wie Validierung und Test (training.run_epoch).
Modelle: 01, die neun Einzeländerungen und X01, je Seed 13, Split v1, die 21 Middle-TFs.

Aufruf im Ordner diagnose_x01 (big_ablation liegt daneben):
  python diag_c_trainingsfit.py inferenz     # GPU-Job; fortsetzbar, schreibt ergebnisse/c_laeufe.csv
  python diag_c_trainingsfit.py auswertung   # danach (CPU, Sekunden): Tabellen und Zusammenfassung
"""
from __future__ import annotations

import argparse
import hashlib
import math
import os
import sys
import time
from pathlib import Path

import diag_gemeinsam as g

MAX_POSITIVE = 5000
AUSWAHL_SEED = 20261123
METRIKEN = {
    "train_auprc": "AUPRC Trainingsteil (Eval-Modus)",
    "train_auroc": "AUROC Trainingsteil (Eval-Modus)",
    "val_auprc": "AUPRC Validierung (gewählter Checkpoint)",
    "test_auprc": "AUPRC Test in-assay",
    "luecke": "Lücke Training minus Validierung (AUPRC)",
}
FELDER = ["experiment", "kurz", "tf", "assay", "status", "hinweis", "n_pos", "n_neg", "verhaeltnis_val",
          "train_auprc", "train_auroc", "val_auprc", "val_auroc", "test_auprc", "luecke", "beste_epoche",
          "epochen", "crops", "gegenstrang", "pwm_count", "pwm_target_weight", "cache_sha256", "sekunden"]


def auswahl(cache, tf: str, assay: str):
    """Fester Trainingsteil: Indizes, Zahl der Positiven/Negativen und Verhältnis der Validierung."""
    import numpy as np
    labels, split = cache["labels"].astype(np.int64), cache["split"]
    val_pos = int(((split == 1) & (labels == 1)).sum())
    val_neg = int(((split == 1) & (labels == 0)).sum())
    if val_pos == 0:
        raise ValueError("keine Validierungs-Positiven")
    ratio = val_neg / val_pos
    digest = hashlib.sha256(f"{AUSWAHL_SEED}/{tf}/{assay}".encode()).digest()
    rng = np.random.default_rng(int.from_bytes(digest[:8], "little"))
    positive = np.flatnonzero((split == 0) & (labels == 1))
    negative = np.flatnonzero((split == 0) & (labels == 0))
    if positive.size > MAX_POSITIVE:
        positive = np.sort(rng.choice(positive, MAX_POSITIVE, replace=False))
    wanted = int(round(positive.size * ratio))
    hinweis = ""
    if wanted > negative.size:
        hinweis = f"nur {negative.size} Trainings-Negative statt {wanted}"
        wanted = negative.size
    negative = np.sort(rng.choice(negative, wanted, replace=False))
    return np.sort(np.concatenate([positive, negative])), int(positive.size), int(negative.size), ratio, hinweis


def bisherige(path: Path) -> set[tuple[str, str, str]]:
    import csv
    if not path.is_file():
        return set()
    with path.open(newline="") as handle:
        return {(r["experiment"], r["tf"], r["assay"]) for r in csv.DictReader(handle) if r["status"] == "ok"}


def anhaengen(path: Path, zeile: dict) -> None:
    import csv
    neu = not path.is_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FELDER, extrasaction="ignore")
        if neu:
            writer.writeheader()
        writer.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v) for k, v in zeile.items()})


def modell_bauen(run_config: dict, frozen: dict, tf: str, assay: str, device):
    """Wie fixed_views: Modell aus der gespeicherten Config des Laufs, Gewichte aus dem Checkpoint.

    Der Kontext schreibt nichts: kein Recorder, kein Laufordner (PWM-Manifeste bleiben unberührt)."""
    from types import SimpleNamespace
    import training
    context = SimpleNamespace(tf=tf, train_assay=assay, config=run_config, run_dir=None, recorder=None,
                              artifacts=None, root=g.PROJEKT, seed=g.SEED)
    model = training.invoke(run_config["predictor"], context,
                            model_config=training.ModelConfig(**frozen["model_config"]))
    model.load_state_dict(frozen["model_state"], strict=True)
    return model.to(device)


def inferenz(args) -> int:
    import numpy as np
    import torch
    import data
    import training

    device = torch.device(args.device if args.device != "auto" else ("cuda" if torch.cuda.is_available() else "cpu"))
    if device.type != "cuda":
        print("WARNUNG: keine GPU gefunden, Inferenz läuft auf der CPU (langsam).", flush=True)
    ausgabe = g.ERGEBNISSE / "c_laeufe.csv"
    fertig = bisherige(ausgabe)
    experimente = [g.BASIS, *g.EINZEL, g.KOMBI]
    tfs, cache_pfade = g.middle_tfs(), g.caches()
    workers = min(int(os.environ.get("SLURM_CPUS_PER_TASK", "4")), 8)
    print(f"Projekt {g.PROJEKT}; {len(experimente)} Modelle x {len(tfs)} TFs x {len(g.ASSAYS)} Assays; "
          f"Gerät {device}; schon fertig: {len(fertig)}", flush=True)
    auswahl_zeilen = []
    for tf in tfs:
        for assay in g.ASSAYS:
            offen = [e for e in experimente if (e, tf, assay) not in fertig]
            pfad = cache_pfade.get((tf, assay))
            if pfad is None:
                print(f"{tf}/{assay}: kein Cache in caches.csv, übersprungen", flush=True)
                continue
            cache = data.load_cache(pfad)
            indices, n_pos, n_neg, ratio, hinweis = auswahl(cache, tf, assay)
            cache_hash = data.sha256_file(pfad)
            auswahl_zeilen.append({"tf": tf, "assay": assay, "n_pos": n_pos, "n_neg": n_neg,
                                   "verhaeltnis_val": ratio, "hinweis": hinweis, "cache_sha256": cache_hash[:12],
                                   "auswahl_sha256": hashlib.sha256(
                                       "\n".join(map(str, cache["sample_ids"][indices])).encode()).hexdigest()[:12]})
            if not offen:
                continue
            loader = None
            for experiment in offen:
                start = time.perf_counter()
                zeile = {"experiment": experiment, "kurz": g.kurz(experiment), "tf": tf, "assay": assay,
                         "n_pos": n_pos, "n_neg": n_neg, "verhaeltnis_val": ratio, "hinweis": hinweis,
                         "cache_sha256": cache_hash[:12]}
                lauf = g.laufordner(experiment, tf, assay)
                meta = g.lies_json(lauf / "run.json") or {}
                checkpoint = lauf / "training" / "model_for_prediction.pt"
                if meta.get("status") != "completed" or not checkpoint.is_file():
                    zeile.update(status="fehlt", hinweis="kein abgeschlossener Lauf")
                    anhaengen(ausgabe, zeile)
                    continue
                try:
                    frozen = torch.load(checkpoint, map_location="cpu", weights_only=True)
                    if frozen.get("cache_sha256") != cache_hash:
                        raise ValueError("Checkpoint stammt von einem anderen Cache-Stand")
                    run_config = g.lies_json(lauf / "config.json") or meta.get("config")
                    manifest = g.lies_json(lauf / "pwm_target.json")   # tatsächlich genutztes PWM-Ziel des Laufs
                    if manifest:
                        zeile.update(pwm_count=manifest.get("pwm_count", ""),
                                     pwm_target_weight=manifest.get("target_weight", ""))
                    model = modell_bauen(run_config, frozen, tf, assay, device)
                    argumente = meta.get("resolved_training_arguments") or {}
                    mode, rc = frozen["evaluation_crop_mode"], bool(frozen["evaluation_reverse_complement"])
                    if loader is None or loader.batch_size != int(argumente.get("eval_batch_size", 128)):
                        loader = data.make_loader(data.TFBindingDataset(cache, indices),
                                                  int(argumente.get("eval_batch_size", 128)), False, workers, device)
                    criterion = torch.nn.BCEWithLogitsLoss(pos_weight=torch.tensor(
                        float(frozen["negatives_per_positive"]), device=device))
                    result = training.run_epoch(
                        model, loader, device, criterion, training.TrainingConfig(**frozen["training_config"]),
                        optimizer=None, scaler=None, use_amp=bool(frozen["amp_enabled"]) and device.type == "cuda",
                        gradient_clip=float(argumente.get("gradient_clip", 1.0)),
                        classification_threshold=float(frozen["classification_threshold"]),
                        eval_crops=mode, eval_rc=rc)
                    if int(result.labels.sum()) != n_pos or len(result.labels) != n_pos + n_neg:
                        raise ValueError("Auswahl und ausgewertete Beispiele passen nicht zusammen")
                    validierung = (g.lies_json(lauf / "training" / "validation_metrics.json") or {}).get(
                        "classification", {})
                    test = g.lies_json(lauf / "evaluations" / "standard" / assay / "metrics.json") or {}
                    verlauf = g.lies_json(lauf / "training" / "history.json") or []
                    zeile.update(
                        status="ok", train_auprc=float(result.classification["auprc"]),
                        train_auroc=float(result.classification["auroc"]),
                        val_auprc=g.zahl(validierung.get("auprc")), val_auroc=g.zahl(validierung.get("auroc")),
                        test_auprc=g.zahl((test.get("test_metrics") or {}).get("auprc"))
                        if test.get("status") == "completed" else math.nan,
                        beste_epoche=frozen.get("epoch", ""), epochen=len(verlauf),
                        crops="/".join(map(str, frozen.get("evaluation_crop_starts", []))) or mode,
                        gegenstrang=rc)
                    zeile["luecke"] = zeile["train_auprc"] - zeile["val_auprc"]
                    del model
                except Exception as error:  # noqa: BLE001 - Lauf melden, weitermachen
                    zeile.update(status="fehler", hinweis=f"{type(error).__name__}: {error}"[:300])
                zeile["sekunden"] = round(time.perf_counter() - start, 1)
                anhaengen(ausgabe, zeile)
                print(f"{tf}/{assay} {g.kurz(experiment)}: {zeile['status']}"
                      + (f", Trainingsteil AUPRC {zeile['train_auprc']:.4f}, Validierung {zeile['val_auprc']:.4f}"
                         if zeile["status"] == "ok" else f" ({zeile.get('hinweis', '')})"), flush=True)
            del cache, loader
            if device.type == "cuda":
                torch.cuda.empty_cache()
    g.schreibe_csv(g.ERGEBNISSE / "c_auswahl.csv", auswahl_zeilen)
    print("Inferenz fertig. Weiter mit: python diag_c_trainingsfit.py auswertung", flush=True)
    return 0


def auswertung(args) -> int:
    import csv
    import numpy as np

    pfad = g.ERGEBNISSE / "c_laeufe.csv"
    if not pfad.is_file():
        print(f"Fehlt: {pfad} (zuerst die Inferenz)", file=sys.stderr)
        return 1
    with pfad.open(newline="") as handle:
        zeilen = list(csv.DictReader(handle))
    werte = {}                                   # (kurz, assay, tf) -> Zeile; die letzte gültige zählt
    probleme = [z for z in zeilen if z["status"] != "ok"]
    for z in zeilen:
        if z["status"] == "ok":
            werte[(z["kurz"], z["assay"], z["tf"])] = {m: g.zahl(z[m]) for m in METRIKEN} | {
                "beste_epoche": g.zahl(z["beste_epoche"]), "pwm": (z["pwm_count"], z["pwm_target_weight"])}
    modelle = [g.kurz(e) for e in (g.BASIS, *g.EINZEL, g.KOMBI)]
    uebersicht, vergleich = [], []
    for assay in g.ASSAYS:
        for m in modelle:
            tfs = [k[2] for k in werte if k[0] == m and k[1] == assay]
            zeile = {"assay": assay, "modell": m, "n_tfs": len(tfs)}
            for metrik in (*METRIKEN, "beste_epoche"):
                x = np.array([werte[(m, assay, tf)][metrik] for tf in tfs], dtype=float)
                x = x[np.isfinite(x)]
                zeile[f"{metrik}_median"] = float(np.median(x)) if x.size else math.nan
                zeile[f"{metrik}_mittel"] = float(x.mean()) if x.size else math.nan
            uebersicht.append(zeile)
        for gegen in [g.kurz(g.BASIS), *[g.kurz(e) for e in g.EINZEL]]:
            for metrik in METRIKEN:
                gemeinsam = sorted({k[2] for k in werte if k[:2] == ("X01", assay)}
                                   & {k[2] for k in werte if k[:2] == (gegen, assay)})
                d = [werte[("X01", assay, tf)][metrik] - werte[(gegen, assay, tf)][metrik] for tf in gemeinsam]
                vergleich.append({"assay": assay, "metrik": metrik, "vergleich": f"X01 - {gegen}",
                                  **g.wilcoxon_zeile(d)})
    g.schreibe_csv(g.ERGEBNISSE / "c_uebersicht.csv", uebersicht)
    g.schreibe_csv(g.ERGEBNISSE / "c_vergleich.csv", vergleich)

    # Kurze Zusammenfassung mit der Lesart aus der Aufgabe
    def v(assay, metrik, gegen):
        return next(z for z in vergleich if z["assay"] == assay and z["metrik"] == metrik
                    and z["vergleich"] == f"X01 - {gegen}")

    def fmt(z):
        if z["n_tfs"] == 0:
            return "keine gemeinsamen Läufe"
        return (f"Median {z['median']:+.4f}, Mittel {z['mittel']:+.4f}, besser/schlechter {z['besser']}/"
                f"{z['schlechter']} von {z['n_tfs']}, p {z['p']:.3g} {z['marke']}".rstrip())

    text = ["Diagnose C: Ist X01 überregularisiert?",
            "Gemessen im Eval-Modus auf einem festen Trainingsteil (alle Trainings-Positiven bis 5.000 je TF und",
            "Assay, Negative im Verhältnis der Validierung), Crops wie in der Validierung. Differenzen X01 minus",
            "Vergleichsmodell, gepaart über TFs; * p < 0,05, ~ p < 0,25 (nur bei gleichem Vorzeichen von Mittel",
            "und Median).", ""]
    einzel = [g.kurz(e) for e in g.EINZEL]
    for assay in g.ASSAYS:
        text.append(f"Trainingsassay {assay}")
        for metrik in METRIKEN:
            text.append(f"  {METRIKEN[metrik]}: X01 gegen 01: {fmt(v(assay, metrik, '01'))}")
        tiefer = [e for e in einzel if v(assay, "train_auprc", e)["median"] < 0]
        sig = [e for e in tiefer if v(assay, "train_auprc", e)["marke"] == "*"]
        text.append(f"  Trainingsteil: X01 tiefer als {len(tiefer)} von 9 Einzeländerungen (Median der Differenz)"
                    + (f": {', '.join(tiefer)}" if tiefer else "") + (f"; signifikant: {', '.join(sig)}" if sig else ""))
        val_besser = [e for e in einzel if v(assay, "val_auprc", e)["median"] > 0 and v(assay, "val_auprc", e)["marke"] == "*"]
        text.append(f"  Validierung: X01 signifikant besser als {len(val_besser)} von 9 Einzeländerungen"
                    + (f": {', '.join(val_besser)}" if val_besser else ""))
        gegen01_train = v(assay, "train_auprc", "01")
        if gegen01_train["n_tfs"] == 0:
            text += ["  Lesart: keine gemeinsamen Läufe von X01 und 01.", ""]
            continue
        gruende = [g_ for g_ in (
            "Trainingsteil nicht tiefer als 01" if gegen01_train["median"] >= 0 else "",
            f"Trainingsteil nur unter {len(tiefer)} von 9 Einzeländerungen" if len(tiefer) < 5 else "",
            f"Validierung signifikant besser als {len(val_besser)} von 9 Einzeländerungen" if len(val_besser) >= 5 else "")
            if g_]
        text.append("  Lesart nach Aufgabe: " + (
            "X01 sitzt auf dem Trainingsteil tiefer als 01 und die meisten Einzeländerungen, ohne in der Validierung "
            "besser als die meisten zu sein: wahrscheinlich überregularisiert." if not gruende else
            "eher nicht überregularisiert (" + "; ".join(gruende) + ")."))
        text.append("")
    pwm = {w["pwm"] for k, w in werte.items() if k[0] in ("X01", "A32")}
    text.append("PWM-Ziel laut Manifest der Läufe (pwm_target.json): "
                + "; ".join(f"{m}: " + ", ".join(sorted({f"{w['pwm'][0]} PWMs, Gewicht {w['pwm'][1]}"
                                                         for k, w in werte.items() if k[0] == m}) or ["keine Angabe"])
                            for m in ("A32", "X01")))
    if len(pwm) > 1:
        text.append("ACHTUNG: A32 und X01 nutzen nicht dieselben PWM-Einstellungen.")
    if probleme:
        text.append(f"Nicht ausgewertet: {len(probleme)} Läufe, z. B. "
                    + "; ".join(f"{p['kurz']} {p['tf']}/{p['assay']}: {p['hinweis']}" for p in probleme[:5]))
    (g.ERGEBNISSE / "c_zusammenfassung.txt").write_text("\n".join(text) + "\n")
    print("\n".join(text))
    print(f"Tabellen: {g.ERGEBNISSE / 'c_uebersicht.csv'}, {g.ERGEBNISSE / 'c_vergleich.csv'}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("schritt", choices=("inferenz", "auswertung"))
    parser.add_argument("--device", default="auto", help="auto (GPU, sonst CPU), cuda oder cpu")
    args = parser.parse_args()
    return inferenz(args) if args.schritt == "inferenz" else auswertung(args)


if __name__ == "__main__":
    sys.exit(main())
