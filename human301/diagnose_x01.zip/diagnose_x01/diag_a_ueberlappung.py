#!/usr/bin/env python3
"""Diagnose A: Helfen die Einzeländerungen denselben Sequenzen?

Je TF und Richtung (CC, GG, CG, GC) werden die Testscores jedes Modells in Perzentil-Ränge r(m, i) von 0 bis 1
umgerechnet (Mittelrang bei Gleichstand). Alle Größen werden getrennt für Positive und Negative berechnet.
  s(i) = +1 für Positive, -1 für Negative; Verbesserung gegen eine Basis b: d(m, b, i) = s(i) * (r(m, i) - r(b, i)).
Getrennte Basen: Korrelation (Spearman) von d(c1, 01 Seed 14) mit d(c2, 01 Seed 15), dazu vertauscht, gemittelt.
Rauschkorrektur:
  2σ² = Var(r(01 Seed 14) - r(01 Seed 15)); rel(c) = (Var(d(c)) - 2σ²) / Var(d(c)), Var(d(c)) über beide Basen gemittelt.
  Überlappung(c1, c2) = Korrelation / Wurzel(rel(c1) * rel(c2)); Paare mit rel < 0,1 gelten als nicht auswertbar.
Null-Kontrolle: 01 Seed 13 als Änderung ohne Effekt. Ihre Korrelation mit einer Änderung misst, was der gemeinsame
  Seed 13 allein beiträgt. Die nullkorrigierte Fassung zieht diesen Anteil auf Ebene der Kovarianz ab, bevor durch die
  Zuverlässigkeit geteilt wird: Die gemeinsame Kovarianz ist rho_null(c) * Wurzel(V0 * Vc) (V = Var(d), V0 für die
  Null-Änderung); ihr Anteil an der Korrelation von c1 und c2 ist damit rho_null(c2) * Wurzel(V0 / V1) bzw.
  rho_null(c1) * Wurzel(V0 / V2), beide Schätzungen gemittelt. (Die Null-Änderung hat keinen Effekt und daher die
  kleinste Varianz; ihre Korrelation direkt abzuziehen, würde zu viel abziehen.)
X01: Übertragung(c) = (Steigung von d(X01, Seed 14) auf d(c, Seed 15), vertauscht gemittelt, minus dieselbe Steigung
  mit 01 Seed 13 statt X01) / rel(c). Etwa 1: das Muster von c kommt in X01 an; etwa 0: es geht verloren.

Aufruf im Ordner diagnose_x01:  python diag_a_ueberlappung.py
"""
from __future__ import annotations

import itertools
import math
import sys

import diag_gemeinsam as g

REL_MIN = 0.1
KLASSEN = {"positiv": 1, "negativ": 0}


def z_raenge(x):
    """Standardisierte Ränge: Mittelwert 0, Varianz 1. Das Mittel ihres Produkts ist die Spearman-Korrelation."""
    import numpy as np
    from scipy.stats import rankdata
    r = rankdata(x, method="average")
    r = r - r.mean()
    sd = r.std()
    return r / sd if sd > 0 else np.full(r.shape, np.nan)


def steigung(y, x) -> float:
    import numpy as np
    vx = float(np.var(x))
    return float(np.mean((x - x.mean()) * (y - y.mean())) / vx) if vx > 0 else math.nan


def analyse(tf: str, richtung: str, modelle: dict, einzel: list[str]):
    import numpy as np
    labels, r, _auprc, fehlt = g.lade_richtung(tf, richtung, modelle)
    probleme = [f"{tf}/{richtung} {k}: {v}" for k, v in fehlt.items()]
    if labels is None or "01s14" not in r or "01s15" not in r:
        return [], [], probleme + [f"{tf}/{richtung}: ohne beide Seed-Basen nicht auswertbar"]
    paare, aenderungen = [], []
    s = np.where(labels == 1, 1.0, -1.0)
    kandidaten = [c for c in (*einzel, "X01", "01s13") if c in r]
    for klasse, wert in KLASSEN.items():
        maske = labels == wert
        if maske.sum() < 10:
            probleme.append(f"{tf}/{richtung}/{klasse}: zu wenige Sequenzen")
            continue
        b14, b15, sk = r["01s14"][maske], r["01s15"][maske], s[maske]
        zwei_sigma2 = float(np.var(b14 - b15))
        d, z, rel, v = {}, {}, {}, {}
        for c in kandidaten:
            rc = r[c][maske]
            d[c] = (sk * (rc - b14), sk * (rc - b15))
            z[c] = (z_raenge(d[c][0]), z_raenge(d[c][1]))
            var_d = 0.5 * (float(np.var(d[c][0])) + float(np.var(d[c][1])))
            v[c] = var_d
            rel[c] = (var_d - zwei_sigma2) / var_d if var_d > 0 else math.nan

        def rho(c1, c2):          # d(c1, Seed 14) mit d(c2, Seed 15) und vertauscht, gemittelt
            return 0.5 * (float(np.mean(z[c1][0] * z[c2][1])) + float(np.mean(z[c1][1] * z[c2][0])))

        def anstieg(y, x):        # Steigung von d(y, Seed 14) auf d(x, Seed 15) und vertauscht, gemittelt
            return 0.5 * (steigung(d[y][0], d[x][1]) + steigung(d[y][1], d[x][0]))

        null = {c: rho("01s13", c) if "01s13" in d else math.nan for c in kandidaten if c != "01s13"}
        for c in kandidaten:
            zeile = {"tf": tf, "richtung": richtung, "klasse": klasse, "aenderung": c, "n": int(maske.sum()),
                     "zwei_sigma2": zwei_sigma2, "var_d": 0.5 * (float(np.var(d[c][0])) + float(np.var(d[c][1]))),
                     "rel": rel[c], "rho_null": null.get(c, math.nan)}
            if c in einzel and "X01" in d:
                roh = anstieg("X01", c)
                nul = anstieg("01s13", c) if "01s13" in d else math.nan
                zeile.update(steigung_roh=roh, steigung_null=nul,
                             uebertragung=(roh - nul) / rel[c] if rel[c] >= REL_MIN else math.nan)
            aenderungen.append(zeile)
        for c1, c2 in itertools.combinations([c for c in einzel if c in d], 2):
            roh = rho(c1, c2)
            if "01s13" in v and v[c1] > 0 and v[c2] > 0:
                anteil = 0.5 * (null[c1] * math.sqrt(v["01s13"] / v[c2]) + null[c2] * math.sqrt(v["01s13"] / v[c1]))
            else:
                anteil = math.nan
            korr = roh - anteil
            auswertbar = rel[c1] >= REL_MIN and rel[c2] >= REL_MIN
            nenner = math.sqrt(rel[c1] * rel[c2]) if auswertbar else math.nan
            paare.append({"tf": tf, "richtung": richtung, "klasse": klasse, "c1": c1, "c2": c2, "rho": roh,
                          "rho_korr": korr, "auswertbar": auswertbar,
                          "ueberlappung": roh / nenner if auswertbar else math.nan,
                          "ueberlappung_korr": korr / nenner if auswertbar else math.nan})
    return paare, aenderungen, probleme


def median(werte):
    import numpy as np
    x = np.asarray([v for v in werte if isinstance(v, float) and math.isfinite(v)], dtype=float)
    return float(np.median(x)) if x.size else math.nan


def main() -> int:
    modelle = g.modelle_ab()
    einzel = [g.kurz(e) for e in g.EINZEL]
    tfs = g.middle_tfs()
    paare, aenderungen, probleme = [], [], []
    for tf in tfs:
        for richtung in g.RICHTUNGEN:
            p, a, f = analyse(tf, richtung, modelle, einzel)
            paare += p; aenderungen += a; probleme += f
        print(f"{tf}: fertig", flush=True)
    out = g.ERGEBNISSE
    g.schreibe_csv(out / "a_pro_tf_paare.csv", paare)
    g.schreibe_csv(out / "a_pro_tf_aenderungen.csv", aenderungen)

    zuverl, nullk, uebertr, paar_med, matrizen = [], [], [], [], []
    text = ["Diagnose A: Helfen die Einzeländerungen denselben Sequenzen?",
            "Überlappung 0: hilft verschiedenen Sequenzen, 1: denselben. Median über TFs; Paare mit rel < 0,1 nicht",
            "auswertbar. * p < 0,05, ~ p < 0,25 (Wilcoxon über TFs, nur bei gleichem Vorzeichen von Mittel und Median).",
            ""]
    for richtung in g.RICHTUNGEN:
        text.append(f"Richtung {richtung}")
        for klasse in KLASSEN:
            sel = [a for a in aenderungen if a["richtung"] == richtung and a["klasse"] == klasse]
            if not sel:
                text.append(f"  {klasse}: keine auswertbaren TFs")
                continue
            for c in (*einzel, "X01", "01s13"):
                rows = [a for a in sel if a["aenderung"] == c]
                rel = [a["rel"] for a in rows]
                zuverl.append({"richtung": richtung, "klasse": klasse, "aenderung": c, "n_tfs": len(rows),
                               "rel_median": median(rel), "anteil_rel_unter_0p1":
                               (sum(1 for x in rel if not x >= REL_MIN) / len(rel)) if rel else math.nan,
                               "var_d_median": median([a["var_d"] for a in rows]),
                               "zwei_sigma2_median": median([a["zwei_sigma2"] for a in rows])})
                if c != "01s13":
                    nullk.append({"richtung": richtung, "klasse": klasse, "aenderung": c,
                                  **g.wilcoxon_zeile([a["rho_null"] for a in rows])})
                if c in einzel:
                    werte = [a.get("uebertragung", math.nan) for a in rows]
                    gegen0 = g.wilcoxon_zeile(werte)
                    gegen1 = g.wilcoxon_zeile([w - 1 for w in werte])
                    uebertr.append({"richtung": richtung, "klasse": klasse, "aenderung": c, "n_tfs": gegen0["n_tfs"],
                                    "median": gegen0["median"], "mittel": gegen0["mittel"], "p_gegen_0": gegen0["p"],
                                    "marke_gegen_0": gegen0["marke"], "p_gegen_1": gegen1["p"],
                                    "marke_gegen_1": gegen1["marke"]})
            rel_med = {z["aenderung"]: z["rel_median"] for z in zuverl
                       if z["richtung"] == richtung and z["klasse"] == klasse}
            messbar = {c for c in einzel if rel_med.get(c, math.nan) >= REL_MIN}
            for u in uebertr:
                if u["richtung"] == richtung and u["klasse"] == klasse and u["aenderung"] not in messbar:
                    u.update(median=math.nan, mittel=math.nan, p_gegen_0=math.nan, marke_gegen_0="",
                             p_gegen_1=math.nan, marke_gegen_1="", hinweis="rel unter 0,1: nicht auswertbar")
            pz = [p for p in paare if p["richtung"] == richtung and p["klasse"] == klasse]
            med = {}
            for c1, c2 in itertools.combinations(einzel, 2):
                rows = [p for p in pz if p["c1"] == c1 and p["c2"] == c2]
                ok = [p for p in rows if p["auswertbar"]] if {c1, c2} <= messbar else []
                med[(c1, c2)] = {"roh": median([p["ueberlappung"] for p in ok]),
                                 "korr": median([p["ueberlappung_korr"] for p in ok])}
                paar_med.append({"richtung": richtung, "klasse": klasse, "c1": c1, "c2": c2, "n_tfs": len(rows),
                                 "auswertbar": {c1, c2} <= messbar,
                                 "n_auswertbar": len(ok), "rho_median": median([p["rho"] for p in rows]),
                                 "rho_korr_median": median([p["rho_korr"] for p in rows]),
                                 "ueberlappung_median": med[(c1, c2)]["roh"],
                                 "ueberlappung_korr_median": med[(c1, c2)]["korr"]})
            for version, key in (("roh", "roh"), ("nullkorrigiert", "korr")):
                for c1 in einzel:
                    zeile = {"richtung": richtung, "klasse": klasse, "version": version, "aenderung": c1}
                    for c2 in einzel:
                        zeile[c2] = 1.0 if c1 == c2 else med[tuple(sorted((c1, c2), key=einzel.index))][key]
                    matrizen.append(zeile)
            # Zusammenfassung dieser Richtung/Klasse
            nz = [z for z in nullk if z["richtung"] == richtung and z["klasse"] == klasse and z["aenderung"] in einzel]
            null_med = median([z["median"] for z in nz])
            null_sig = sum(1 for z in nz if z["marke"] == "*" and z["median"] > 0)
            deutlich = null_sig >= 5
            key = "korr" if deutlich else "roh"
            werte = sorted((v[key], f"{c1}/{c2}") for (c1, c2), v in med.items() if math.isfinite(v[key]))
            zr = {z["aenderung"]: z for z in zuverl if z["richtung"] == richtung and z["klasse"] == klasse}
            rels = [zr[c]["rel_median"] for c in einzel if math.isfinite(zr[c]["rel_median"])]
            schwach = [c for c in einzel if not zr[c]["rel_median"] >= REL_MIN]
            rauschen = median(list({a["tf"]: a["zwei_sigma2"] for a in sel}.values()))
            null_rel = zr.get("01s13", {}).get("rel_median", math.nan)
            text.append(f"  {klasse}: Seed-Rauschen 2σ² {rauschen:.4g}; rel(c) "
                        + (f"{min(rels):.2f} bis {max(rels):.2f}" if rels else "nicht bestimmbar")
                        + (f" (unter 0,1: {', '.join(schwach)})" if schwach else "")
                        + f"; rel(01 Seed 13, sollte nahe 0 liegen) {null_rel:.2f}")
            text.append(f"    Null-Kontrolle: Median {null_med:+.3f}, signifikant über 0 bei {null_sig} von 9 Änderungen"
                        f" -> maßgeblich ist die {'nullkorrigierte' if deutlich else 'rohe'} Überlappung")
            if werte:
                text.append(f"    Überlappung der 36 Paare: Median {median([w for w, _ in werte]):.2f}, "
                            f"kleinste {werte[0][1]} {werte[0][0]:.2f}, größte {werte[-1][1]} {werte[-1][0]:.2f}")
            tz = [u for u in uebertr if u["richtung"] == richtung and u["klasse"] == klasse]
            text.append("    X01 übernimmt (Übertragung, Median): " + ", ".join(
                f"{u['aenderung']} {u['median']:.2f}{u['marke_gegen_0']}" for u in tz if math.isfinite(u["median"])))
        text.append("")
    g.schreibe_csv(out / "a_zuverlaessigkeit.csv", zuverl)
    g.schreibe_csv(out / "a_nullkontrolle.csv", nullk)
    g.schreibe_csv(out / "a_paare.csv", paar_med)
    g.schreibe_csv(out / "a_matrizen.csv", matrizen)
    g.schreibe_csv(out / "a_x01_uebertragung.csv", uebertr)
    if probleme:
        text.append(f"Nicht ausgewertet ({len(probleme)}), z. B.: " + "; ".join(probleme[:6]))
    text.append("Marke bei der Übertragung: Wilcoxon gegen 0; in a_x01_uebertragung.csv auch gegen 1.")
    (out / "a_zusammenfassung.txt").write_text("\n".join(text) + "\n")
    print("\n".join(text))
    return 0


if __name__ == "__main__":
    sys.exit(main())
