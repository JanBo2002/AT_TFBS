#!/usr/bin/env bash
# CPU-Job für die Diagnosen A und B; ab_einplanen.sh reicht ihn mit Wartebedingung auf das Seed-Array ein.
set -euo pipefail
cd "$DIAG_ORDNER"
PY="${CONDA_PREFIX:+$CONDA_PREFIX/bin/python}"
PY="${PY:-$(command -v python3)}"
echo "Diagnosen A und B als $(id -un) auf $(hostname) mit $PY, Job $SLURM_JOB_ID"
rc=0
"$PY" diag_a_ueberlappung.py || rc=$?
"$PY" diag_b_ensemble.py || rc=$?
exit $rc
