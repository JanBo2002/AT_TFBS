"""Gemeinsame Teile der Diagnose-Analysen zu X01 (A, B, C).

Die Analysen lesen nur aus big_ablation (Configs, Caches, Läufe) und schreiben nur in diesen Ordner.
Sie liegen bewusst außerhalb von big_ablation: Neue .py-Dateien dort würden den Code-Hash laufender
Experimente verändern.
"""
from __future__ import annotations

import csv
import json
import math
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True                      # nichts in big_ablation/__pycache__ schreiben
HIER = Path(__file__).resolve().parent
PROJEKT = Path(os.environ.get("DIAG_PROJEKT", HIER.parent / "big_ablation")).resolve()
ERGEBNISSE = Path(os.environ.get("DIAG_ERGEBNISSE", HIER / "ergebnisse")).resolve()
if str(PROJEKT) not in sys.path:
    sys.path.insert(0, str(PROJEKT))

BASIS = "01_basic_0p1cdo"
EINZEL = [
    "A14_kernel_3_6_9_12_128c_do0p2_100epo",
    "A32_pwm_target03_middle",
    "B03_groupnorm_middle",
    "B04_gelu_middle",
    "B08_se_max_middle",
    "B09_bottleneck128_middle",
    "B12_stochastic_depth_0p1_middle",
    "B14_readout_lse16_middle",
    "B17_encoder_kernel3_middle",
]
KOMBI = "X01_bestA_beginnB"
SEED = 13
ASSAYS = ("CHIP", "GHTS")
KURZ_ASSAY = {"CHIP": "C", "GHTS": "G"}


def kurz(name: str) -> str:
    """Kurzname: Teil vor dem ersten Unterstrich (01, A14, ..., X01)."""
    return name.split("_", 1)[0]


def middle_tfs() -> list[str]:
    """Die 21 TFs des Middle-Sets in der Reihenfolge der Prioritätsliste."""
    import data
    ranks = data.read_priority(PROJEKT / "configs" / "training_priority_middle.csv")
    tfs = []
    for (tf, _assay), _rank in sorted(ranks.items(), key=lambda item: item[1]):
        if tf not in tfs:
            tfs.append(tf)
    return tfs


def caches() -> dict[tuple[str, str], Path]:
    with (PROJEKT / "configs" / "caches.csv").open(newline="") as handle:
        return {(row["tf"], row["assay"]): Path(row["cache"]) for row in csv.DictReader(handle)}


def laufordner(experiment: str, tf: str, assay: str, seed: int = SEED) -> Path:
    return PROJEKT / "results" / experiment / "runs" / tf / f"train_{assay}" / f"seed_{seed:02d}"


def lies_json(path: Path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def zahl(value) -> float:
    try:
        value = float(value)
    except (TypeError, ValueError):
        return math.nan
    return value if math.isfinite(value) else math.nan


def wilcoxon_zeile(differenzen) -> dict:
    """Gepaarter Wilcoxon über TFs wie bisher: zweiseitig, SciPy-Standard (exakt ohne Nullen und Bindungen).

    * bei p < 0,05, ~ bei p < 0,25, jeweils nur, wenn Mittelwert und Median dasselbe Vorzeichen haben.
    """
    import numpy as np
    from scipy.stats import wilcoxon

    d = np.asarray([x for x in differenzen if math.isfinite(x)], dtype=float)
    zeile = {"n_tfs": int(d.size), "mittel": math.nan, "median": math.nan,
             "besser": int((d > 0).sum()), "schlechter": int((d < 0).sum()), "p": math.nan, "marke": ""}
    if d.size == 0:
        return zeile
    zeile["mittel"], zeile["median"] = float(d.mean()), float(np.median(d))
    if d.size >= 2 and np.any(d != 0):
        try:
            zeile["p"] = float(wilcoxon(d).pvalue)
        except ValueError:
            pass
    gleich = np.sign(zeile["mittel"]) == np.sign(zeile["median"]) and zeile["median"] != 0
    if gleich and math.isfinite(zeile["p"]):
        zeile["marke"] = "*" if zeile["p"] < 0.05 else "~" if zeile["p"] < 0.25 else ""
    return zeile


def schreibe_csv(path: Path, zeilen: list[dict], felder: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    felder = felder or (list(zeilen[0]) if zeilen else [])
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=felder, extrasaction="ignore")
        writer.writeheader()
        for zeile in zeilen:
            writer.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v) for k, v in zeile.items()})
