#!/usr/bin/env bash
# Zieht Diagnose C und die beiden 01-Seed-Läufe vor die noch wartenden Aufgaben der älteren Arrays (jetzt A36).
#
#   bash diagnose_x01/vorziehen.sh [--account=NAME]      # auf dem Login-Knoten, in at_env
#
# Was passiert:
#   1. Die Configs 01_basic_0p1cdo_seed14/15 kommen nach big_ablation/configs (falls noch nicht da).
#   2. submit_array.sh reicht beide Seeds als ein Array ein (wie immer, inkl. Sammeljobs). Danach wird nur die
#      Wartebedingung dieses Arrays auf die älteren Arrays gelöscht, sonst begänne es erst nach allen 138 A36-Aufgaben.
#   3. Die noch wartenden Aufgaben der älteren Arrays bekommen eine niedrigere Priorität (Nice). Laufende Aufgaben
#      laufen normal zu Ende; jeder frei werdende Platz geht zuerst an Diagnose C, dann an die Seeds, dann an A36.
#   4. Diagnose C wird als GPU-Job eingereicht, mit denselben #SBATCH-Zeilen wie die Trainingsaufgaben.
#   5. Das Aufräumen wird wie gewohnt neu eingeplant.
# Rückgängig (A36 wieder normal priorisieren):  scontrol update JobId=<A36-Array> Nice=0
set -euo pipefail
HIER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BA="$(cd "$HIER/../big_ablation" && pwd)"
ACCOUNT=()
for arg in "$@"; do
    case "$arg" in
        --account=?*) ACCOUNT=("$arg") ;;
        *) echo "Unbekannte Option: $arg (Aufruf: bash vorziehen.sh [--account=NAME])" >&2; exit 2 ;;
    esac
done
SEEDS=(01_basic_0p1cdo_seed14 01_basic_0p1cdo_seed15)

echo "== Prüfen"
for exe in sbatch squeue scontrol scancel; do
    command -v "$exe" >/dev/null || { echo "Abgebrochen: $exe fehlt (Login-Knoten?)" >&2; exit 1; }
done
python3 -c "import torch, scipy, sklearn" 2>/dev/null \
    || { echo "Abgebrochen: python3 ohne torch/scipy/sklearn – zuerst at_env aktivieren." >&2; exit 1; }
[ -f "$BA/train_array.sbatch" ] || { echo "Abgebrochen: $BA/train_array.sbatch fehlt." >&2; exit 1; }
for name in "${SEEDS[@]}"; do
    if [ -f "$BA/configs/$name.json" ]; then
        cmp -s "$HIER/configs/$name.json" "$BA/configs/$name.json" \
            || { echo "Abgebrochen: configs/$name.json existiert schon mit anderem Inhalt." >&2; exit 1; }
    fi
done

echo "== Seeds einreichen"
for name in "${SEEDS[@]}"; do
    [ -f "$BA/configs/$name.json" ] || cp "$HIER/configs/$name.json" "$BA/configs/$name.json"
done
ausgabe="$(cd "$BA" && bash submit_array.sh "${SEEDS[@]}" ${ACCOUNT[@]+"${ACCOUNT[@]}"} 2>&1)" || { echo "$ausgabe"; exit 1; }
echo "$ausgabe"
SEED_ARRAY="$(echo "$ausgabe" | sed -n 's/^Jobarray \([0-9][0-9]*\):.*/\1/p' | head -1)"
[ -n "$SEED_ARRAY" ] || { echo "Abgebrochen: Nummer des Seed-Arrays nicht gefunden." >&2; exit 1; }
if scontrol update JobId="$SEED_ARRAY" Dependency=; then
    echo "Seed-Array $SEED_ARRAY wartet nicht mehr auf die älteren Arrays (die Meldung oben gilt damit nicht mehr)."
else
    echo "WARNUNG: Wartebedingung von $SEED_ARRAY nicht gelöscht – die Seeds starten erst nach A36." >&2
fi
scontrol update JobId="$SEED_ARRAY" Nice=10 || echo "WARNUNG: Nice für $SEED_ARRAY nicht gesetzt." >&2

echo "== Ältere wartende Arrays nach hinten"
for job in $(squeue --me -h -t PENDING -o "%F %j" | awk '$2 ~ /^h301_array_/ {print $1}' | sort -u); do
    [ "$job" = "$SEED_ARRAY" ] && continue
    if scontrol update JobId="$job" Nice=100000; then
        echo "Array $job: niedrigere Priorität (Nice 100000)"
    else
        echo "WARNUNG: Priorität von Array $job nicht gesenkt – Ausgabe unten prüfen." >&2
    fi
done

echo "== Diagnose C einreichen"
mkdir -p "$HIER/logs"
JOBFILE="$HIER/logs/diag_c_job.sbatch"
{
    echo "#!/usr/bin/env bash"
    grep '^#SBATCH' "$BA/train_array.sbatch" \
        | grep -v -E -e '--(job-name|output|error|array|chdir|dependency)' -e '^#SBATCH[[:space:]]+-[JoeaDd]([[:space:]=]|$)' || true
    sed 1d "$HIER/diag_c_job.sh"
} > "$JOBFILE"
DIAG_C="$(sbatch --parsable ${ACCOUNT[@]+"${ACCOUNT[@]}"} --no-requeue --job-name=h301_diag_c --chdir="$HIER" \
    --output="$HIER/logs/diag_c_%j.out" --export=ALL,DIAG_ORDNER="$HIER" "$JOBFILE")"
DIAG_C="${DIAG_C%%;*}"
echo "Diagnose C: Job $DIAG_C (Ressourcen wie train_array.sbatch; Log $HIER/logs/diag_c_$DIAG_C.out)"

echo "== Aufräumen neu einplanen"
scancel -u "$USER" -n h301_aufraeumen || true
(cd "$BA" && bash aufraeumen.sh --nach-jobs)

echo "== Wartende Jobs mit Priorität (höher startet zuerst)"
squeue --me -t PENDING -o "%.18i %.10Q %.22r %.60j"
