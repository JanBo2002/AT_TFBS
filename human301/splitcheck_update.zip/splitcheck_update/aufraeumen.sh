#!/usr/bin/env bash
# Version: 2026-11-13-aufraeumen-5
#
# Räumt big_ablation auf und löscht dabei endgültig (Dateien in git bleiben in der Historie):
#   Teil 1, jederzeit:   Paketreste (Installer, Prüfsummen, Word-Dateien, CHANGES.diff, tests.zip, files/),
#                        Sicherungen und verworfene Ergebnisse neben big_ablation, Pläne und Slurm-Logs
#                        aller Arrays, die nicht mehr in der Queue sind.
#   Teil 2, erst wenn kein Job dieses Projekts mehr läuft oder wartet (alle Konten, soweit squeue sie zeigt):
#                        alte Hilfsscripte (.py) und Launcher, tests/, certified_code/, conda_root.txt und
#                        dieses Script. .py-Dateien gehen in den Code-Stand ein; vorher entfernt, brächen
#                        laufende und wartende Tasks ab.
# Nie angefasst: Programmdateien, submit_array.sh, Job-Skripte, configs/ (außer conda_root.txt), caches/,
# results/, altcode_restart_v2/ und alles Unbekannte (wird nur aufgelistet).
#
#   bash aufraeumen.sh              # nur anzeigen, was passieren würde
#   bash aufraeumen.sh --apply      # sofort ausführen; Teil 2 nur, wenn nichts mehr läuft
#   bash aufraeumen.sh --nach-jobs  # als kleinen Slurm-Job einplanen, der startet, sobald alle jetzt
#                                   # laufenden/wartenden Jobs dieses Projekts beendet sind
# Der eingeplante Job räumt nur dann vollständig auf, wenn alle diese Jobs mit COMPLETED endeten. Sonst behält
# er deren Logs (zur Fehlersuche) und die Hilfsscripte (damit ein --restart ohne Sonderschalter klappt) und
# bleibt selbst liegen. Protokoll: ~/aufraeumen_<Jobnummer>.out
#
# Was in git liegt, wird mit git rm entfernt und am Ende committet; pushen musst du selbst.
set -euo pipefail
ROOT="${AUFRAEUMEN_ROOT:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)}"
if [[ -n "${SLURM_JOB_ID:-}" && "${AUFRAEUMEN_ALS_JOB:-0}" != "1" ]]; then
    echo "Abgebrochen: auf dem Login-Knoten starten (als Slurm-Job nur über --nach-jobs)." >&2
    exit 1
fi
export ABLATION_PYTHON="${ABLATION_PYTHON:-$(command -v python3)}"
exec "$ABLATION_PYTHON" - "$ROOT" "$@" <<'PY'
import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
options = sys.argv[2:]
for option in options:
    if option not in ("--apply", "--nach-jobs"):
        print(f"Unbekannte Option: {option}  (Aufruf: bash aufraeumen.sh [--apply | --nach-jobs])", file=sys.stderr)
        sys.exit(2)
apply, schedule = "--apply" in options, "--nach-jobs" in options
if apply and schedule:
    sys.exit("Entweder --apply oder --nach-jobs.")
as_job = os.environ.get("AUFRAEUMEN_ALS_JOB") == "1" and bool(os.environ.get("SLURM_JOB_ID"))
own_job = os.environ.get("SLURM_JOB_ID", "")
waited = [x for x in os.environ.get("AUFRAEUMEN_WARTET_AUF", "").split(":") if x] if as_job else []
parent = root.parent
if not (root / "submit_array.sh").is_file() or not (root / "configs").is_dir():
    sys.exit(f"Abgebrochen: {root} sieht nicht wie big_ablation aus.")

PROGRAM = {"model.py": {"5839dae12329", "038cc63bc9b1"}, "data.py": {"51265f5843b7", "bab35d9093c9", "6c0fa250a7d2", "65a3a303e2a4"},
           "training.py": {"98667ae8b452", "d459e4abc202"}, "run_experiment.py": {"bfccdef0aaa8"}}
KEEP = {"run_experiment.py", "model.py", "data.py", "training.py", "submit_array.sh", "train_array.sbatch",
        "collect_config.sbatch", "configs", "caches", "results", "plans", "__pycache__", "altcode_restart_v2",
        "mex_pwm_model.py", ".gitignore", ".gitattributes", "aufraeumen.sh"}
NOW = ["CHANGES.diff", "Testprotokoll_A30-A35.docx", "Testprotokoll_BlockB.docx",
       "Anleitung_Fremdkonto_Einreichung.docx", "install_block_b_update.pyz", "package_checksums.json",
       "tests.zip", "source_checksums.json", "files", "middle_update_v2.zip", "middle_update.zip",
       "a30_update.zip", "blockb_update.zip", "install_pwmsplit_update.pyz", "pwmsplit_update.zip",
       "folgelaeufe.zip", "install_blockc_update.pyz", "blockc_update.zip", "blockA_A41_A42.zip", "kernel_3_5.zip",
       "kernel_3_5_A37_A38.zip", "pwm_3_5_A39_A40.zip", "install_splitcheck_update.pyz",
       "splitcheck_update.zip"]
NOW_BESIDE = ["block_b_update_backups", "block_b_update_files", "a30_update_backups", "middle_update_backups",
              "ungueltig_A30_A35", "abgebrochen_B_cpitzschel", "middle_update_v2.zip", "a30_update.zip",
              "blockb_update.zip", "pwmsplit_update_backups", "pwmsplit_update.zip", "folgelaeufe.zip",
              "blockc_update_backups", "blockc_update.zip", "blockA_A41_A42.zip", "kernel_3_5.zip",
              "kernel_3_5_A37_A38.zip", "pwm_3_5_A39_A40.zip", "splitcheck_update_backups",
              "splitcheck_update.zip", "a36_umbenennung_backup"]
PACKAGES_BESIDE = {"blockb_update": "install_block_b_update.pyz", "a30_update": "install_a30_update.py",
                   "middle_update": "install_middle_update.py", "pwmsplit_update": "install_pwmsplit_update.pyz",
                   "blockc_update": "install_blockc_update.pyz",
                   "splitcheck_update": "install_splitcheck_update.pyz"}
LATER = ["extend_to_middle.py", "migrate_short_to_middle.py", "install_middle_update.py", "install_a30_update.py",
         "install_block_b_update.py", "submit_middle.sh", "submit_block_b.sh", "configs/conda_root.txt",
         "certified_code", "blockb_update", "a30_update", "middle_update", "pwmsplit_update", "blockc_update",
         "splitcheck_update"]
TESTS = {"make_synthetic_project.py", "test_equivalence.py", "test_features.py", "test_block_b.py",
         "test_a30_compat.py", "test_certified_code.py", "compare_predictors.py", "compare_runs.py",
         "certified_snippet.py", "reference_a30", "__pycache__"}


def git(*arguments):
    try:
        return subprocess.run(["git", "-C", str(root), *arguments], capture_output=True, text=True, timeout=300)
    except (OSError, subprocess.SubprocessError):
        return None


top = git("rev-parse", "--show-toplevel")
repo = Path(top.stdout.strip()).resolve() if top is not None and top.returncode == 0 else None


def tracked(path):
    if repo is None:
        return False
    result = git("ls-files", "-z", "--", str(path))
    return bool(result is not None and result.stdout)


def locally_changed(path):
    result = git("status", "--porcelain", "--", str(path)) if repo is not None else None
    return bool(result is not None and any("M" in line[:2] for line in result.stdout.splitlines()))


def size(path):
    total = 0
    if path.is_file() and not path.is_symlink():
        return path.stat().st_size
    for directory, _, files in os.walk(path):
        for name in files:
            try:
                total += os.lstat(os.path.join(directory, name)).st_size
            except OSError:
                pass
    return total


def human(count):
    for unit in ("B", "KB", "MB", "GB"):
        if count < 1024 or unit == "GB":
            return f"{count:.0f} {unit}" if unit == "B" else f"{count:.1f} {unit}"
        count /= 1024


def label(path):
    try:
        return str(path.relative_to(root))
    except ValueError:
        return "../" + str(path.relative_to(parent))


CLEANUP_JOB = "h301_aufraeumen"


def project_jobs():
    """Jobs aller Konten (soweit squeue sie zeigt) mit diesem Projekt als Arbeitsordner: Liste von
    (Job-ID, Name, Konto, Partition) ohne diesen Aufräum-Job selbst; None = Queue nicht abfragbar."""
    if not shutil.which("squeue"):
        return None
    try:
        result = subprocess.run(["squeue", "--noheader", "--format=%i|%j|%Z|%u|%P"],
                                capture_output=True, text=True, timeout=120)
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode:
        return None
    jobs = []
    for line in result.stdout.splitlines():
        fields = [field.strip() for field in line.split("|", 4)]
        if len(fields) == 5 and fields[2] and Path(os.path.realpath(fields[2])) == root:
            job_id = fields[0].split("_", 1)[0]
            if job_id != own_job:
                jobs.append((job_id, fields[1], fields[3], fields[4]))
    return jobs


def plan_ids(directory):
    try:
        state = json.loads((directory / "submission.json").read_text())
    except (OSError, ValueError):
        return set()
    ids = set()
    if isinstance(state, dict):
        if state.get("array_id") is not None:
            ids.add(str(state["array_id"]))
        ids |= {str(value) for value in (state.get("collectors") or {}).values()}
    return ids


# ---------------------------------------------------------------- Bestandsaufnahme
all_jobs = project_jobs()
scheduled = [j for j in all_jobs if j[1] == CLEANUP_JOB] if all_jobs is not None else []
jobs = [j for j in all_jobs if j[1] != CLEANUP_JOB] if all_jobs is not None else None
active = {job[0] for job in jobs} if jobs is not None else set()

if schedule:
    if jobs is None:
        sys.exit("Abgebrochen: squeue nicht abfragbar; ohne Queue lässt sich nichts einplanen.")
    if scheduled:
        sys.exit(f"Schon eingeplant als Job {scheduled[0][0]} (abbrechen mit: scancel {scheduled[0][0]}).")
    if not jobs:
        print("Es läuft nichts mehr in diesem Projekt – gleich ausführen: bash aufraeumen.sh --apply")
        sys.exit(0)
    ids = sorted({job[0] for job in jobs}, key=lambda x: int(x) if x.isdigit() else 0)
    partition = next((j[3] for j in jobs if j[1].startswith("h301_collect_")), None) or jobs[0][3]
    log = Path.home() / "aufraeumen_%j.out"
    extra = {"AUFRAEUMEN_ALS_JOB": "1", "AUFRAEUMEN_ROOT": str(root), "AUFRAEUMEN_WARTET_AUF": ":".join(ids),
             "ABLATION_PYTHON": sys.executable}
    command = ["sbatch", "--parsable", f"--job-name={CLEANUP_JOB}", f"--dependency=afterany:{':'.join(ids)}",
               f"--chdir={root}", f"--output={log}", "--time=01:00:00", "--ntasks=1", "--cpus-per-task=1",
               "--mem=2G", "--export=ALL," + ",".join(f"{k}={v}" for k, v in extra.items())]
    if partition:
        command.append(f"--partition={partition}")
    command += [str(root / "aufraeumen.sh"), "--apply"]
    result = subprocess.run(command, capture_output=True, text=True, env=dict(os.environ, **extra))
    if result.returncode:
        sys.exit("sbatch fehlgeschlagen: " + (result.stderr.strip() or result.stdout.strip()))
    job_id = result.stdout.strip().split(";")[0]
    print(f"Aufräumen eingeplant als Job {job_id} (Partition {partition or 'Standard'}).")
    print(f"Startet, sobald diese Jobs beendet sind: {', '.join(ids)}")
    print(f"Protokoll danach: {Path.home()}/aufraeumen_{job_id}.out   Abbrechen: scancel {job_id}")
    sys.exit(0)

# Im eingeplanten Job: Endeten alle Jobs, auf die er gewartet hat, mit COMPLETED?
incomplete = None
if waited:
    states = {}
    try:
        result = subprocess.run(["sacct", "-n", "-P", "-X", "-j", ",".join(waited), "--format=JobID,State"],
                                capture_output=True, text=True, timeout=300)
        if result.returncode:
            states = None
        else:
            for line in result.stdout.splitlines():
                job, _, state = line.partition("|")
                base = job.split("_", 1)[0].split(".", 1)[0]
                word = (state.split() or ["?"])[0]
                states.setdefault(base, {}).setdefault(word, 0)
                states[base][word] += 1
    except (OSError, subprocess.SubprocessError):
        states = None
    if states is None:
        incomplete = "Ende der Jobs nicht prüfbar (sacct nicht abfragbar)"
    else:
        problems = []
        for job_id in waited:
            counts = states.get(job_id)
            if not counts:
                problems.append(f"{job_id}: nicht in sacct")
            elif set(counts) != {"COMPLETED"}:
                problems.append(f"{job_id}: " + ", ".join(f"{n} {s}" for s, n in sorted(counts.items())))
        if problems:
            incomplete = "nicht alle Jobs endeten mit COMPLETED – " + "; ".join(problems)
now, later, notes, unknown = [], [], [], []

for name in NOW:
    path = root / name
    if path.exists() or path.is_symlink() or tracked(path):
        now.append(path)
for name in NOW_BESIDE:
    path = parent / name
    if path.exists() or tracked(path):
        now.append(path)
for name, marker in PACKAGES_BESIDE.items():
    path = parent / name
    if (path / marker).exists():
        now.append(path)
for path in sorted(root.glob("slurm-*.out")):
    now.append(path)

plans = root / "plans"
plan_dirs = sorted(p for p in plans.iterdir() if p.is_dir()) if plans.is_dir() else []
if jobs is None:
    notes.append("squeue nicht abfragbar: Pläne in plans/ und Teil 2 bleiben unangetastet.")
else:
    mapped = {p: plan_ids(p) for p in plan_dirs}
    unmapped = active - set().union(set(), *mapped.values())
    if unmapped:
        notes.append("Aktive Jobs ohne Zuordnung zu einem Plan (" + ", ".join(sorted(unmapped))
                     + "): plans/ bleibt vorsichtshalber unangetastet.")
    else:
        for path, ids in mapped.items():
            if ids & active:
                continue
            if incomplete and ids & set(waited):
                notes.append(f"{label(path)} bleibt (Logs zur Fehlersuche).")
                continue
            now.append(path)
        if (plans / "active_batch.json").exists():
            now.append(plans / "active_batch.json")
        for path in sorted(plans.iterdir()) if plans.is_dir() else []:
            if path.is_file() and path.name not in (".dispatcher.lock", "active_batch.json"):
                unknown.append(path)

for name in LATER:
    path = root / name
    if path.exists() or tracked(path):
        later.append(path)
tests = root / "tests"
leftover_tests = []
if tests.is_dir() or tracked(tests):
    for path in sorted(tests.iterdir()) if tests.is_dir() else []:
        (later if path.name in TESTS else leftover_tests).append(path)
    if not leftover_tests:
        later.append(tests)
removed_modules = {p.stem for p in later if p.suffix == ".py" and p.parent == root}
for path in sorted((root / "__pycache__").glob("*.pyc")) if (root / "__pycache__").is_dir() else []:
    if path.name.split(".")[0] in removed_modules:
        later.append(path)
later.append(root / "aufraeumen.sh")

listed = {p.name for p in now + later if p.parent == root} | {"tests"}
for path in sorted(root.iterdir()):
    if path.name not in KEEP and path.name not in listed and not path.name.startswith(".git"):
        unknown.append(path)
unknown += leftover_tests

# ---------------------------------------------------------------- Bericht
print(f"Projekt: {root}")
print("git: " + (f"Repository {repo}" if repo else "kein Repository – es wird nur gelöscht"))
state = {n: hashlib.sha256((root / n).read_bytes()).hexdigest()[:12] if (root / n).is_file() else "fehlt"
         for n in PROGRAM}
bad = [f"{n} ({h})" for n, h in state.items() if h not in PROGRAM[n]]
print("Programmdateien: " + (("Block-C-Stand" + (" mit Split-Prüfsummen" if state["data.py"] == "65a3a303e2a4" else "")
                               if state["model.py"] == "038cc63bc9b1" else "Block-B-Stand"
                              + (" mit PWM-Split-Update" if state["data.py"] == "bab35d9093c9" else ""))
                             if not bad else "ABWEICHUNG – " + ", ".join(bad)))
if jobs:
    print("Laufende/wartende Jobs dieses Projekts: "
          + ", ".join(f"{i} ({n}, {u})" for i, n, u, _ in sorted(set(jobs))))
elif jobs is not None:
    print("Laufende/wartende Jobs dieses Projekts: keine")
if scheduled:
    print(f"Aufräumen ist als Job {scheduled[0][0]} eingeplant (wartet auf das Ende der Jobs).")
if as_job:
    print(f"Eingeplanter Aufräum-Job {own_job}; gewartet auf: {', '.join(waited) or '–'}")
    print("Ende der Jobs: " + (incomplete or "alle mit COMPLETED"))


def show(title, paths):
    print(f"\n{title}")
    if not paths:
        print("  – nichts –")
    for path in paths:
        mark = []
        if tracked(path):
            mark.append("git")
            if locally_changed(path):
                mark.append("lokal geändert")
        if not path.exists() and not path.is_symlink():
            mark.append("nur noch in git")
        else:
            mark.append(human(size(path)))
        print(f"  - {label(path)}" + (f"  [{', '.join(mark)}]" if mark else ""))


later_allowed = jobs is not None and not jobs and not incomplete
if incomplete:
    notes.append("Teil 2 bleibt aus: Die Hilfsscripte bleiben, damit ein --restart der betroffenen Runs ohne "
                 "Sonderschalter klappt. Danach erneut: bash aufraeumen.sh --apply")
show("Teil 1 – wird jetzt gelöscht (ohne Einfluss auf laufende Jobs):", now)
show("Teil 2 – " + ("wird jetzt gelöscht (es läuft nichts mehr):" if later_allowed else
                    "wird jetzt nicht gelöscht (Grund unten):" if incomplete else
                    "wird erst gelöscht, wenn kein Job dieses Projekts mehr läuft:"), later)
if unknown:
    show("Nicht angefasst (unbekannt – bei Bedarf selbst entscheiden):", unknown)
for note in notes:
    print("\nHinweis: " + note)
print("\nHinweis: Jobs anderer Konten erkennt das Script nur, wenn squeue sie anzeigt.")
if later_allowed:
    print("Nach Teil 2 ist der Code-Stand neu: Ein späteres --restart bestehender Experimente braucht einmal "
          "ABLATION_ALLOW_CODE_VERSION_MISMATCH=1.")

if repo is None and shutil.which("git") is None and (root / ".." / ".." / ".git").exists():
    print("Hinweis: git ist hier nicht verfügbar; Löschungen später mit git commit -a festhalten.")
if not apply:
    print("\nNur angezeigt; nichts gelöscht. Ausführen: bash aufraeumen.sh --apply"
          "  (oder automatisch nach den Jobs: bash aufraeumen.sh --nach-jobs)")
    sys.exit(0)

# ---------------------------------------------------------------- Ausführen
errors, in_git = [], []


def report(function, failed, info):
    error = info[1] if isinstance(info, tuple) else info
    reason = getattr(error, "strerror", None) or str(error)
    try:
        errors.append(f"{label(Path(failed))}: {reason}")
    except ValueError:
        errors.append(f"{failed}: {reason}")


def remove(path):
    if tracked(path):
        result = git("rm", "-r", "-f", "-q", "--", str(path))
        if result is None or result.returncode:
            errors.append(f"git rm {label(path)}: " + (result.stderr.strip() if result else "git fehlt"))
        else:
            in_git.append(path)
    if path.is_symlink() or path.is_file():
        try:
            path.unlink()
        except OSError as error:
            errors.append(f"{label(path)}: {error.strerror or error}")
    elif path.is_dir():
        if sys.version_info >= (3, 12):
            shutil.rmtree(path, onexc=report)
        else:
            shutil.rmtree(path, onerror=report)


for path in now:
    remove(path)
done_later = False
self_script = root / "aufraeumen.sh"
if later_allowed:
    for path in later:
        if path != self_script:
            remove(path)
    done_later = True
    if not errors:  # bei Fehlern bleibt das Script für einen zweiten Durchlauf liegen
        remove(self_script)

if in_git and repo is not None:
    message = ("big_ablation aufgeräumt: Paketreste, Sicherungen, alte Pläne"
               + (", alte Hilfsscripte" if done_later else ""))
    relative = sorted({os.path.relpath(p, repo) for p in in_git})
    result = subprocess.run(["git", "-C", str(repo), "commit", "-q", "-m", message, "--", *relative],
                            capture_output=True, text=True)
    if result.returncode:
        errors.append("git commit: " + (result.stderr.strip() or result.stdout.strip()))
    else:
        count = f"{len(relative)} Pfad" + ("" if len(relative) == 1 else "e")
        print(f"\ngit: Commit „{message}“ angelegt ({count}). Hochladen mit: git push")

if not done_later:
    print("\nTeil 1 erledigt. Teil 2 folgt: " + ("nach der Fehlersuche bzw. dem --restart " if incomplete else
          "nach dem Ende aller Jobs ") + "erneut bash aufraeumen.sh --apply (oder --nach-jobs).")
elif not errors:
    print("\nTeil 1 und 2 erledigt; dieses Script hat sich mit gelöscht.")
else:
    print("\nTeil 1 und 2 erledigt bis auf die Punkte unten; das Script bleibt für einen zweiten Durchlauf liegen.")
if errors:
    print("\nNicht gelöscht (meist fehlende Rechte, etwa bei Dateien eines anderen Kontos):")
    for error in errors[:40]:
        print("  - " + error)
    if len(errors) > 40:
        print(f"  … und {len(errors) - 40} weitere")
    sys.exit(1)
PY
