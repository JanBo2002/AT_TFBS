#!/usr/bin/env bash
# Version: 2026-11-13-a36-umplanen-1
#
# Plant A36 auf 30 TFs x 3 Splits neu, ohne den Original-Split noch einmal zu rechnen:
#   * results/A36_A14_plus_A32_middle (21 TFs) wird zu A36_A14_plus_A32_30TF umbenannt – Ordner und
#     Metadaten der Läufe, wie beim Short->Middle-Umzug. Die Middle-Config geht in die Sicherung.
#   * Das wartende A36-Array und seine Sammeljobs werden abgebrochen und mit submit_array.sh --restart
#     neu eingereicht: nur die fehlenden TFs auf dem Original-Split sowie split_v2 und split_v3.
#     Das neue Array startet nach allen bisherigen Arrays (auch Block C).
#   * Ein eingeplantes Aufräumen (h301_aufraeumen) wird danach neu eingeplant.
#
#   bash a36_umplanen.sh            # nur prüfen und anzeigen, nichts ändern
#   bash a36_umplanen.sh --apply    # ausführen
# Optional: --target=/pfad/zu/big_ablation (Standard: big_ablation neben dem Paketordner),
#           --account=NAME (wird an submit_array.sh durchgereicht)
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -n "${SLURM_JOB_ID:-}" ]]; then
    echo "Abgebrochen: auf dem Login-Knoten starten, nicht in einem Slurm-Job." >&2
    exit 1
fi
PY="${ABLATION_PYTHON:-$(command -v python3)}"
exec "$PY" - "$HERE" "$@" <<'PY'
import csv, fcntl, hashlib, itertools, json, os, re, shutil, subprocess, sys, tempfile, time
from datetime import datetime
from pathlib import Path

here, options = Path(sys.argv[1]), sys.argv[2:]
bad = [o for o in options if o != "--apply" and not o.startswith(("--target=", "--account="))]
if bad:
    sys.exit(f"Unbekannte Option: {bad[0]}  (Aufruf: bash a36_umplanen.sh [--apply] [--target=PFAD] [--account=NAME])")
apply = "--apply" in options
targets = [o.split("=", 1)[1] for o in options if o.startswith("--target=")]
account = [o for o in options if o.startswith("--account=")]
root = Path(targets[0]).expanduser().resolve() if targets else (here.parent / "big_ablation").resolve()
SRC, DST = "A36_A14_plus_A32_middle", "A36_A14_plus_A32_30TF"
ALL = [DST, DST + "_split_v2", DST + "_split_v3"]
DATA_SPLITCHECK = "65a3a303e2a4"
SELECTION = {"description", "seeds", "train_assays", "test_assays", "tfs", "task_profile"}
ASSAY_DIR = {"CHIP": "train_CHIP", "GHTS": "train_GHTS"}
RUN_JSON = ("run.json", "config.json", "training/configuration.json", "training/prediction_metadata.json")


def fail(message):
    print("Abgebrochen: " + message, file=sys.stderr)
    sys.exit(1)


def json_text(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def recipe(config):
    """Entspricht training.recipe_digest."""
    return hashlib.sha256(json_text({k: v for k, v in config.items() if k not in SELECTION}).encode()).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def certified_code_hashes():
    """Wie training.certified_code_hashes: alle als gleichwertig zertifizierten Code-Stände."""
    files = []
    for path in sorted(root.rglob("*.py")):
        if "results" in path.relative_to(root).parts or "__pycache__" in path.parts:
            continue
        files.append((str(path.relative_to(root)), path.read_bytes()))
    contents = dict(files)

    def digest(replacements):
        result = hashlib.sha256()
        for name, data in files:
            result.update(name.encode())
            result.update(replacements.get(name, data))
        return result.hexdigest()

    hashes = {digest({})}
    directory = root / "certified_code"
    for manifest_path in sorted(directory.glob("*.json")) if directory.is_dir() else []:
        try:
            manifest = json.loads(manifest_path.read_text())
            choices = []
            for name, spec in sorted(manifest["files"].items()):
                if name not in contents or hashlib.sha256(contents[name]).hexdigest() != spec["sha256"]:
                    continue
                variants = [contents[name]]
                for earlier in spec.get("equivalent", []):
                    data = (directory / earlier["ref"]).read_bytes()
                    if hashlib.sha256(data).hexdigest() == earlier["sha256"]:
                        variants.append(data)
                choices.append((name, variants))
        except (OSError, ValueError, KeyError, TypeError):
            continue
        for combination in itertools.product(*[variants for _, variants in choices]):
            hashes.add(digest({name: data for (name, _), data in zip(choices, combination)}))
    return hashes


def pairs(filename):
    with (root / "configs" / filename).open(newline="") as handle:
        return [(row["tf"], {"CHS": "CHIP"}.get(row["assay"], row["assay"])) for row in csv.DictReader(handle)]


def run_completed(run_dir, test_assays):
    try:
        meta = json.loads((run_dir / "run.json").read_text())
    except (OSError, ValueError):
        return None
    if meta.get("status") != "completed" or not (run_dir / "records.jsonl").is_file():
        return None
    for assay in test_assays:
        evaluation = run_dir / "evaluations" / "standard" / assay
        try:
            metrics = json.loads((evaluation / "metrics.json").read_text())
        except (OSError, ValueError):
            return None
        if metrics.get("status") != "completed" or not (evaluation / "predictions.tsv").is_file():
            return None
    return meta


def queue():
    """(Job-ID, Name, Zustand) aller eigenen Jobs dieses Projekts."""
    result = subprocess.run(["squeue", "--me", "--noheader", "--format=%i|%j|%Z|%T"],
                            capture_output=True, text=True, timeout=120)
    if result.returncode:
        fail("squeue fehlgeschlagen: " + (result.stderr.strip() or result.stdout.strip()))
    jobs = []
    for line in result.stdout.splitlines():
        fields = [field.strip() for field in line.split("|", 3)]
        if len(fields) == 4 and fields[2] and Path(os.path.realpath(fields[2])) == root:
            jobs.append((fields[0].split("_", 1)[0], fields[1], fields[3]))
    return jobs


def owners():
    result = {}
    for path in (root / "plans").glob("*/submission.json"):
        try:
            state = json.loads(path.read_text())
        except (OSError, ValueError):
            continue
        if isinstance(state, dict) and state.get("array_id") is not None:
            result[str(state["array_id"])] = set(state.get("requested_configs") or state.get("configs") or [])
    return result


def rewrite(value, old_prefix, new_prefix):
    """Ersetzt den alten Ergebnispfad und den alten Namen in allen Zeichenketten eines JSON-Dokuments."""
    if isinstance(value, str):
        if value == SRC:
            return DST
        return re.sub(re.escape(old_prefix) + r"(?=/|$)", new_prefix, value)
    if isinstance(value, list):
        return [rewrite(item, old_prefix, new_prefix) for item in value]
    if isinstance(value, dict):
        return {key: rewrite(item, old_prefix, new_prefix) for key, item in value.items()}
    return value


def atomic_write(path, text):
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    os.close(fd)
    try:
        Path(temporary).write_text(text)
        shutil.copymode(path, temporary) if path.exists() else None
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


# ---------------------------------------------------------------- Prüfungen (beide Modi)
if not (root / "submit_array.sh").is_file() or not (root / "configs" / "caches.csv").is_file():
    fail(f"{root} sieht nicht wie big_ablation aus (Ziel mit --target=PFAD angeben).")
if sha(root / "data.py")[:12] != DATA_SPLITCHECK:
    fail("data.py ist nicht im Stand mit Split-Prüfsummen – zuerst install_splitcheck_update.pyz ausführen.")
if not (root / "configs" / f"{SRC}.json").is_file() and (root / "results" / DST).is_dir():
    print(f"A36 ist bereits umgeplant: results/{DST} enthält die Middle-Läufe. Nichts zu tun.")
    sys.exit(0)
configs = {}
for name in [SRC] + ALL:
    path = root / "configs" / f"{name}.json"
    if not path.is_file():
        fail(f"Config fehlt: configs/{name}.json")
    configs[name] = json.loads(path.read_text())
source, target = configs[SRC], configs[DST]
if recipe(dict(source, name=DST)) != recipe(target):
    fail(f"{DST} hat ein anderes Modell-/Trainingsrezept als {SRC}; Umbenennen wäre falsch.")
experiment, destination = root / "results" / SRC, root / "results" / DST
if not experiment.is_dir() or experiment.is_symlink():
    fail(f"results/{SRC} fehlt (oder ist ein Link).")
if destination.exists():
    fail(f"results/{DST} existiert schon – A36 auf dem Original-Split wurde bereits begonnen.")
stored = json.loads((experiment / "config.json").read_text())
if recipe(stored) != recipe(source):
    fail(f"results/{SRC}/config.json passt nicht zu configs/{SRC}.json.")

middle, long = pairs("training_priority_middle.csv"), pairs("training_priority.csv")
if not set(middle) <= set(long):
    fail("Die Middle-TFs sind nicht vollständig in der 30-TF-Liste enthalten.")
seeds = [int(seed) for seed in source["seeds"]]
done, metas = [], []
for tf, assay in middle:
    if assay not in source["train_assays"]:
        continue
    for seed in seeds:
        meta = run_completed(experiment / "runs" / tf / ASSAY_DIR[assay] / f"seed_{seed:02d}", source["test_assays"])
        if meta is not None:
            done.append((tf, assay, seed))
            metas.append(meta)
expected_middle = sum(1 for _, assay in middle if assay in source["train_assays"]) * len(seeds)
expected_long = sum(1 for _, assay in long if assay in target["train_assays"]) * len(target["seeds"])
foreign = {m.get("code_hash") for m in metas} - certified_code_hashes()
if foreign:
    fail(f"{len(foreign)} Code-Stand/-Stände der Middle-Läufe sind nicht mehr als gleichwertig zertifiziert; "
         "die Läufe ließen sich nicht mit neuen zusammenfassen. Dann A36 vollständig neu einreichen: "
         "bash submit_array.sh --restart " + " ".join(ALL))
if {recipe(m["config"]) if isinstance(m.get("config"), dict) else None for m in metas} - {recipe(source)}:
    fail(f"Läufe in results/{SRC} stammen aus einem anderen Rezept.")

jobs, owned = queue(), owners()
a36_jobs, busy = [], []
for job, name, state in jobs:
    configs_of_job = owned.get(job, set())
    if name.startswith("h301_collect_"):
        configs_of_job = {name[len("h301_collect_"):]}
    elif name.startswith(("h301_array_", "hum301_array")) and job not in owned:
        fail(f"Array {job} ({name}) ohne Config-Zuordnung in plans/*/submission.json.")
    if SRC in configs_of_job:
        busy.append(f"{job} ({name})")
    if configs_of_job & set(ALL):
        if not configs_of_job <= set(ALL):
            fail(f"Job {job} enthält außer A36 weitere Configs ({', '.join(sorted(configs_of_job - set(ALL)))}).")
        if state not in ("PENDING", "PD"):
            fail(f"Job {job} ({name}) ist schon im Zustand {state} – A36 hat bereits begonnen.")
        a36_jobs.append(job)
a36_jobs = sorted(set(a36_jobs), key=int)
if busy:
    fail(f"Für {SRC} sind noch Jobs aktiv: {', '.join(busy)}.")
others = sorted({job for job, name, _ in jobs if job not in a36_jobs and name != "h301_aufraeumen"}, key=int)
cleanup = sorted({job for job, name, _ in jobs if name == "h301_aufraeumen"}, key=int)

missing_orig = expected_long - len(done)
v_runs = [sum(1 for _, assay in long if assay in configs[n]["train_assays"]) * len(configs[n]["seeds"]) for n in ALL[1:]]
print(f"Projekt: {root}")
print(f"Original-Split: {SRC} hat {len(done)} von {expected_middle} Läufen fertig "
      f"({len({tf for tf, _, _ in done})} TFs); wird zu {DST} umbenannt.")
print(f"  Danach fehlen auf dem Original-Split {missing_orig} von {expected_long} Läufen "
      f"(TFs außerhalb des Middle-Profils{' und unfertige Middle-Läufe' if len(done) < expected_middle else ''}).")
print(f"split_v2/split_v3: {v_runs[0]} + {v_runs[1]} Läufe.")
print(f"Neues Array: {missing_orig + sum(v_runs)} Aufgaben statt {expected_long + sum(v_runs)}; "
      f"es wartet auf {', '.join(others) if others else 'nichts'}.")
print("Abgebrochen werden: " + (", ".join(a36_jobs) if a36_jobs else "nichts (kein A36-Job in der Warteschlange)"))
if cleanup:
    print(f"Aufräumen {', '.join(cleanup)} wird danach neu eingeplant.")
if not apply:
    print("\nNur angezeigt. Ausführen: bash " + str(here / "a36_umplanen.sh") + " --apply")
    sys.exit(0)

# ---------------------------------------------------------------- Ausführen
env = dict(os.environ)
print("\nVorprüfung: Split-Caches und Aufgabenplan ...", flush=True)
check = subprocess.run([sys.executable, str(root / "data.py"), "prepare-splits", "--manifest",
                        str(root / "configs" / "caches.csv"), "--variants", "split_v2", "split_v3",
                        "--report", str(root / "plans" / "split_preparation.json")], cwd=root, env=env)
if check.returncode:
    fail("Split-Vorbereitung fehlgeschlagen; nichts verändert.")
with tempfile.TemporaryDirectory() as temporary:
    plan = subprocess.run([sys.executable, str(root / "run_experiment.py"), "plan", "--config", *ALL,
                           "--manifest", str(root / "configs" / "caches.csv"), "--output", str(Path(temporary) / "p.csv")],
                          cwd=root, env=env, capture_output=True, text=True)
    if plan.returncode:
        fail("Aufgabenplan nicht erstellbar; nichts verändert:\n" + (plan.stderr or plan.stdout)[-2000:])

backup = root.parent / "a36_umbenennung_backup" / datetime.now().strftime("%Y%m%d_%H%M%S")
with (root / "plans" / ".dispatcher.lock").open("a") as lock:
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        fail("submit_array.sh läuft gerade in diesem Projekt; später erneut versuchen.")
    if a36_jobs:
        subprocess.run(["scancel", *a36_jobs], check=False)
        deadline = time.monotonic() + 120
        while {job for job, _, _ in queue()} & set(a36_jobs):
            if time.monotonic() > deadline:
                fail("Die A36-Jobs sind noch nicht beendet; nichts umbenannt. Später erneut --apply.")
            time.sleep(2)
        print("A36-Jobs abgebrochen: " + ", ".join(a36_jobs))
    backup.mkdir(parents=True)
    old_prefix, new_prefix = str(experiment), str(destination)
    new_hash = recipe(target)
    for run_json in sorted(experiment.glob("runs/*/*/*/run.json")):
        run_dir = run_json.parent
        files = [run_dir / name for name in RUN_JSON] + sorted(run_dir.glob("evaluations/*/*/metrics.json"))
        for path in [p for p in files if p.is_file()] + [run_dir / "records.jsonl"]:
            if not path.is_file():
                continue
            copy = backup / "results" / path.relative_to(root / "results")
            copy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, copy)
            if path.name == "records.jsonl":
                rows = []
                for line in path.read_text().splitlines():
                    if line.strip():
                        row = rewrite(json.loads(line), old_prefix, new_prefix)
                        if "config_hash" in row:
                            row["config_hash"] = new_hash
                        rows.append(json.dumps(row, allow_nan=False, default=str))
                atomic_write(path, "".join(row + "\n" for row in rows))
                continue
            document = rewrite(json.loads(path.read_text()), old_prefix, new_prefix)
            if path.name == "run.json":
                document["config_hash"] = new_hash
                if isinstance(document.get("config"), dict):
                    document["config"].update(task_profile=target.get("task_profile"),
                                              description=target.get("description"))
            elif path.name == "config.json" and path.parent == run_dir:
                document.update(task_profile=target.get("task_profile"), description=target.get("description"))
            atomic_write(path, json.dumps(document, indent=2) + "\n")
    shutil.copy2(experiment / "config.json", backup / f"{SRC}.results.config.json")
    atomic_write(experiment / "config.json", json.dumps(target, indent=2) + "\n")
    os.rename(experiment, destination)
    summary = root / "results" / "Results_all" / f"{SRC}.csv"
    if summary.is_file():
        (backup / "Results_all").mkdir(exist_ok=True)
        shutil.move(str(summary), str(backup / "Results_all" / summary.name))
    (backup / "configs").mkdir(exist_ok=True)
    shutil.copy2(root / "configs" / f"{SRC}.json", backup / "configs" / f"{SRC}.json")
    for path in sorted((root / "configs").glob("*.json")):
        try:
            other = json.loads(path.read_text())
        except ValueError:
            continue
        if isinstance(other, dict) and other.get("reference") == SRC and path.stem != SRC:
            shutil.copy2(path, backup / "configs" / path.name)
            atomic_write(path, json.dumps(dict(other, reference=DST), indent=2) + "\n")
            print(f"Referenz angepasst: configs/{path.name}")
    (root / "configs" / f"{SRC}.json").unlink()
print(f"Umbenannt: results/{SRC} -> results/{DST} ({len(done)} Läufe). Sicherung: {backup}")

command = ["bash", str(root / "submit_array.sh"), "--restart", *ALL, *account]
print("\n" + " ".join(command[1:]), flush=True)
submitted = subprocess.run(command, cwd=root, env=env)
if submitted.returncode:
    fail("Einreichen fehlgeschlagen. Die Umbenennung bleibt; nach der Fehlerbehebung erneut einreichen mit:\n  "
         f"cd {root} && bash submit_array.sh --restart {' '.join(ALL)}"
         + ("\n  danach: scancel -u $USER -n h301_aufraeumen; bash aufraeumen.sh --nach-jobs" if cleanup else ""))
if cleanup:
    subprocess.run(["scancel", *cleanup], check=False)
    time.sleep(2)
    subprocess.run(["bash", str(root / "aufraeumen.sh"), "--nach-jobs"], cwd=root, env=env)
PY
