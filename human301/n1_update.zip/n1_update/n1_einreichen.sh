#!/usr/bin/env bash
# N1: Caches mit random, aliens und shades bauen, dann N1E (01 nachbewerten) und N1 (Training) vor alle
# anderen wartenden Arrays stellen.
#
#   bash n1_update/n1_einreichen.sh [--nur-pruefen] [--genom=/pfad/hg38.fa] [--ueberlappende-weglassen] [--account=NAME]
#
# Auf dem Login-Knoten, in at_env, nach dem Installer. Was passiert:
#   1. Prüfung (Login-Knoten, wenige Minuten): Für jede der 21 Middle-TFs, beide Assays, Train und Test wird der
#      Ordner gesucht, dessen Positive exakt die des Caches sind; daneben liegende aliens/shades werden genommen
#      (sonst die Ergänzung). Koordinaten, Chromosomen-Trennung, Überlappungen und Lage der shades werden geprüft.
#      Bei einem Problem endet das Script hier, ohne etwas einzureichen. --nur-pruefen: nur diese Prüfung.
#      --ueberlappende-weglassen: neue Negative, die ein Positives überlappen, weglassen (im Cache vermerkt)
#      statt abzubrechen.
#   2. Ein CPU-Job baut die 42 Caches mit Negativtypen (je TF/Assay neben dem bisherigen Cache unter
#      negatives/ras/; die bisherigen Caches bleiben unverändert).
#   3. submit_array.sh reicht N1E und N1 als ein Array ein (N1E zuerst: die Brücke b) ist schnell da). Das Array
#      wartet danach nur auf den Cache-Job (afterok); alle anderen wartenden Arrays
#      dieses Projekts (Arbeitsordner big_ablation) bekommen Nice 100000 und werden, falls angehalten, wieder
#      freigegeben. Laufende Tasks
#      laufen normal zu Ende.
#   4. Das Aufräumen wird neu eingeplant, damit es auch auf N1 wartet.
# Rückgängig (andere Arrays wieder normal priorisieren): scontrol update JobId=<Array> Nice=0
set -euo pipefail
HIER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
H301="$(cd "$HIER/.." && pwd)"
BA="$H301/big_ablation"
LOGS="$H301/n1_auswertung/logs"
N1E=N1E_01_eval_aliens_shades_middle
N1=N1_01_aliens_shades_middle
HANDOFF="${N1_HANDOFF:-/data/projects/SFB_A03/jan/AT_TFBS/raw_data/clara/chip/student_handoff_30tf_increment/Input_data}"
ARCHTHALIA="${N1_ARCHTHALIA:-/data/projects/SFB_A03/clara/ArchThalia-ML}"
ERGAENZUNG="${N1_ERGAENZUNG:-/data/projects/SFB_A03/jan/AT_TFBS/raw_data/archipelago_ergaenzung}"
NUR_PRUEFEN=0
WEGLASSEN=()
GENOM=()
ACCOUNT=()
for arg in "$@"; do
    case "$arg" in
        --nur-pruefen) NUR_PRUEFEN=1 ;;
        --genom=?*) GENOM=(--genome-fasta "${arg#--genom=}") ;;
        --ueberlappende-weglassen) WEGLASSEN=(--drop-overlaps) ;;
        --account=?*) ACCOUNT=("$arg") ;;
        *) echo "Unbekannte Option: $arg (Aufruf: bash n1_einreichen.sh [--nur-pruefen] [--genom=PFAD]" \
                "[--ueberlappende-weglassen] [--account=NAME])" >&2
           exit 2 ;;
    esac
done
PY="${CONDA_PREFIX:+$CONDA_PREFIX/bin/python}"
PY="${PY:-$(command -v python3)}"

echo "== Prüfen"
for exe in sbatch squeue scontrol scancel; do
    command -v "$exe" >/dev/null || { echo "Abgebrochen: $exe fehlt (Login-Knoten?)" >&2; exit 1; }
done
"$PY" -c "import torch, scipy, sklearn" 2>/dev/null \
    || { echo "Abgebrochen: $PY ohne torch/scipy/sklearn – zuerst at_env aktivieren." >&2; exit 1; }
for name in "$N1E" "$N1"; do
    [ -f "$BA/configs/$name.json" ] || { echo "Abgebrochen: configs/$name.json fehlt – zuerst den Installer ausführen." >&2; exit 1; }
    [ -e "$BA/results/$name" ] && { echo "Abgebrochen: results/$name existiert schon (schon eingereicht?)." >&2; exit 1; }
done
grep -q "prepare-negatives" "$BA/data.py" || { echo "Abgebrochen: data.py ohne prepare-negatives – Installer zuerst." >&2; exit 1; }
# squeue-Ausgabe erst einlesen: grep -q in einer Pipe kann squeue mit SIGPIPE beenden (pipefail)
NAMEN="$(squeue --me -h -o "%j")" || { echo "Abgebrochen: squeue nicht abfragbar." >&2; exit 1; }
if grep -qx "h301_n1_caches" <<< "$NAMEN"; then
    echo "Abgebrochen: Der Cache-Job h301_n1_caches steht schon in der Queue." >&2; exit 1
fi
mkdir -p "$LOGS"
BA_ECHT="$(cd "$BA" && pwd -P)"
MISCHUNG="$("$PY" -c 'import json, sys; m = json.load(open(sys.argv[1]))["fitting"]["params"]["negative_mix"]; print(",".join(f"{k}={v}" for k, v in m.items()))' "$BA/configs/$N1.json")" \
    || { echo "Abgebrochen: negative_mix in configs/$N1.json nicht lesbar." >&2; exit 1; }
QUELLEN=(--source-root "$HANDOFF" --source-root "$ARCHTHALIA" --supplement-root "$ERGAENZUNG")
ARGUMENTE=(prepare-negatives --manifest "$BA/configs/caches.csv" --priority-file "$BA/configs/training_priority_middle.csv"
           "${QUELLEN[@]}" --negative-mix "$MISCHUNG" ${GENOM[@]+"${GENOM[@]}"} ${WEGLASSEN[@]+"${WEGLASSEN[@]}"})
"$PY" "$BA/data.py" "${ARGUMENTE[@]}" --check-only --report "$LOGS/pruefung.json" \
    || { echo "Abgebrochen: Die Prüfung der Quellen ist fehlgeschlagen (Meldung oben); nichts eingereicht." >&2; exit 1; }
echo "Prüfprotokoll: $LOGS/pruefung.json"
if [ "$NUR_PRUEFEN" = 1 ]; then
    echo "Nur geprüft (--nur-pruefen): nichts eingereicht."
    exit 0
fi

echo "== Cache-Job einreichen"
JOBDATEI="$LOGS/n1_caches.sbatch"
{
    echo "#!/usr/bin/env bash"
    echo "set -euo pipefail"
    echo "echo \"Caches mit Negativtypen als \$(id -un) auf \$(hostname), Job \$SLURM_JOB_ID\""
    printf '%q ' "$PY" "$BA/data.py" "${ARGUMENTE[@]}" --report "$LOGS/caches.json"
    echo
} > "$JOBDATEI"
PARTITION="$(squeue --me -h -o "%j|%P" | awk -F'|' '$1 ~ /^h301_collect_/ && !p {p = $2} END {print p}')" || PARTITION=""
OPTIONEN=(--parsable --no-requeue --job-name=h301_n1_caches --chdir="$BA" --output="$LOGS/n1_caches_%j.out"
          --time=12:00:00 --ntasks=1 --cpus-per-task=2 --mem=32G --export=ALL)
[ -n "$PARTITION" ] && OPTIONEN+=(--partition="$PARTITION")
CACHEJOB="$(sbatch "${OPTIONEN[@]}" ${ACCOUNT[@]+"${ACCOUNT[@]}"} "$JOBDATEI")"
CACHEJOB="${CACHEJOB%%;*}"
echo "Cache-Job $CACHEJOB (Log $LOGS/n1_caches_$CACHEJOB.out)"

echo "== N1E und N1 einreichen"
ausgabe="$(cd "$BA" && bash submit_array.sh "$N1E" "$N1" ${ACCOUNT[@]+"${ACCOUNT[@]}"} 2>&1)" || {
    echo "$ausgabe"
    echo "Abgebrochen: submit_array.sh ist gescheitert; der Cache-Job $CACHEJOB läuft weiter (schadet nicht)." >&2
    exit 1; }
echo "$ausgabe"
ARRAY="$(sed -n 's/^Jobarray \([0-9][0-9]*\):.*/\1/p' <<< "$ausgabe" | sed -n 1p)"
[ -n "$ARRAY" ] || { echo "Abgebrochen: Nummer des neuen Arrays nicht gefunden." >&2; exit 1; }
if scontrol update JobId="$ARRAY" Dependency=afterok:"$CACHEJOB"; then
    echo "Array $ARRAY wartet nur noch auf den Cache-Job $CACHEJOB (die Wartemeldung oben gilt nicht mehr)."
else
    # ohne diese Bedingung könnte das Array vor den Caches starten: dann lieber gar nicht
    SAMMLER="$(squeue --me -h -o "%i|%j|%Z" | awk -F'|' -v ba="$BA_ECHT" -v a="$N1E" -v b="$N1" \
        '$3 == ba && ($2 == "h301_collect_" a || $2 == "h301_collect_" b) {print $1}')" || SAMMLER=""
    scancel "$ARRAY" $SAMMLER || true
    echo "Abgebrochen: Wartebedingung von $ARRAY nicht setzbar; Array und Sammeljobs wieder entfernt, der" \
         "Cache-Job $CACHEJOB läuft weiter. Bitte melden." >&2
    exit 1
fi

echo "== Andere wartende Arrays nach hinten"
for job in $(squeue --me -h -t PENDING -o "%F|%j|%Z" | awk -F'|' -v ba="$BA_ECHT" '$2 ~ /^h301_array_/ && $3 == ba {print $1}' | sort -u); do
    [ "$job" = "$ARRAY" ] && continue
    if scontrol update JobId="$job" Nice=100000; then
        echo "Array $job: niedrigere Priorität (Nice 100000)"
    else
        echo "WARNUNG: Priorität von Array $job nicht gesenkt – Ausgabe unten prüfen." >&2
    fi
    GRUND="$(squeue -h -j "$job" -t PENDING -o "%r" 2>/dev/null || true)"
    if grep -q "JobHeld" <<< "$GRUND"; then
        scontrol release "$job" && echo "Array $job: wieder freigegeben (startet nach N1)" \
            || echo "WARNUNG: Array $job nicht freigegeben – selbst: scontrol release $job" >&2
    fi
done

echo "== Aufräumen neu einplanen"
AUFRAEUMEN="$(squeue --me -h -o "%i|%j|%Z" | awk -F'|' -v ba="$BA_ECHT" '$2 == "h301_aufraeumen" && $3 == ba {print $1}')" \
    || AUFRAEUMEN=""
if [ -n "$AUFRAEUMEN" ]; then
    scancel $AUFRAEUMEN || true
    sleep 2
    (cd "$BA" && bash aufraeumen.sh --nach-jobs) || echo "WARNUNG: Aufräumen nicht neu eingeplant – später: bash aufraeumen.sh --nach-jobs" >&2
else
    echo "Kein Aufräumen eingeplant."
fi

echo "== Wartende Jobs mit Priorität (höher startet zuerst)"
squeue --me -t PENDING -o "%.18i %.10Q %.22r %.60j"
echo "Auswertung, sobald Läufe fertig sind: python $H301/n1_auswertung/n1_auswerten.py"
