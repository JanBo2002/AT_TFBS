"""Auswertung von N1 (Training mit random, aliens, shades) und N1E (01 auf demselben Testsatz).

    python n1_auswertung/n1_auswerten.py [--big-ablation PFAD]

Liest die abgeschlossenen Läufe (auch während das Array noch läuft) und schreibt nach n1_auswertung/ergebnisse/:
  n1_pro_lauf.csv   je Config, TF, Richtung, Seed und Auswertung: AUROC, AUPRC, n_pos, n_neg, Zufallsniveau
  n1_vergleich.csv  je TF, Richtung, Auswertung: N1 (Seed 13) gegen 01 Seed 13 und gegen das Mittel der 01-Seeds
  n1_median.csv     Mediane je Richtung und Auswertung, dazu Zahl der TFs, bei denen N1 besser ist
  n1_bruecke.csv    Brücke b): nur_random von N1E gegen die AUPRC des ursprünglichen 01-Testlaufs
Auswertungen: gesamt (alle Negativen), nur_random (= bisheriger Testsatz), nur_aliens, nur_shades.
"""
import argparse
import csv
import json
import statistics
from pathlib import Path

N1 = "N1_01_aliens_shades_middle"
N1E = "N1E_01_eval_aliens_shades_middle"
AUSWERTUNGEN = {"standard": "gesamt", "nur_random": "nur_random", "nur_aliens": "nur_aliens", "nur_shades": "nur_shades"}
KURZ = {"CHIP": "CHS", "GHTS": "GHTS"}
RICHTUNGEN = ["CHS→CHS", "GHTS→GHTS", "CHS→GHTS", "GHTS→CHS"]


def laeufe(ordner):
    """[(tf, train, seed, run_dir)] der abgeschlossenen Läufe einer Config."""
    result = []
    for run in sorted((ordner / "runs").glob("*/train_*/seed_*/run.json")) if (ordner / "runs").is_dir() else []:
        try:
            meta = json.loads(run.read_text())
        except (OSError, ValueError):
            continue
        if meta.get("status") == "completed":
            result.append((meta["tf"], meta["train_assay"], int(meta["seed"]), run.parent))
    return result


def lesen(ordner, config):
    zeilen, bruecken = [], []
    for tf, train, seed, run in laeufe(ordner):
        for test in ("CHIP", "GHTS"):
            for kennung, name in AUSWERTUNGEN.items():
                pfad = run / "evaluations" / kennung / test / "metrics.json"
                try:
                    daten = json.loads(pfad.read_text())
                    m = daten["test_metrics"]
                except (OSError, ValueError, KeyError):
                    continue
                zeilen.append({"config": config, "tf": tf, "richtung": f"{KURZ[train]}→{KURZ[test]}", "seed": seed,
                               "auswertung": name, "auroc": m["auroc"], "auprc": m["auprc"],
                               "n_pos": m["positive_count"], "n_neg": m["negative_count"],
                               "zufallsniveau": m["pr_baseline"]})
                b = daten.get("bruecke_zum_original")
                if kennung == "nur_random" and isinstance(b, dict):
                    bruecken.append({"tf": tf, "richtung": f"{KURZ[train]}→{KURZ[test]}", "seed": seed,
                                     "quelle_config": b.get("source_config"), "auprc_original": b.get("auprc_original"),
                                     "auprc_nur_random": b.get("auprc_nur_random"),
                                     "abweichung_auprc": b.get("abweichung_auprc"),
                                     "abweichung_auroc": b.get("abweichung_auroc"),
                                     "n_gleich": b.get("n_original") == b.get("n_nur_random"),
                                     "gleiche_ansichten": b.get("gleiche_ansichten"),
                                     "geraet_original": b.get("geraet_original"), "geraet_jetzt": b.get("geraet_jetzt"),
                                     "torch_original": b.get("torch_original"), "torch_jetzt": b.get("torch_jetzt"),
                                     "status": b.get("status")})
    return zeilen, bruecken


def schreiben(pfad, zeilen, felder):
    with pfad.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=felder)
        writer.writeheader()
        for zeile in zeilen:
            writer.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v) for k, v in zeile.items()})


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    hier = Path(__file__).resolve().parent
    parser.add_argument("--big-ablation", type=Path, default=hier.parent / "big_ablation")
    args = parser.parse_args()
    results = args.big_ablation / "results"
    n1, _ = lesen(results / N1, "N1")
    e01, bruecken = lesen(results / N1E, "01")
    ziel = hier / "ergebnisse"
    ziel.mkdir(exist_ok=True)
    felder = ["config", "tf", "richtung", "seed", "auswertung", "auroc", "auprc", "n_pos", "n_neg", "zufallsniveau"]
    schreiben(ziel / "n1_pro_lauf.csv", n1 + e01, felder)

    # Vergleich je TF/Richtung/Auswertung
    def tabelle(zeilen, seed=None):
        result = {}
        for z in zeilen:
            if seed is None or z["seed"] == seed:
                result.setdefault((z["tf"], z["richtung"], z["auswertung"]), []).append(z)
        return result
    n1_s13, alt_s13, alt_alle = tabelle(n1, 13), tabelle(e01, 13), tabelle(e01)
    vergleich = []
    for key in sorted(n1_s13, key=lambda k: (RICHTUNGEN.index(k[1]), k[2], k[0])):
        neu = n1_s13[key][0]
        zeile = {"tf": key[0], "richtung": key[1], "auswertung": key[2], "auprc_n1": neu["auprc"],
                 "zufallsniveau": neu["zufallsniveau"], "n_pos": neu["n_pos"], "n_neg": neu["n_neg"],
                 "auprc_01_seed13": None, "auprc_01_mittel": None, "n_seeds_01": 0,
                 "delta_zu_seed13": None, "delta_zu_mittel": None}
        if key in alt_s13:
            zeile["auprc_01_seed13"] = alt_s13[key][0]["auprc"]
            zeile["delta_zu_seed13"] = neu["auprc"] - zeile["auprc_01_seed13"]
        if key in alt_alle:
            werte = [z["auprc"] for z in alt_alle[key]]
            zeile.update(auprc_01_mittel=statistics.fmean(werte), n_seeds_01=len(werte))
            zeile["delta_zu_mittel"] = neu["auprc"] - zeile["auprc_01_mittel"]
        vergleich.append(zeile)
    schreiben(ziel / "n1_vergleich.csv", vergleich, list(vergleich[0]) if vergleich else
              ["tf", "richtung", "auswertung", "auprc_n1"])

    # Mediane je Richtung und Auswertung
    median = []
    for richtung in RICHTUNGEN:
        for name in AUSWERTUNGEN.values():
            zeilen = [z for z in vergleich if z["richtung"] == richtung and z["auswertung"] == name]
            gepaart = [z for z in zeilen if z["delta_zu_mittel"] is not None]
            if not zeilen:
                continue
            median.append({"richtung": richtung, "auswertung": name, "n_tfs": len(zeilen),
                           "median_auprc_n1": statistics.median(z["auprc_n1"] for z in zeilen),
                           "median_auprc_01_mittel": (statistics.median(z["auprc_01_mittel"] for z in gepaart)
                                                      if gepaart else None),
                           "median_delta_zu_mittel": (statistics.median(z["delta_zu_mittel"] for z in gepaart)
                                                      if gepaart else None),
                           "n1_besser": sum(z["delta_zu_mittel"] > 0 for z in gepaart), "n_gepaart": len(gepaart),
                           "median_zufallsniveau": statistics.median(z["zufallsniveau"] for z in zeilen)})
    schreiben(ziel / "n1_median.csv", median, list(median[0]) if median else ["richtung", "auswertung"])
    schreiben(ziel / "n1_bruecke.csv", bruecken,
              list(bruecken[0]) if bruecken else ["tf", "richtung", "seed", "status"])

    def zahl(zeilen):
        return len({(z["tf"], z["richtung"].split("→")[0], z["seed"]) for z in zeilen})
    print(f"Abgeschlossene Läufe: N1 {zahl(n1)} (Ziel 42), 01 nachbewertet {zahl(e01)} (Ziel 126)")
    if bruecken:
        gleich = [b for b in bruecken if b["status"] == "identisch"]
        werte = [abs(b["abweichung_auprc"]) for b in bruecken if isinstance(b["abweichung_auprc"], (int, float))]
        print(f"Brücke b): {len(gleich)} von {len(bruecken)} Auswertungen identisch"
              + (f"; größte Abweichung der AUPRC {max(werte):.2e}" if werte else ""))
        for b in bruecken:
            if b["status"] != "identisch":
                print(f"  ABWEICHUNG {b['tf']} {b['richtung']} Seed {b['seed']}: {b['auprc_nur_random']} gegen "
                      f"{b['auprc_original']} ({b['status']}; Ansichten gleich: {b['gleiche_ansichten']}; GPU "
                      f"{b['geraet_original']} -> {b['geraet_jetzt']}; torch {b['torch_original']} -> {b['torch_jetzt']})")
    if median:
        print("\nMedian AUPRC je Richtung (N1 Seed 13 | 01 Mittel der Seeds | Median der Differenzen je TF | "
              "TFs mit N1 besser):")
        for m in median:
            alt = "–" if m["median_auprc_01_mittel"] is None else f"{m['median_auprc_01_mittel']:.4f}"
            delta = "–" if m["median_delta_zu_mittel"] is None else f"{m['median_delta_zu_mittel']:+.4f}"
            print(f"  {m['richtung']:<10} {m['auswertung']:<11} {m['median_auprc_n1']:.4f} | {alt} | {delta} | "
                  f"{m['n1_besser']}/{m['n_gepaart']}  (Zufall {m['median_zufallsniveau']:.4f})")
    print(f"\nTabellen: {ziel}")


if __name__ == "__main__":
    main()
